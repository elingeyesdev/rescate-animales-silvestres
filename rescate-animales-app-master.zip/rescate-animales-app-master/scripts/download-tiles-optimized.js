#!/usr/bin/env node

/**
 * Tile Downloader for Santa Cruz, Bolivia
 * Downloads OpenStreetMap tiles for offline use
 * 
 * OPTIMIZED VERSION - Downloads only essential tiles
 * 
 * Usage: node scripts/download-tiles-optimized.js
 */

const https = require('https');
const fs = require('fs');
const path = require('path');

// Santa Cruz bounds (REDUCED AREA - only city center)
const BOUNDS = {
    north: -17.75,   // Reduced from -17.7
    south: -17.82,   // Reduced from -17.85
    east: -63.15,    // Reduced from -63.05
    west: -63.20     // Reduced from -63.25
};

// REDUCED zoom levels (only essential)
const ZOOM_LEVELS = [12, 13, 14]; // Only 3 levels instead of 6
const OUTPUT_DIR = path.join(__dirname, '..', 'assets', 'map-tiles');
const TILE_SERVER = 'https://tile.openstreetmap.org';

// Convert lat/lng to tile coordinates
function latLngToTile(lat, lng, zoom) {
    const n = Math.pow(2, zoom);
    const x = Math.floor((lng + 180) / 360 * n);
    const y = Math.floor((1 - Math.log(Math.tan(lat * Math.PI / 180) + 1 / Math.cos(lat * Math.PI / 180)) / Math.PI) / 2 * n);
    return { x, y };
}

// Calculate total tiles before downloading
function calculateTotalTiles() {
    let total = 0;
    for (const zoom of ZOOM_LEVELS) {
        const nw = latLngToTile(BOUNDS.north, BOUNDS.west, zoom);
        const se = latLngToTile(BOUNDS.south, BOUNDS.east, zoom);
        const tilesX = se.x - nw.x + 1;
        const tilesY = se.y - nw.y + 1;
        const tilesForZoom = tilesX * tilesY;
        total += tilesForZoom;
        console.log(`Zoom ${zoom}: ${tilesX} x ${tilesY} = ${tilesForZoom} tiles`);
    }
    return total;
}

// Download a single tile
function downloadTile(z, x, y) {
    return new Promise((resolve, reject) => {
        const dir = path.join(OUTPUT_DIR, String(z), String(x));
        const filepath = path.join(dir, `${y}.png`);

        // Check if tile already exists
        if (fs.existsSync(filepath)) {
            resolve({ cached: true });
            return;
        }

        // Create directory if it doesn't exist
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }

        const url = `${TILE_SERVER}/${z}/${x}/${y}.png`;
        const file = fs.createWriteStream(filepath);

        https.get(url, {
            headers: {
                'User-Agent': 'RescateAnimalesApp/1.0'
            }
        }, (response) => {
            if (response.statusCode !== 200) {
                reject(new Error(`Failed: ${response.statusCode}`));
                return;
            }

            response.pipe(file);
            file.on('finish', () => {
                file.close();
                resolve({ cached: false });
            });
        }).on('error', (err) => {
            fs.unlink(filepath, () => { });
            reject(err);
        });
    });
}

// Download all tiles for a zoom level
async function downloadZoomLevel(zoom) {
    const nw = latLngToTile(BOUNDS.north, BOUNDS.west, zoom);
    const se = latLngToTile(BOUNDS.south, BOUNDS.east, zoom);

    const tiles = [];
    for (let x = nw.x; x <= se.x; x++) {
        for (let y = nw.y; y <= se.y; y++) {
            tiles.push({ z: zoom, x, y });
        }
    }

    console.log(`\nZoom ${zoom}: ${tiles.length} tiles`);

    let downloaded = 0;
    let cached = 0;
    let failed = 0;

    for (let i = 0; i < tiles.length; i++) {
        const tile = tiles[i];
        try {
            const result = await downloadTile(tile.z, tile.x, tile.y);
            if (result.cached) {
                cached++;
            } else {
                downloaded++;
                // Only delay for new downloads
                await new Promise(resolve => setTimeout(resolve, 1000));
            }

            // Progress indicator
            if ((i + 1) % 10 === 0 || i === tiles.length - 1) {
                process.stdout.write(`\r  Progress: ${i + 1}/${tiles.length} (Downloaded: ${downloaded}, Cached: ${cached}, Failed: ${failed})`);
            }
        } catch (err) {
            failed++;
            console.error(`\n  ✗ Error: ${tile.z}/${tile.x}/${tile.y}`);
        }
    }

    console.log(`\n  ✓ Complete - Downloaded: ${downloaded}, Cached: ${cached}, Failed: ${failed}`);
}

// Main function
async function main() {
    console.log('='.repeat(60));
    console.log('OpenStreetMap Tile Downloader (OPTIMIZED)');
    console.log('Santa Cruz, Bolivia - City Center Only');
    console.log('='.repeat(60));
    console.log(`Bounds: ${BOUNDS.north}, ${BOUNDS.west} to ${BOUNDS.south}, ${BOUNDS.east}`);
    console.log(`Zoom levels: ${ZOOM_LEVELS.join(', ')}`);
    console.log(`Output: ${OUTPUT_DIR}`);
    console.log('='.repeat(60));

    // Calculate and show total
    const totalTiles = calculateTotalTiles();
    console.log(`\nTotal tiles to download: ${totalTiles}`);
    console.log(`Estimated time: ${Math.ceil(totalTiles / 60)} minutes`);
    console.log(`Estimated size: ${Math.ceil(totalTiles * 15 / 1024)} MB\n`);

    // Confirm before proceeding
    console.log('Starting download in 3 seconds... (Ctrl+C to cancel)');
    await new Promise(resolve => setTimeout(resolve, 3000));

    // Create output directory
    if (!fs.existsSync(OUTPUT_DIR)) {
        fs.mkdirSync(OUTPUT_DIR, { recursive: true });
    }

    // Download tiles for each zoom level
    for (const zoom of ZOOM_LEVELS) {
        await downloadZoomLevel(zoom);
    }

    console.log('\n' + '='.repeat(60));
    console.log('Download complete!');
    console.log('='.repeat(60));

    // Calculate total size
    const getDirectorySize = (dir) => {
        let size = 0;
        try {
            const files = fs.readdirSync(dir, { withFileTypes: true });
            for (const file of files) {
                const filepath = path.join(dir, file.name);
                if (file.isDirectory()) {
                    size += getDirectorySize(filepath);
                } else {
                    size += fs.statSync(filepath).size;
                }
            }
        } catch (e) {
            // Directory doesn't exist yet
        }
        return size;
    };

    const totalSize = getDirectorySize(OUTPUT_DIR);
    const sizeMB = (totalSize / (1024 * 1024)).toFixed(2);
    console.log(`Total size: ${sizeMB} MB`);
    console.log('\nTiles are ready to use!');
}

main().catch(console.error);
