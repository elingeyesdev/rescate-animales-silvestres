#!/usr/bin/env node

/**
 * Tile Downloader for Santa Cruz, Bolivia
 * Downloads OpenStreetMap tiles for offline use
 * 
 * Usage: node scripts/download-tiles.js
 */

const https = require('https');
const fs = require('fs');
const path = require('path');

// Santa Cruz bounds
const BOUNDS = {
    north: -17.7,
    south: -17.85,
    east: -63.05,
    west: -63.25
};

const ZOOM_LEVELS = [11, 12, 13, 14, 15, 16];
const OUTPUT_DIR = path.join(__dirname, '..', 'assets', 'map-tiles');
const TILE_SERVER = 'https://tile.openstreetmap.org';

// Convert lat/lng to tile coordinates
function latLngToTile(lat, lng, zoom) {
    const n = Math.pow(2, zoom);
    const x = Math.floor((lng + 180) / 360 * n);
    const y = Math.floor((1 - Math.log(Math.tan(lat * Math.PI / 180) + 1 / Math.cos(lat * Math.PI / 180)) / Math.PI) / 2 * n);
    return { x, y };
}

// Download a single tile
function downloadTile(z, x, y) {
    return new Promise((resolve, reject) => {
        const dir = path.join(OUTPUT_DIR, String(z), String(x));
        const filepath = path.join(dir, `${y}.png`);

        // Check if tile already exists
        if (fs.existsSync(filepath)) {
            console.log(`✓ Tile exists: ${z}/${x}/${y}`);
            resolve();
            return;
        }

        // Create directory if it doesn't exist
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }

        const url = `${TILE_SERVER}/${z}/${x}/${y}.png`;
        const file = fs.createWriteStream(filepath);

        https.get(url, {
            headers: {
                'User-Agent': 'RescateAnimalesApp/1.0'
            }
        }, (response) => {
            if (response.statusCode !== 200) {
                reject(new Error(`Failed to download tile ${z}/${x}/${y}: ${response.statusCode}`));
                return;
            }

            response.pipe(file);
            file.on('finish', () => {
                file.close();
                console.log(`✓ Downloaded: ${z}/${x}/${y}`);
                resolve();
            });
        }).on('error', (err) => {
            fs.unlink(filepath, () => { });
            reject(err);
        });
    });
}

// Download all tiles for a zoom level
async function downloadZoomLevel(zoom) {
    const nw = latLngToTile(BOUNDS.north, BOUNDS.west, zoom);
    const se = latLngToTile(BOUNDS.south, BOUNDS.east, zoom);

    const tiles = [];
    for (let x = nw.x; x <= se.x; x++) {
        for (let y = nw.y; y <= se.y; y++) {
            tiles.push({ z: zoom, x, y });
        }
    }

    console.log(`\nZoom ${zoom}: ${tiles.length} tiles to download`);

    // Download tiles with rate limiting (1 tile per second to be respectful)
    for (const tile of tiles) {
        try {
            await downloadTile(tile.z, tile.x, tile.y);
            await new Promise(resolve => setTimeout(resolve, 1000)); // 1 second delay
        } catch (err) {
            console.error(`✗ Error downloading ${tile.z}/${tile.x}/${tile.y}:`, err.message);
        }
    }
}

// Main function
async function main() {
    console.log('='.repeat(50));
    console.log('OpenStreetMap Tile Downloader');
    console.log('Santa Cruz, Bolivia');
    console.log('='.repeat(50));
    console.log(`Bounds: ${BOUNDS.north}, ${BOUNDS.west} to ${BOUNDS.south}, ${BOUNDS.east}`);
    console.log(`Zoom levels: ${ZOOM_LEVELS.join(', ')}`);
    console.log(`Output directory: ${OUTPUT_DIR}`);
    console.log('='.repeat(50));

    // Create output directory
    if (!fs.existsSync(OUTPUT_DIR)) {
        fs.mkdirSync(OUTPUT_DIR, { recursive: true });
    }

    // Download tiles for each zoom level
    for (const zoom of ZOOM_LEVELS) {
        await downloadZoomLevel(zoom);
    }

    console.log('\n' + '='.repeat(50));
    console.log('Download complete!');
    console.log('='.repeat(50));

    // Calculate total size
    const getDirectorySize = (dir) => {
        let size = 0;
        const files = fs.readdirSync(dir, { withFileTypes: true });
        for (const file of files) {
            const filepath = path.join(dir, file.name);
            if (file.isDirectory()) {
                size += getDirectorySize(filepath);
            } else {
                size += fs.statSync(filepath).size;
            }
        }
        return size;
    };

    const totalSize = getDirectorySize(OUTPUT_DIR);
    const sizeMB = (totalSize / (1024 * 1024)).toFixed(2);
    console.log(`Total size: ${sizeMB} MB`);
}

main().catch(console.error);
