import { createNativeStackNavigator } from '@react-navigation/native-stack';
import MyReportsScreen from '../screens/MyReportsScreen';
import ReportCreateScreen from '../screens/ReportCreateScreen';
import ApprovedReportsScreen from '../screens/ApprovedReportsScreen';
import AnimalFileCreateScreen from '../screens/AnimalFileCreateScreen';
import ReportsScreen from '../screens/ReportsScreen';
import TransfersScreen from '../screens/TransfersScreen';
import HojaDeVida from '../screens/HojaDeVida';
import { MaterialIcons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { useAuth } from '../context/AuthContext';
import { Pressable, Text, View, Animated, Easing } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useEffect, useState } from 'react';
import { useWindowDimensions } from 'react-native';

const Stack = createNativeStackNavigator();

function MenuScreen({ navigation }) {
  const { logout, hasRole } = useAuth();
  const { width } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const [anim] = useState(new Animated.Value(1));
  const panelW = Math.min(360, Math.max(240, width * 0.46));
  // Padding grande además de los safe area insets
  const topPadding = insets.top + 40;
  const bottomPadding = insets.bottom + 40;
  useEffect(() => { Animated.timing(anim, { toValue: 0, duration: 220, easing: Easing.out(Easing.quad), useNativeDriver: true }).start(); }, []);
  const translateX = anim.interpolate({ inputRange: [0, 1], outputRange: [0, -panelW] });
  const go = (routeName, params) => {
    const localRoutes = ['MyReports', 'ReportCreate', 'ApprovedReports', 'Reports', 'Transfers', 'HojaDeVida'];
    if (localRoutes.includes(routeName)) {
      navigation.replace(routeName, params);
    } else {
      navigation.getParent()?.navigate(routeName, params);
      navigation.goBack();
    }
  };
  const doLogout = async () => {
    await logout();
    navigation.getParent()?.replace('Login');
  };
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <Pressable onPress={() => navigation.goBack()} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.35)' }} />
      <Animated.View style={{ position: 'absolute', top: 0, left: 0, bottom: 0, width: panelW, transform: [{ translateX }], backgroundColor: colors.cardBg, borderRightWidth: 1, borderColor: colors.border }}>
        <View style={{ paddingTop: topPadding, paddingHorizontal: 16, paddingBottom: 16, borderBottomWidth: 1, borderColor: colors.border }}>
          <Text style={{ color: colors.textDark, fontWeight: '700', fontSize: 18 }}>Menú</Text>
          <Text style={{ color: colors.textLight, marginTop: 4 }}>Navega por la app</Text>
        </View>
        <View>
          <Pressable onPress={() => go('MyReports')} style={{ flexDirection: 'row', alignItems: 'center', padding: 14, borderBottomWidth: 1, borderColor: colors.border }}>
            <MaterialIcons name="home" size={20} color={colors.icon} style={{ marginRight: 10 }} />
            <Text style={{ color: colors.textDark, fontWeight: '600' }}>Menu</Text>
          </Pressable>
          <Pressable onPress={() => go('ReportCreate')} style={{ flexDirection: 'row', alignItems: 'center', padding: 14, borderBottomWidth: 1, borderColor: colors.border }}>
            <MaterialIcons name="add-circle" size={20} color={colors.icon} style={{ marginRight: 10 }} />
            <Text style={{ color: colors.textDark, fontWeight: '600' }}>Registrar</Text>
          </Pressable>
          {hasRole(['admin','encargado']) ? (
          <Pressable onPress={() => go('ApprovedReports')} style={{ flexDirection: 'row', alignItems: 'center', padding: 14, borderBottomWidth: 1, borderColor: colors.border }}>
            <MaterialIcons name="verified" size={20} color={colors.icon} style={{ marginRight: 10 }} />
            <Text style={{ color: colors.textDark, fontWeight: '600' }}>Aprobados</Text>
          </Pressable>
          ) : null}
          {hasRole(['encargado','admin']) ? (
          <Pressable onPress={() => go('AnimalFileCreate')} style={{ flexDirection: 'row', alignItems: 'center', padding: 14, borderBottomWidth: 1, borderColor: colors.border }}>
            <MaterialIcons name="assignment" size={20} color={colors.icon} style={{ marginRight: 10 }} />
            <Text style={{ color: colors.textDark, fontWeight: '600' }}>Crear Hoja de Vida</Text>
          </Pressable>
          ) : null}
          <Pressable onPress={() => go('HojaDeVida')} style={{ flexDirection: 'row', alignItems: 'center', padding: 14, borderBottomWidth: 1, borderColor: colors.border }}>
            <MaterialIcons name="description" size={20} color={colors.icon} style={{ marginRight: 10 }} />
            <Text style={{ color: colors.textDark, fontWeight: '600' }}>Hoja de vida</Text>
          </Pressable>
          {hasRole(['veterinario']) ? (
          <Pressable onPress={() => go('Evaluations')} style={{ flexDirection: 'row', alignItems: 'center', padding: 14, borderBottomWidth: 1, borderColor: colors.border }}>
            <MaterialIcons name="medical-services" size={20} color={colors.icon} style={{ marginRight: 10 }} />
            <Text style={{ color: colors.textDark, fontWeight: '600' }}>Evaluaciones</Text>
          </Pressable>
          ) : null}
          {hasRole(['cuidador']) ? (
          <Pressable onPress={() => go('Cares')} style={{ flexDirection: 'row', alignItems: 'center', padding: 14, borderBottomWidth: 1, borderColor: colors.border }}>
            <MaterialIcons name="health-and-safety" size={20} color={colors.icon} style={{ marginRight: 10 }} />
            <Text style={{ color: colors.textDark, fontWeight: '600' }}>Cuidados</Text>
          </Pressable>
          ) : null}
          <Pressable onPress={() => go('History')} style={{ flexDirection: 'row', alignItems: 'center', padding: 14, borderBottomWidth: 1, borderColor: colors.border }}>
            <MaterialIcons name="history" size={20} color={colors.icon} style={{ marginRight: 10 }} />
            <Text style={{ color: colors.textDark, fontWeight: '600' }}>Historial</Text>
          </Pressable>
          <Pressable onPress={() => go('Transfers')} style={{ flexDirection: 'row', alignItems: 'center', padding: 14, borderBottomWidth: 1, borderColor: colors.border }}>
            <MaterialIcons name="local-shipping" size={20} color={colors.icon} style={{ marginRight: 10 }} />
            <Text style={{ color: colors.textDark, fontWeight: '600' }}>Traslados</Text>
          </Pressable>
          <Pressable onPress={() => go('Reports')} style={{ flexDirection: 'row', alignItems: 'center', padding: 14, borderBottomWidth: 1, borderColor: colors.border }}>
            <MaterialIcons name="analytics" size={20} color={colors.icon} style={{ marginRight: 10 }} />
            <Text style={{ color: colors.textDark, fontWeight: '600' }}>Reportes</Text>
          </Pressable>
         
        </View>
        <View style={{ marginTop: 'auto', paddingTop: 14, paddingHorizontal: 14, paddingBottom: bottomPadding, borderTopWidth: 1, borderColor: colors.border }}>
          <Pressable onPress={doLogout} style={{ backgroundColor: colors.danger, paddingVertical: 12, borderRadius: 6, alignItems: 'center' }}>
            <Text style={{ color: '#fff', fontWeight: '700' }}>Cerrar sesión</Text>
          </Pressable>
        </View>
      </Animated.View>
    </SafeAreaView>
  );
}

export default function MainTabs() {
  const rootNav = useNavigation();
  const { logout } = useAuth();
  const HeaderMenuButton = () => {
    const nav = useNavigation();
    return (
      <Pressable onPress={() => nav.navigate('MainMenu')} style={{ paddingHorizontal: 12, paddingVertical: 8, flexDirection: 'row', alignItems: 'center' }}>
        <MaterialIcons name="menu" size={20} color={colors.blue} style={{ marginRight: 6 }} />
        <Text style={{ color: colors.blue, fontWeight: '600' }}>Menú</Text>
      </Pressable>
    );
  };
  const goTo = (screen, params) => {
    try { rootNav.navigate(screen, params); } catch {}
  };
  const doLogout = async () => {
    await logout();
    try { rootNav.getParent()?.replace('Login'); } catch { rootNav.replace('Login'); }
  };
  
  // Configuración común del header
  // La barra de estado está oculta, así que no necesitamos padding extra
  const headerOptions = {
    headerStyle: {
      backgroundColor: colors.bg,
    },
    headerTitleStyle: {
      color: colors.textDark,
    },
    headerTintColor: colors.textDark,
    // Asegura que el contenido no se solape con el header
    contentStyle: {
      flex: 1,
    },
  };

  return (
    <View style={{ flex: 1 }}>
    <Stack.Navigator
      screenOptions={headerOptions}
    >
      <Stack.Screen 
        name="MyReports" 
        component={MyReportsScreen} 
        options={{
          title: '', // Removed 'Mis hallazgos' title
          headerRight: () => <HeaderMenuButton />,
        }}
      />
      <Stack.Screen
        name="ReportCreate"
        component={ReportCreateScreen}
        options={{
          title: 'Registrar',
          headerRight: () => <HeaderMenuButton />,
        }}
      />
      <Stack.Screen
        name="ApprovedReports"
        component={ApprovedReportsScreen}
        options={{
          title: 'Aprobados',
          headerRight: () => <HeaderMenuButton />,
        }}
      />
      <Stack.Screen
        name="AnimalFileCreate"
        component={AnimalFileCreateScreen}
        options={{
          title: 'Crear Hoja de Vida',
          headerRight: () => <HeaderMenuButton />,
        }}
      />
      <Stack.Screen
        name="HojaDeVida"
        component={HojaDeVida}
        options={{
          title: 'Hoja de vida',
          headerRight: () => <HeaderMenuButton />,
        }}
      />
      <Stack.Screen
        name="Transfers"
        component={TransfersScreen}
        options={{
          title: 'Traslados',
          headerRight: () => <HeaderMenuButton />,
        }}
      />
      <Stack.Screen
        name="Reports"
        component={ReportsScreen}
        options={{
          title: 'Reportes',
          headerRight: () => <HeaderMenuButton />,
        }}

      
      />
      <Stack.Screen name="MainMenu" component={MenuScreen} options={{ headerShown: false, presentation: 'transparentModal' }} />
    </Stack.Navigator>
    </View>
  );
}
