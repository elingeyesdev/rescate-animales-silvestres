/**
 * Crash Prevention Utilities
 * Funciones para prevenir crashes en la aplicación
 */

/**
 * Acceso seguro a propiedades anidadas
 * @param {Object} obj - Objeto a acceder
 * @param {string} path - Ruta de la propiedad (ej: 'user.profile.name')
 * @param {*} defaultValue - Valor por defecto si no existe
 * @returns {*} Valor encontrado o defaultValue
 */
export const safeGet = (obj, path, defaultValue = null) => {
    try {
        if (!obj || !path) return defaultValue;

        const keys = path.split('.');
        let result = obj;

        for (const key of keys) {
            if (result == null || typeof result !== 'object') {
                return defaultValue;
            }
            result = result[key];
        }

        return result !== undefined ? result : defaultValue;
    } catch (error) {
        console.warn('[safeGet] Error accessing path:', path, error);
        return defaultValue;
    }
};

/**
 * Asegura que un valor sea un array
 * @param {*} value - Valor a verificar
 * @returns {Array} Array válido o array vacío
 */
export const safeArray = (value) => {
    return Array.isArray(value) ? value : [];
};

/**
 * Navegación segura entre pantallas
 * @param {Object} navigation - Objeto de navegación
 * @param {string} screen - Nombre de la pantalla
 * @param {Object} params - Parámetros opcionales
 */
export const safeNavigate = (navigation, screen, params) => {
    try {
        if (!navigation || typeof navigation.navigate !== 'function') {
            console.error('[safeNavigate] Invalid navigation object');
            return;
        }

        navigation.navigate(screen, params);
    } catch (error) {
        console.error('[safeNavigate] Navigation error:', error);
    }
};

/**
 * Ejecuta una función async de forma segura
 * @param {Function} asyncFn - Función async a ejecutar
 * @param {Function} onError - Callback opcional para manejar errores
 * @returns {Promise} Promesa que nunca rechaza
 */
export const safeAsync = async (asyncFn, onError) => {
    try {
        return await asyncFn();
    } catch (error) {
        console.error('[safeAsync] Error:', error);
        if (onError && typeof onError === 'function') {
            onError(error);
        }
        return null;
    }
};

/**
 * Wrapper para llamadas API con fallback
 * @param {Function} apiCall - Función que hace la llamada API
 * @param {*} fallbackValue - Valor a retornar en caso de error
 * @returns {Promise} Resultado de la API o fallbackValue
 */
export const safeApiCall = async (apiCall, fallbackValue = null) => {
    try {
        const result = await apiCall();
        return result;
    } catch (error) {
        console.error('[safeApiCall] API error:', error);
        return fallbackValue;
    }
};

/**
 * Renderizado seguro de componentes
 * @param {Function} renderFn - Función de renderizado
 * @param {*} fallback - Componente fallback en caso de error
 * @returns {*} Resultado del render o fallback
 */
export const safeRender = (renderFn, fallback = null) => {
    try {
        return renderFn();
    } catch (error) {
        console.error('[safeRender] Render error:', error);
        return fallback;
    }
};

/**
 * Parseo seguro de JSON
 * @param {string} jsonString - String JSON a parsear
 * @param {*} defaultValue - Valor por defecto si falla
 * @returns {*} Objeto parseado o defaultValue
 */
export const safeJsonParse = (jsonString, defaultValue = null) => {
    try {
        return JSON.parse(jsonString);
    } catch (error) {
        console.warn('[safeJsonParse] Parse error:', error);
        return defaultValue;
    }
};

/**
 * Stringify seguro de objetos
 * @param {*} obj - Objeto a convertir a string
 * @param {string} defaultValue - Valor por defecto si falla
 * @returns {string} String JSON o defaultValue
 */
export const safeJsonStringify = (obj, defaultValue = '{}') => {
    try {
        return JSON.stringify(obj);
    } catch (error) {
        console.warn('[safeJsonStringify] Stringify error:', error);
        return defaultValue;
    }
};

/**
 * Wrapper para useEffect que captura errores
 * @param {Function} effect - Función de efecto
 * @param {Array} deps - Dependencias
 * @returns {Function} Cleanup function
 */
export const safeEffect = (effect, deps) => {
    return () => {
        try {
            const cleanup = effect();
            return cleanup;
        } catch (error) {
            console.error('[safeEffect] Effect error:', error);
            return () => { };
        }
    };
};

/**
 * Validación segura de número
 * @param {*} value - Valor a validar
 * @param {number} defaultValue - Valor por defecto
 * @returns {number} Número válido o defaultValue
 */
export const safeNumber = (value, defaultValue = 0) => {
    const num = Number(value);
    return isNaN(num) ? defaultValue : num;
};

/**
 * Validación segura de string
 * @param {*} value - Valor a validar
 * @param {string} defaultValue - Valor por defecto
 * @returns {string} String válido o defaultValue
 */
export const safeString = (value, defaultValue = '') => {
    return value != null ? String(value) : defaultValue;
};
