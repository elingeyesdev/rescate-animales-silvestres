/**
 * Get offline tile URL for WebView
 * Since we can't directly access bundled assets in WebView,
 * we'll use online tiles with offline fallback message
 */
export function getOfflineTileLayer() {
  // For now, we'll use online tiles
  // In production, you could:
  // 1. Copy tiles to FileSystem on first launch
  // 2. Serve them via a local HTTP server
  // 3. Use a custom tile provider

  return {
    // Primary: Online tiles
    online: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    // Fallback: Could implement local tile server
    offline: null,
    maxZoom: 19,
    minZoom: 11
  };
}

/**
 * Generate Leaflet map HTML with offline support
 */
export function generateMapHTML({ lat, lng, zoom = 13, interactive = false, marker = true, title = 'Ubicación' }) {
  const tileConfig = getOfflineTileLayer();

  return `<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
  <style>
    html, body, #map { 
      height: 100%; 
      margin: 0; 
      padding: 0; 
    }
    .offline-notice {
      position: absolute;
      top: 10px;
      left: 50%;
      transform: translateX(-50%);
      background: rgba(255, 152, 0, 0.9);
      color: white;
      padding: 8px 16px;
      border-radius: 4px;
      z-index: 1000;
      font-family: Arial, sans-serif;
      font-size: 12px;
      display: none;
    }
  </style>
</head>
<body>
  <div id="offline-notice" class="offline-notice">
    ⚠️ Modo offline - Mapa limitado
  </div>
  <div id="map"></div>
  <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
  <script>
    const map = L.map('map', {
      zoomControl: ${interactive},
      attributionControl: false,
      dragging: ${interactive},
      touchZoom: ${interactive},
      scrollWheelZoom: ${interactive},
      doubleClickZoom: ${interactive}
    }).setView([${lat}, ${lng}], ${zoom});

    // Try to load tiles
    const tileLayer = L.tileLayer('${tileConfig.online}', {
      maxZoom: ${tileConfig.maxZoom},
      minZoom: ${tileConfig.minZoom},
      attribution: ''
    });

    // Show offline notice if tiles fail to load
    let tilesLoaded = false;
    tileLayer.on('load', function() {
      tilesLoaded = true;
    });

    tileLayer.on('tileerror', function() {
      if (!tilesLoaded) {
        document.getElementById('offline-notice').style.display = 'block';
      }
    });

    tileLayer.addTo(map);

    ${marker ? `
    const marker = L.marker([${lat}, ${lng}], {
      draggable: ${interactive}
    }).addTo(map);
    
    ${title ? `marker.bindPopup(${JSON.stringify(title)});` : ''}
    
    ${interactive ? `
    marker.on('dragend', function(e) {
      const pos = e.target.getLatLng();
      if (window.ReactNativeWebView) {
        window.ReactNativeWebView.postMessage(JSON.stringify({
          type: 'move',
          lat: pos.lat,
          lng: pos.lng
        }));
      }
    });
    ` : ''}
    ` : ''}

    ${interactive ? `
    map.on('click', function(e) {
      if (window.ReactNativeWebView) {
        window.ReactNativeWebView.postMessage(JSON.stringify({
          type: 'click',
          lat: e.latlng.lat,
          lng: e.latlng.lng
        }));
      }
    });
    ` : ''}
  </script>
</body>
</html>`;
}
