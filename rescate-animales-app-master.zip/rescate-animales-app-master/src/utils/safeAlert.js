import { Alert } from 'react-native';

/**
 * Safe Alert wrapper that prevents crashes
 * @param {string} title - Alert title
 * @param {string} message - Alert message
 * @param {Array} buttons - Optional buttons array
 */
export const safeAlert = (title, message, buttons) => {
    try {
        Alert.alert(title, message, buttons);
    } catch (error) {
        console.error('[safeAlert] Error showing alert:', error);
        console.log('[safeAlert] Title:', title);
        console.log('[safeAlert] Message:', message);
    }
};

export default safeAlert;
