import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system';

const PENDING_REPORTS_KEY = '@pending_reports';
const CACHED_CENTERS_KEY = '@cached_centers';
const CACHED_FORM_DATA_KEY = '@cached_form_data';

/**
 * Save a report to offline storage
 */
export async function savePendingReport(reportData) {
    try {
        const pending = await getPendingReports();
        const fp = computeReportFingerprint(reportData || {});
        const newReport = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            data: { ...reportData, fingerprint: fp },
            synced: false,
            uploading: false
        };

        // Convert image to base64 if present
        if (reportData.imagen?.uri) {
            try {
                const base64 = await FileSystem.readAsStringAsync(reportData.imagen.uri, {
                    encoding: FileSystem.EncodingType.Base64
                });
                newReport.data.imagen = {
                    ...reportData.imagen,
                    base64
                };
            } catch (e) {
                console.log('Error converting image to base64:', e);
            }
        }

        pending.push(newReport);
        await AsyncStorage.setItem(PENDING_REPORTS_KEY, JSON.stringify(pending));
        return newReport;
    } catch (e) {
        console.error('Error saving pending report:', e);
        throw e;
    }
}

/**
 * Get all pending reports
 */
export async function getPendingReports() {
    try {
        const data = await AsyncStorage.getItem(PENDING_REPORTS_KEY);
        return data ? JSON.parse(data) : [];
    } catch (e) {
        console.error('Error getting pending reports:', e);
        return [];
    }
}

/**
 * Remove a pending report by ID
 */
export async function removePendingReport(id) {
    try {
        console.log('[offlineStorage] removePendingReport called with id:', id);
        const pending = await getPendingReports();
        console.log('[offlineStorage] Current pending reports count:', pending.length);
        console.log('[offlineStorage] Pending report IDs:', pending.map(r => r.id));

        const filtered = pending.filter(r => r.id !== id);
        console.log('[offlineStorage] After filter, remaining reports:', filtered.length);

        await AsyncStorage.setItem(PENDING_REPORTS_KEY, JSON.stringify(filtered));
        console.log('[offlineStorage] Successfully removed report:', id);

        // Verify it was actually removed
        const verify = await getPendingReports();
        console.log('[offlineStorage] Verification - remaining reports:', verify.length);

        return true;
    } catch (e) {
        console.error('[offlineStorage] Error removing pending report:', e);
        return false;
    }
}

/**
 * Mark a report as synced
 */
export async function markReportSynced(id) {
    try {
        const pending = await getPendingReports();
        const updated = pending.map(r =>
            r.id === id ? { ...r, synced: true, syncedAt: new Date().toISOString() } : r
        );
        await AsyncStorage.setItem(PENDING_REPORTS_KEY, JSON.stringify(updated));
        return true;
    } catch (e) {
        console.error('Error marking report as synced:', e);
        return false;
    }
}

/**
 * Clear all synced reports
 */
export async function clearSyncedReports() {
    try {
        const pending = await getPendingReports();
        const unsynced = pending.filter(r => !r.synced);
        await AsyncStorage.setItem(PENDING_REPORTS_KEY, JSON.stringify(unsynced));
        return true;
    } catch (e) {
        console.error('Error clearing synced reports:', e);
        return false;
    }
}

export async function markReportUploading(id, uploading) {
    try {
        const pending = await getPendingReports();
        const updated = pending.map(r =>
            r.id === id ? { ...r, uploading: !!uploading } : r
        );
        await AsyncStorage.setItem(PENDING_REPORTS_KEY, JSON.stringify(updated));
        return true;
    } catch (e) {
        return false;
    }
}

export async function getUnsyncedReports() {
    try {
        const pending = await getPendingReports();
        return pending.filter(r => !r.synced);
    } catch (e) {
        return [];
    }
}

export function computeReportFingerprint(data) {
    const pid = data?.persona_id != null ? String(data.persona_id) : '';
    const lat = data?.latitud != null ? String(Number(data.latitud).toFixed(5)) : '';
    const lng = data?.longitud != null ? String(Number(data.longitud).toFixed(5)) : '';
    const tam = data?.tamano != null ? String(data.tamano) : '';
    const cond = data?.condicion_inicial_id != null ? String(data.condicion_inicial_id) : '';
    const inc = data?.tipo_incidente_id != null ? String(data.tipo_incidente_id) : '';
    const obs = data?.observaciones != null ? String(data.observaciones).trim() : '';
    return [pid, lat, lng, tam, cond, inc, obs].join('|');
}

/**
 * Get count of pending reports
 */
export async function getPendingReportsCount() {
    try {
        const pending = await getPendingReports();
        return pending.filter(r => !r.synced).length;
    } catch (e) {
        console.error('Error getting pending reports count:', e);
        return 0;
    }
}

/**
 * Cache rescue centers for offline use
 */
export async function cacheCenters(centers) {
    try {
        const cacheData = {
            centers: centers,
            timestamp: new Date().toISOString()
        };
        await AsyncStorage.setItem(CACHED_CENTERS_KEY, JSON.stringify(cacheData));
        console.log('Centers cached successfully:', centers.length);
        return true;
    } catch (e) {
        console.error('Error caching centers:', e);
        return false;
    }
}

/**
 * Get cached rescue centers
 */
export async function getCachedCenters() {
    try {
        const data = await AsyncStorage.getItem(CACHED_CENTERS_KEY);
        if (!data) return null;

        const cacheData = JSON.parse(data);
        console.log('Retrieved cached centers:', cacheData.centers?.length || 0);
        return cacheData.centers || [];
    } catch (e) {
        console.error('Error getting cached centers:', e);
        return null;
    }
}

/**
 * Clear cached centers
 */
export async function clearCachedCenters() {
    try {
        await AsyncStorage.removeItem(CACHED_CENTERS_KEY);
        return true;
    } catch (e) {
        console.error('Error clearing cached centers:', e);
        return false;
    }
}

/**
 * Cache form data (conditions, incidents, etc)
 */
export async function cacheFormData(key, data) {
    try {
        const currentRaw = await AsyncStorage.getItem(CACHED_FORM_DATA_KEY);
        const current = currentRaw ? JSON.parse(currentRaw) : {};
        current[key] = {
            data,
            timestamp: new Date().toISOString()
        };
        await AsyncStorage.setItem(CACHED_FORM_DATA_KEY, JSON.stringify(current));
        return true;
    } catch (e) {
        console.error('Error caching form data:', e);
        return false;
    }
}

/**
 * Get cached form data
 */
export async function getCachedFormData(key) {
    try {
        const raw = await AsyncStorage.getItem(CACHED_FORM_DATA_KEY);
        if (!raw) return null;
        const current = JSON.parse(raw);
        return current[key]?.data || null;
    } catch (e) {
        console.error('Error getting cached form data:', e);
        return null;
    }
}

