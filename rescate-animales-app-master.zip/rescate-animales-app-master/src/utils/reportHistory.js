import AsyncStorage from '@react-native-async-storage/async-storage';

const REPORT_HISTORY_KEY = '@report_history';
const MAX_HISTORY_ITEMS = 100;

/**
 * Save a report to history after creation
 */
export async function saveReportToHistory(reportData) {
    try {
        const history = await getReportHistory();

        const newEntry = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            data: reportData,
            status: reportData.uploadedSuccessfully ? 'uploaded' : 'pending'
        };

        // Add to beginning and keep only MAX_HISTORY_ITEMS
        const updated = [newEntry, ...history].slice(0, MAX_HISTORY_ITEMS);

        await AsyncStorage.setItem(REPORT_HISTORY_KEY, JSON.stringify(updated));
        console.log('[ReportHistory] Saved report to history:', newEntry.id);

        return newEntry;
    } catch (e) {
        console.error('[ReportHistory] Error saving to history:', e);
        throw e;
    }
}

/**
 * Get all report history
 */
export async function getReportHistory() {
    try {
        const data = await AsyncStorage.getItem(REPORT_HISTORY_KEY);
        return data ? JSON.parse(data) : [];
    } catch (e) {
        console.error('[ReportHistory] Error getting history:', e);
        return [];
    }
}

/**
 * Clear all report history
 */
export async function clearReportHistory() {
    try {
        await AsyncStorage.removeItem(REPORT_HISTORY_KEY);
        console.log('[ReportHistory] History cleared');
    } catch (e) {
        console.error('[ReportHistory] Error clearing history:', e);
        throw e;
    }
}

/**
 * Get history count
 */
export async function getReportHistoryCount() {
    try {
        const history = await getReportHistory();
        return history.length;
    } catch (e) {
        return 0;
    }
}

/**
 * Update status of a history item
 */
export async function updateHistoryStatus(id, newStatus) {
    try {
        const history = await getReportHistory();
        const updated = history.map(item =>
            item.id === id ? { ...item, status: newStatus } : item
        );
        await AsyncStorage.setItem(REPORT_HISTORY_KEY, JSON.stringify(updated));
        console.log('[ReportHistory] Updated status for:', id, 'to', newStatus);
    } catch (e) {
        console.error('[ReportHistory] Error updating status:', e);
    }
}
