const AsyncStorage = require('@react-native-async-storage/async-storage').default;
const { savePendingReport, getPendingReports, removePendingReport } = require('../offlineStorage');

// Mock AsyncStorage
jest.mock('@react-native-async-storage/async-storage');

describe('offlineStorage', () => {
    beforeEach(() => {
        // Clear all mocks before each test
        jest.clearAllMocks();
    });

    describe('savePendingReport', () => {
        it('should save report with generated ID and timestamp', async () => {
            AsyncStorage.getItem.mockResolvedValue(null);

            const reportData = {
                latitud: -17.783,
                longitud: -63.182,
                tamano: 'mediano',
                observaciones: 'Test report'
            };

            const result = await savePendingReport(reportData);

            expect(result).toHaveProperty('id');
            expect(result).toHaveProperty('timestamp');
            expect(result.data).toEqual(reportData);
            expect(result.synced).toBe(false);
            expect(AsyncStorage.setItem).toHaveBeenCalled();
        });

        it('should convert image to base64 if present', async () => {
            AsyncStorage.getItem.mockResolvedValue(null);

            const reportData = {
                latitud: -17.783,
                longitud: -63.182,
                imagen: {
                    uri: 'file:///path/to/image.jpg',
                    type: 'image/jpeg'
                }
            };

            // Mock FileSystem
            const mockFileSystem = require('expo-file-system');
            mockFileSystem.readAsStringAsync = jest.fn().mockResolvedValue('base64string');

            await savePendingReport(reportData);

            expect(AsyncStorage.setItem).toHaveBeenCalled();
        });

        it('should add to existing reports', async () => {
            const existingReports = [
                { id: '1', data: { tamano: 'pequeño' } }
            ];
            AsyncStorage.getItem.mockResolvedValue(JSON.stringify(existingReports));

            await savePendingReport({ tamano: 'grande' });

            const savedData = JSON.parse(AsyncStorage.setItem.mock.calls[0][1]);
            expect(savedData).toHaveLength(2);
        });
    });

    describe('getPendingReports', () => {
        it('should return empty array when no reports exist', async () => {
            AsyncStorage.getItem.mockResolvedValue(null);

            const reports = await getPendingReports();

            expect(reports).toEqual([]);
        });

        it('should return parsed reports from storage', async () => {
            const mockReports = [
                { id: '1', data: { tamano: 'mediano' }, synced: false },
                { id: '2', data: { tamano: 'grande' }, synced: false }
            ];
            AsyncStorage.getItem.mockResolvedValue(JSON.stringify(mockReports));

            const reports = await getPendingReports();

            expect(reports).toEqual(mockReports);
            expect(reports).toHaveLength(2);
        });

        it('should handle corrupted data gracefully', async () => {
            AsyncStorage.getItem.mockResolvedValue('invalid json');

            const reports = await getPendingReports();

            expect(reports).toEqual([]);
        });
    });

    describe('removePendingReport', () => {
        it('should remove report by ID', async () => {
            const mockReports = [
                { id: '1', data: { tamano: 'pequeño' } },
                { id: '2', data: { tamano: 'mediano' } },
                { id: '3', data: { tamano: 'grande' } }
            ];
            AsyncStorage.getItem.mockResolvedValue(JSON.stringify(mockReports));

            const result = await removePendingReport('2');

            expect(result).toBe(true);
            const savedData = JSON.parse(AsyncStorage.setItem.mock.calls[0][1]);
            expect(savedData).toHaveLength(2);
            expect(savedData.find(r => r.id === '2')).toBeUndefined();
            expect(savedData.find(r => r.id === '1')).toBeDefined();
            expect(savedData.find(r => r.id === '3')).toBeDefined();
        });

        it('should return true even if report not found', async () => {
            AsyncStorage.getItem.mockResolvedValue(JSON.stringify([]));

            const result = await removePendingReport('nonexistent');

            expect(result).toBe(true);
        });

        it('should return false on error', async () => {
            AsyncStorage.getItem.mockRejectedValue(new Error('Storage error'));

            const result = await removePendingReport('1');

            expect(result).toBe(false);
        });
    });

    describe('getUnsyncedReports', () => {
        it('should return only unsynced reports', async () => {
            const mockReports = [
                { id: '1', synced: false },
                { id: '2', synced: true },
                { id: '3', synced: false }
            ];
            AsyncStorage.getItem.mockResolvedValue(JSON.stringify(mockReports));

            const { getUnsyncedReports } = require('../offlineStorage');
            const unsynced = await getUnsyncedReports();

            expect(unsynced).toHaveLength(2);
            expect(unsynced.every(r => !r.synced)).toBe(true);
        });
    });
});
