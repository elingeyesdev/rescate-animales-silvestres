const AsyncStorage = require('@react-native-async-storage/async-storage').default;
const { saveReportToHistory, getReportHistory, clearReportHistory, updateHistoryStatus } = require('../reportHistory');

jest.mock('@react-native-async-storage/async-storage');

describe('reportHistory', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    describe('saveReportToHistory', () => {
        it('should save report with status based on uploadedSuccessfully flag', async () => {
            AsyncStorage.getItem.mockResolvedValue(null);

            const reportData = {
                latitud: -17.783,
                longitud: -63.182,
                uploadedSuccessfully: true
            };

            const result = await saveReportToHistory(reportData);

            expect(result.status).toBe('uploaded');
            expect(result).toHaveProperty('id');
            expect(result).toHaveProperty('timestamp');
            expect(AsyncStorage.setItem).toHaveBeenCalled();
        });

        it('should set status to pending if not uploaded', async () => {
            AsyncStorage.getItem.mockResolvedValue(null);

            const reportData = {
                latitud: -17.783,
                uploadedSuccessfully: false
            };

            const result = await saveReportToHistory(reportData);

            expect(result.status).toBe('pending');
        });

        it('should limit history to MAX_HISTORY_ITEMS (100)', async () => {
            // Create 100 existing items
            const existingHistory = Array.from({ length: 100 }, (_, i) => ({
                id: String(i),
                timestamp: new Date().toISOString(),
                data: {},
                status: 'uploaded'
            }));
            AsyncStorage.getItem.mockResolvedValue(JSON.stringify(existingHistory));

            await saveReportToHistory({ test: true });

            const savedData = JSON.parse(AsyncStorage.setItem.mock.calls[0][1]);
            expect(savedData).toHaveLength(100); // Still 100, oldest removed
        });

        it('should add new items to the beginning of array', async () => {
            const existingHistory = [
                { id: '1', timestamp: '2024-01-01T00:00:00Z' }
            ];
            AsyncStorage.getItem.mockResolvedValue(JSON.stringify(existingHistory));

            const result = await saveReportToHistory({ test: true });

            const savedData = JSON.parse(AsyncStorage.setItem.mock.calls[0][1]);
            expect(savedData[0].id).toBe(result.id); // New item first
            expect(savedData[1].id).toBe('1'); // Old item second
        });
    });

    describe('getReportHistory', () => {
        it('should return empty array when no history', async () => {
            AsyncStorage.getItem.mockResolvedValue(null);

            const history = await getReportHistory();

            expect(history).toEqual([]);
        });

        it('should return parsed history', async () => {
            const mockHistory = [
                { id: '1', status: 'uploaded' },
                { id: '2', status: 'pending' }
            ];
            AsyncStorage.getItem.mockResolvedValue(JSON.stringify(mockHistory));

            const history = await getReportHistory();

            expect(history).toEqual(mockHistory);
        });

        it('should handle errors gracefully', async () => {
            AsyncStorage.getItem.mockRejectedValue(new Error('Storage error'));

            const history = await getReportHistory();

            expect(history).toEqual([]);
        });
    });

    describe('clearReportHistory', () => {
        it('should remove history from storage', async () => {
            await clearReportHistory();

            expect(AsyncStorage.removeItem).toHaveBeenCalledWith('@report_history');
        });

        it('should not throw on error', async () => {
            AsyncStorage.removeItem.mockRejectedValue(new Error('Storage error'));

            await expect(clearReportHistory()).resolves.not.toThrow();
        });
    });

    describe('updateHistoryStatus', () => {
        it('should update status of specific item', async () => {
            const mockHistory = [
                { id: '1', status: 'pending' },
                { id: '2', status: 'pending' }
            ];
            AsyncStorage.getItem.mockResolvedValue(JSON.stringify(mockHistory));

            await updateHistoryStatus('1', 'uploaded');

            const savedData = JSON.parse(AsyncStorage.setItem.mock.calls[0][1]);
            expect(savedData[0].status).toBe('uploaded');
            expect(savedData[1].status).toBe('pending');
        });

        it('should not modify other items', async () => {
            const mockHistory = [
                { id: '1', status: 'pending', data: { test: 1 } },
                { id: '2', status: 'uploaded', data: { test: 2 } }
            ];
            AsyncStorage.getItem.mockResolvedValue(JSON.stringify(mockHistory));

            await updateHistoryStatus('1', 'uploaded');

            const savedData = JSON.parse(AsyncStorage.setItem.mock.calls[0][1]);
            expect(savedData[0].data).toEqual({ test: 1 });
            expect(savedData[1].data).toEqual({ test: 2 });
        });
    });

    describe('getReportHistoryCount', () => {
        it('should return count of history items', async () => {
            const mockHistory = [{ id: '1' }, { id: '2' }, { id: '3' }];
            AsyncStorage.getItem.mockResolvedValue(JSON.stringify(mockHistory));

            const { getReportHistoryCount } = require('../reportHistory');
            const count = await getReportHistoryCount();

            expect(count).toBe(3);
        });

        it('should return 0 on error', async () => {
            AsyncStorage.getItem.mockRejectedValue(new Error('Error'));

            const { getReportHistoryCount } = require('../reportHistory');
            const count = await getReportHistoryCount();

            expect(count).toBe(0);
        });
    });
});
