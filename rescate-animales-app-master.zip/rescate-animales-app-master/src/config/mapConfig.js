export const MAP_CONFIG = {
    santaCruz: {
        center: [-17.783, -63.182],
        bounds: [
            [-17.85, -63.25], // southwest
            [-17.7, -63.05]   // northeast
        ],
        zoom: {
            min: 11,
            max: 16,
            default: 13
        }
    },
    // Offline tile configuration
    // Tiles should be placed in assets/map-tiles/{z}/{x}/{y}.png
    offlineTiles: {
        enabled: true,
        // Path will be resolved based on platform
        urlTemplate: 'map-tiles/{z}/{x}/{y}.png',
        maxZoom: 16,
        minZoom: 11
    },
    // Fallback to online tiles if offline fails
    onlineTiles: {
        urlTemplate: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        maxZoom: 19,
        attribution: '© OpenStreetMap contributors'
    }
};

/**
 * Get tile URL for platform
 */
export function getTileUrl(platform = 'android') {
    if (MAP_CONFIG.offlineTiles.enabled) {
        // For Expo/React Native, we'll use a custom approach
        // The tiles will be served through the app's asset system
        return MAP_CONFIG.offlineTiles.urlTemplate;
    }
    return MAP_CONFIG.onlineTiles.urlTemplate;
}

/**
 * Check if coordinates are within Santa Cruz bounds
 */
export function isWithinSantaCruz(lat, lng) {
    const [[swLat, swLng], [neLat, neLng]] = MAP_CONFIG.santaCruz.bounds;
    return lat >= swLat && lat <= neLat && lng >= swLng && lng <= neLng;
}
