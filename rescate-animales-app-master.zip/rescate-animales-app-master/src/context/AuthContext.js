import React, { createContext, useContext, useEffect, useState } from 'react';
import apiClient, { API_BASE_URL, getCurrentUser, pingServer } from '../api/client';
import { clearToken, getToken, storeToken, storeCachedUser, getCachedUser, clearCachedUser, getRememberedCredentials } from '../api/tokenStore';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [roles, setRoles] = useState([]);
  const [permissions, setPermissions] = useState([]);
  const [highestRole, setHighestRole] = useState(null);
  const [loading, setLoading] = useState(true);
  const [offlineMode, setOfflineMode] = useState(false);

  // Cargar token inicial desde AsyncStorage
  useEffect(() => {
    const loadToken = async () => {
      try {
        const storedToken = await getToken();
        if (storedToken) {
          setToken(storedToken);
          try {
            const u = await getCurrentUser();
            setUser(u);
            const r = Array.isArray(u?.roles) ? u.roles : (Array.isArray(u?.data?.roles) ? u.data.roles : []);
            const p = Array.isArray(u?.permissions) ? u.permissions : (Array.isArray(u?.data?.permissions) ? u.data.permissions : []);
            const hr = u?.highest_role || u?.data?.highest_role || null;
            setRoles(r || []);
            setPermissions(p || []);
            setHighestRole(hr || null);

            if ((!r || r.length === 0) && u?.id) {
              try {
                const r2 = await apiClient.get(`/users/${u.id}`).catch(() => ({ data: {} }));
                const roles2 = Array.isArray(r2?.data?.roles) ? r2.data.roles : [];
                const perms2 = Array.isArray(r2?.data?.permissions) ? r2.data.permissions : [];
                const hr2 = r2?.data?.highest_role || null;
                setRoles(roles2 || []);
                setPermissions(perms2 || []);
                setHighestRole(hr2 || null);
              } catch {}
            }
          } catch (e) {
            const cached = await getCachedUser();
            if (cached) {
              setUser(cached);
              const r = Array.isArray(cached?.roles) ? cached.roles : [];
              const p = Array.isArray(cached?.permissions) ? cached.permissions : [];
              const hr = cached?.highest_role || null;
              setRoles(r);
              setPermissions(p);
              setHighestRole(hr);
              setOfflineMode(true);
            } else {
              setOfflineMode(true);
            }
          }
        }
      } finally {
        setLoading(false);
      }
    };
    loadToken();
  }, []);

  const login = async ({ email, password }) => {
    try {
      const response = await apiClient.post('/login', { email, password });
      const { token: apiToken, user: apiUser } = response.data;
      await storeToken(apiToken);
      await storeCachedUser(apiUser);
      setToken(apiToken);

      try {
        const u = await getCurrentUser();
        setUser(u || apiUser);
        const r = Array.isArray(u?.roles) ? u.roles : (Array.isArray(u?.data?.roles) ? u.data.roles : []);
        const p = Array.isArray(u?.permissions) ? u.permissions : (Array.isArray(u?.data?.permissions) ? u.data.permissions : []);
        const hr = u?.highest_role || u?.data?.highest_role || null;
        setRoles(r || []);
        setPermissions(p || []);
        setHighestRole(hr || null);
        if ((!r || r.length === 0) && (u?.id || apiUser?.id)) {
          try {
            const uid = u?.id || apiUser?.id;
            const r2 = await apiClient.get(`/users/${uid}`).catch(() => ({ data: {} }));
            const roles2 = Array.isArray(r2?.data?.roles) ? r2.data.roles : [];
            const perms2 = Array.isArray(r2?.data?.permissions) ? r2.data.permissions : [];
            const hr2 = r2?.data?.highest_role || null;
            setRoles(roles2 || []);
            setPermissions(perms2 || []);
            setHighestRole(hr2 || null);
          } catch {}
        }
      } catch {
        setUser(apiUser);
        const r = Array.isArray(apiUser?.roles) ? apiUser.roles : [];
        const p = Array.isArray(apiUser?.permissions) ? apiUser.permissions : [];
        const hr = apiUser?.highest_role || null;
        setRoles(r || []);
        setPermissions(p || []);
        setHighestRole(hr || null);
      }
      return apiUser;
    } catch (e1) {
      const base = API_BASE_URL;
      const appBase = base.endsWith('/api') ? base.slice(0, -4) : base;
      try {
        const alt = await fetch(`${appBase}/api/login`, {
          method: 'POST',
          headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password }),
        });
        if (!alt.ok) {
          throw new Error(`HTTP ${alt.status}`);
        }
        const data = await alt.json();
        const apiToken = data?.token;
        const apiUser = data?.user;
        await storeToken(apiToken);
        await storeCachedUser(apiUser);
        setToken(apiToken);
        setUser(apiUser);
        setRoles(Array.isArray(data?.roles) ? data.roles : (Array.isArray(apiUser?.roles) ? apiUser.roles : []));
        setPermissions(Array.isArray(data?.permissions) ? data.permissions : (Array.isArray(apiUser?.permissions) ? apiUser.permissions : []));
        setHighestRole(data?.highest_role || apiUser?.highest_role || null);
        return apiUser;
      } catch (e2) {
        try {
          const alt2 = await fetch(`${appBase}/login`, {
            method: 'POST',
            headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password }),
          });
          if (!alt2.ok) {
            throw new Error(`HTTP ${alt2.status}`);
          }
          const data2 = await alt2.json();
          const apiToken2 = data2?.token;
          const apiUser2 = data2?.user;
        await storeToken(apiToken2);
        await storeCachedUser(apiUser2);
          setToken(apiToken2);
          setUser(apiUser2);
          setRoles(Array.isArray(data2?.roles) ? data2.roles : (Array.isArray(apiUser2?.roles) ? apiUser2.roles : []));
          setPermissions(Array.isArray(data2?.permissions) ? data2.permissions : (Array.isArray(apiUser2?.permissions) ? apiUser2.permissions : []));
          setHighestRole(data2?.highest_role || apiUser2?.highest_role || null);
          return apiUser2;
        } catch (e3) {
          throw e1;
        }
      }
      }
  };

  const loginOffline = async ({ email }) => {
    const cached = await getCachedUser();
    if (cached) {
      setUser(cached);
      const r = Array.isArray(cached?.roles) ? cached.roles : [];
      const p = Array.isArray(cached?.permissions) ? cached.permissions : [];
      const hr = cached?.highest_role || null;
      setRoles(r);
      setPermissions(p);
      setHighestRole(hr);
    } else {
      setUser({ email, roles: [], permissions: [] });
      setRoles([]);
      setPermissions([]);
      setHighestRole(null);
    }
    setOfflineMode(true);
    return true;
  };

  const retryConnection = async () => {
    try {
      const ok = await pingServer();
      if (!ok) {
        return false;
      }
      setOfflineMode(false);
      try {
        const existingToken = await getToken();
        if (!existingToken) {
          const creds = await getRememberedCredentials();
          if (creds?.rememberMe && creds?.email && creds?.password) {
            try { await login({ email: creds.email, password: creds.password }); } catch {}
          }
        }
        const u = await getCurrentUser().catch(() => null);
        if (u) {
          setUser(u || user);
          const r = Array.isArray(u?.roles) ? u.roles : (Array.isArray(u?.data?.roles) ? u.data.roles : []);
          const p = Array.isArray(u?.permissions) ? u.permissions : (Array.isArray(u?.data?.permissions) ? u.data.permissions : []);
          const hr = u?.highest_role || u?.data?.highest_role || null;
          setRoles(r || []);
          setPermissions(p || []);
          setHighestRole(hr || null);
        }
      } catch {}
      return true;
    } catch {
      return false;
    }
  };

  const register = async ({ email, password, nombre, ci, telefono, es_cuidador = false }) => {
    const response = await apiClient.post('/users', {
      email,
      password,
      nombre,
      ci,
      telefono,
      es_cuidador,
    });
    return response.data;
  };

  const logout = async () => {
    setUser(null);
    setToken(null);
    setRoles([]);
    setPermissions([]);
    setHighestRole(null);
    setOfflineMode(false);
    await clearToken();
    await clearCachedUser();
    // Si tu API tiene endpoint /logout, podrías llamarlo aquí.
  };

  const hasRole = (allowed = []) => {
    const set = Array.isArray(roles) ? roles : [];
    const arr = Array.isArray(allowed) ? allowed : [allowed];
    return set.some((r) => arr.includes(r));
  };
  const hasPermission = (allowed = []) => {
    const set = Array.isArray(permissions) ? permissions : [];
    const arr = Array.isArray(allowed) ? allowed : [allowed];
    return set.some((p) => arr.includes(p));
  };

  const value = {
    user,
    token,
    roles,
    permissions,
    highestRole,
    loading,
    isAuthenticated: !!token || offlineMode,
    offlineMode,
    login,
    loginOffline,
    retryConnection,
    register,
    logout,
    hasRole,
    hasPermission,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth debe usarse dentro de un AuthProvider');
  }
  return ctx;
};
