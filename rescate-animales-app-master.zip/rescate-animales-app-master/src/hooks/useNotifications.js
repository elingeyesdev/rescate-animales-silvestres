import { useState, useEffect, useRef } from 'react';
import { Platform } from 'react-native';
import * as Device from 'expo-device';
import * as Notifications from 'expo-notifications';
import Constants from 'expo-constants';
import apiClient from '../api/client';

// 1. Configuración global: Cómo se muestran las notificaciones cuando la app está ABIERTA
try {
  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowAlert: true, // Mostrar alerta visual
      shouldPlaySound: true, // Reproducir sonido
      shouldSetBadge: false,
    }),
  });
} catch (error) {
  if (error?.message?.includes('Expo Go')) {
    console.log('Notificaciones push deshabilitadas en Expo Go');
  } else {
    console.error('Error configurando handler de notificaciones:', error);
  }
}

export const useNotifications = () => {
  const [expoPushToken, setExpoPushToken] = useState('');
  const [notification, setNotification] = useState(false);
  const notificationListener = useRef();
  const responseListener = useRef();

  useEffect(() => {
    // A. Registrar y obtener el token
    registerForPushNotificationsAsync().then(token => {
      setExpoPushToken(token);
    });

    // B. Listener: Cuando llega una notificación y la app está ABIERTA
    try {
      notificationListener.current = Notifications.addNotificationReceivedListener(notification => {
        setNotification(notification);
        console.log('Notificación recibida en primer plano:', notification);
      });

      // C. Listener: Cuando el usuario TOCA la notificación (y la app se abre)
      responseListener.current = Notifications.addNotificationResponseReceivedListener(response => {
        const data = response.notification.request.content.data;
        console.log('Usuario tocó la notificación. Datos:', data);
        
        // D. Lógica de Navegación
        // El backend envía: data: { screen: 'ReportDetail', report_id: 123 }
        // Esta lógica debe ser manejada preferiblemente donde tengas acceso al objeto 'navigation'
        // o usando una referencia de navegación global si está disponible.
      });
    } catch (e) {
      console.log('Error setting up notification listeners (probably Expo Go):', e);
    }

    return () => {
      if (notificationListener.current) {
        try { notificationListener.current.remove(); } catch {}
      }
      if (responseListener.current) {
        try { responseListener.current.remove(); } catch {}
      }
    };
  }, []);

  // Función de prueba local
  const testNotification = async () => {
    try {
      await Notifications.scheduleNotificationAsync({
        content: {
          title: "🔔 ¡Prueba exitosa!",
          body: "El sistema de notificaciones está funcionando correctamente.",
          data: { data: 'goes here' },
        },
        trigger: null, // null significa "mostrar inmediatamente"
      });
      console.log("Notificación de prueba enviada");
    } catch (error) {
      console.error("Error al programar notificación de prueba:", error);
      alert("Error al mostrar notificación: " + error.message);
    }
  };

  return { expoPushToken, notification, testNotification };
};

// Función auxiliar para permisos
async function registerForPushNotificationsAsync() {
  let token;

  if (Platform.OS === 'android') {
    try {
      await Notifications.setNotificationChannelAsync('default', {
        name: 'default',
        importance: Notifications.AndroidImportance.MAX,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: '#FF231F7C',
      });
    } catch (e) {
      console.log('Advertencia: No se pudo configurar el canal de notificaciones:', e);
    }
  }

  // Solicitar permisos (tanto en Dispositivo real como en Simulador para notificaciones locales)
  try {
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;
    
    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }
    
    if (finalStatus !== 'granted') {
      console.log('¡Faltan permisos para notificaciones!');
      alert('Se requieren permisos para mostrar notificaciones.');
      return null;
    }
  } catch (e) {
    console.error('Error solicitando permisos:', e);
    return null;
  }

  // MODO LOCAL SOLAMENTE: No generamos tokens Push de Expo
  console.log('Modo notificaciones locales: Permisos concedidos. No se generará token Push.');
  return null;
}

/**
 * (Desactivado) Envía el token al backend
 * @param {string} token 
 */
export async function sendPushTokenToBackend(token) {
  // Desactivado por solicitud: "sin tener tokens ni nada"
  return;
}
