import { useEffect, useRef } from 'react';

/**
 * Hook to track if component is mounted
 * Prevents memory leaks from setState on unmounted components
 * 
 * Usage:
 * const isMounted = useIsMounted();
 * 
 * useEffect(() => {
 *   fetchData().then(data => {
 *     if (isMounted.current) {
 *       setData(data);
 *     }
 *   });
 * }, []);
 */
export function useIsMounted() {
    const isMounted = useRef(true);

    useEffect(() => {
        return () => {
            isMounted.current = false;
        };
    }, []);

    return isMounted;
}

export default useIsMounted;
