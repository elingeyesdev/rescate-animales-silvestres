import { useState, useEffect, useRef } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Notifications from 'expo-notifications';
import { listReports } from '../api/reports';
import { useAuth } from '../context/AuthContext';

const NOTIFIED_REPORTS_KEY = 'notified_reports_ids';
const POLLING_INTERVAL_MS = 5000; // Consultar cada 5 segundos

export const useReportStatusPolling = () => {
  const { user } = useAuth();
  const [isPolling, setIsPolling] = useState(false);
  const intervalRef = useRef(null);

  useEffect(() => {
    // Solo hacer polling si hay usuario logueado
    if (!user) {
      stopPolling();
      return;
    }

    startPolling();

    return () => stopPolling();
  }, [user]);

  const startPolling = () => {
    if (intervalRef.current) return;
    
    // Ejecutar inmediatamente
    checkReportsStatus();
    
    // Y luego cada X tiempo
    intervalRef.current = setInterval(checkReportsStatus, POLLING_INTERVAL_MS);
    setIsPolling(true);
    console.log('🔄 Polling de estado de reportes iniciado...');
  };

  const stopPolling = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setIsPolling(false);
  };

  const checkReportsStatus = async () => {
    try {
      // 1. Obtener reportes del usuario (el backend filtra por usuario usualmente)
      // Si el backend no filtra, quizás necesitemos pasar user_id
      const reports = await listReports({ sort: 'created_at', order: 'desc', per_page: 20 });
      
      if (!reports || reports.length === 0) return;

      // 2. Obtener lista de IDs ya notificados
      const notifiedJson = await AsyncStorage.getItem(NOTIFIED_REPORTS_KEY);
      const notifiedIds = notifiedJson ? JSON.parse(notifiedJson) : [];
      const notifiedSet = new Set(notifiedIds);
      
      let newNotifiedIds = [...notifiedIds];
      let hasChanges = false;

      // 3. Buscar reportes aprobados que NO hayan sido notificados
      for (const report of reports) {
        // Asumimos que el campo es 'aprobado' (booleano o 1/0)
        // O podría ser 'estado' === 'aprobado'
        const isApproved = report.aprobado === true || report.aprobado === 1 || report.aprobado === '1';
        
        if (isApproved && !notifiedSet.has(report.id)) {
          // 4. Notificar!
          await sendLocalNotification(report);
          
          // Marcar como notificado
          newNotifiedIds.push(report.id);
          notifiedSet.add(report.id);
          hasChanges = true;
        }
      }

      // 5. Guardar actualización
      if (hasChanges) {
        await AsyncStorage.setItem(NOTIFIED_REPORTS_KEY, JSON.stringify(newNotifiedIds));
      }

    } catch (error) {
      // Silencioso para no molestar al usuario, solo log
      console.log('Error en polling de reportes:', error.message);
    }
  };

  const sendLocalNotification = async (report) => {
    try {
      await Notifications.scheduleNotificationAsync({
        content: {
          title: "✅ ¡Hallazgo Aprobado!",
          body: `Tu reporte de hallazgo #${report.id} ha sido aprobado por el sistema.`,
          data: { reportId: report.id, screen: 'History' },
        },
        trigger: null,
      });
      console.log(`🔔 Notificación enviada para reporte ${report.id}`);
    } catch (error) {
      console.error('Error enviando notificación local:', error);
    }
  };

  return { isPolling, checkReportsStatus };
};
