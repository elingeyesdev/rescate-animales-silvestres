import { View, Text, Pressable } from 'react-native';
import { WebView } from 'react-native-webview';
import * as Location from 'expo-location';
import { colors } from '../theme/colors';
import { useRef } from 'react';

export default function CentersMap({ centers = [], selectedId, onSelect, userLat, userLng, height = 220 }) {
  const lat0 = userLat != null ? Number(userLat) : -17.7833;
  const lng0 = userLng != null ? Number(userLng) : -63.1821;
  const points = (Array.isArray(centers) ? centers : [])
    .map((c) => {
      const lat = Number(c.latitud);
      const lng = Number(c.longitud);
      if (!isFinite(lat) || !isFinite(lng)) return null;
      return { id: c.id, nombre: c.nombre, direccion: c.direccion, lat, lng };
    })
    .filter(Boolean);
  const html = `<!DOCTYPE html><html><head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <style>html,body,#map{height:100%;margin:0;padding:0}</style>
  </head><body>
    <div id="map"></div>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script>
      const map=L.map('map', {zoomControl: true, attributionControl: false}).setView([${lat0},${lng0}], ${points.length > 0 ? 13 : 12});
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19, attribution: ''}).addTo(map);
      const pts = ${JSON.stringify(points)};
      const selectedId = ${selectedId != null ? selectedId : 'null'};
      const markers = {};
      
      pts.forEach((c)=>{
        const m=L.marker([c.lat,c.lng]).addTo(map).bindPopup(c.nombre||('Centro '+c.id));
        markers[c.id] = m;
        m.on('click',()=>{
          const msg={ id:c.id, nombre:c.nombre, direccion:c.direccion, lat:c.lat, lng:c.lng };
          window.ReactNativeWebView && window.ReactNativeWebView.postMessage(JSON.stringify(msg));
        });
      });
      
      // Focus on selected center
      if (selectedId !== null && markers[selectedId]) {
        const center = pts.find(c => c.id === selectedId);
        if (center) {
          map.setView([center.lat, center.lng], 15, { animate: true, duration: 0.5 });
          markers[selectedId].openPopup();
        }
      }
      
      // Listen for messages to update focus
      window.addEventListener('message', (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.action === 'focusCenter' && data.id && markers[data.id]) {
            const center = pts.find(c => c.id === data.id);
            if (center) {
              map.setView([center.lat, center.lng], 15, { animate: true, duration: 0.5 });
              markers[data.id].openPopup();
            }
          }
          if (data.action === 'center' && typeof data.lat === 'number' && typeof data.lng === 'number') {
            map.setView([data.lat, data.lng], 14, { animate: true });
          }
        } catch (e) {}
      });
    </script>
  </body></html>`;
  const webRef = useRef(null);
  return (
    <View style={{ height, borderRadius: 6, overflow: 'hidden', borderWidth: 1, borderColor: colors.border }}>
      <WebView originWhitelist={['*']} style={{ flex: 1 }} source={{ html }} ref={webRef} onMessage={(e) => {
        try {
          const c = JSON.parse(e.nativeEvent.data || '{}');
          onSelect && onSelect(c);
        } catch { }
      }} />
      <View style={{ position: 'absolute', right: 8, bottom: 8 }}>
        <Pressable
          onPress={async () => {
            try {
              const { status } = await Location.requestForegroundPermissionsAsync();
              if (status !== 'granted') return;
              const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
              const la = Number(pos.coords.latitude.toFixed(7));
              const ln = Number(pos.coords.longitude.toFixed(7));
              const js = `window.dispatchEvent(new MessageEvent('message', { data: JSON.stringify({ action: 'center', lat: ${la}, lng: ${ln} }) }));`;
              webRef.current && webRef.current.injectJavaScript(js);
            } catch {}
          }}
          style={{ backgroundColor: colors.cardBg, borderWidth: 1, borderColor: colors.border, borderRadius: 20, paddingHorizontal: 12, paddingVertical: 8 }}
        >
          <Text style={{ color: colors.textDark, fontWeight: '600' }}>Ubicarme</Text>
        </Pressable>
      </View>
      {selectedId != null ? (
        <View style={{ position: 'absolute', bottom: 8, left: 8, right: 8, backgroundColor: colors.cardBg, padding: 8, borderRadius: 6 }}>
          <Text style={{ color: colors.text }}>Centro seleccionado: {selectedId}</Text>
        </View>
      ) : null}
    </View>
  );
}
