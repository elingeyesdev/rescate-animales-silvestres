import { View, Pressable, Text } from 'react-native';
import { WebView } from 'react-native-webview';
import * as Location from 'expo-location';
import { colors } from '../theme/colors';
import { useRef } from 'react';

export default function LeafletPicker({ lat, lng, height = '100%', onChange }) {
  const lat0 = lat != null ? Number(lat) : -17.7833;
  const lng0 = lng != null ? Number(lng) : -63.1821;
  const hasPoint = lat != null && lng != null;
  const webRef = useRef(null);

  const html = `<!DOCTYPE html><html><head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <style>html,body,#map{height:100%;margin:0;padding:0}</style>
  </head><body>
    <div id="map"></div>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script>
      const map=L.map('map',{zoomControl:true, attributionControl:false}).setView([${lat0},${lng0}], ${hasPoint ? 15 : 12});
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19, attribution:''}).addTo(map);
      let marker = ${hasPoint ? `L.marker([${lat0},${lng0}],{draggable:true}).addTo(map)` : 'null'};
      function emit(type, p) {
        const msg = { type, lat: p.lat, lng: p.lng };
        window.ReactNativeWebView && window.ReactNativeWebView.postMessage(JSON.stringify(msg));
      }
      if (marker) {
        marker.on('dragend', (e) => {
          const p = e.target.getLatLng();
          emit('move', p);
        });
      }
      map.on('click', (e) => {
        const p = e.latlng;
        if (!marker) {
          marker = L.marker([p.lat,p.lng],{draggable:true}).addTo(map);
          marker.on('dragend', (ev) => {
            const pp = ev.target.getLatLng();
            emit('move', pp);
          });
        } else {
          marker.setLatLng([p.lat,p.lng]);
        }
        emit('set', p);
      });

      // Listen to messages from React Native to center map
      window.addEventListener('message', (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data && data.action === 'center' && typeof data.lat === 'number' && typeof data.lng === 'number') {
            map.setView([data.lat, data.lng], 15, { animate: true });
            if (!marker) {
              marker = L.marker([data.lat, data.lng],{draggable:true}).addTo(map);
              marker.on('dragend', (ev) => {
                const pp = ev.target.getLatLng();
                emit('move', pp);
              });
            } else {
              marker.setLatLng([data.lat, data.lng]);
            }
            emit('set', { lat: data.lat, lng: data.lng });
          }
        } catch (e) {}
      });
    </script>
  </body></html>`;

  return (
    <View style={{ flex: 1, height, borderRadius: 6, overflow: 'hidden', borderWidth: 1, borderColor: colors.border }}>
      <WebView
        originWhitelist={['*']}
        source={{ html }}
        style={{ flex: 1 }}
        ref={webRef}
        onMessage={(e) => {
          try {
            const msg = JSON.parse(e.nativeEvent.data || '{}');
            if (msg && typeof msg.lat === 'number' && typeof msg.lng === 'number') {
              onChange && onChange(msg.lat, msg.lng);
            }
          } catch { }
        }}
      />
      <Pressable
        onPress={async () => {
          try {
            const { status } = await Location.requestForegroundPermissionsAsync();
            if (status !== 'granted') return;
            const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
            const la = Number(pos.coords.latitude.toFixed(7));
            const ln = Number(pos.coords.longitude.toFixed(7));
            const js = `window.dispatchEvent(new MessageEvent('message', { data: JSON.stringify({ action: 'center', lat: ${la}, lng: ${ln} }) }));`;
            webRef.current && webRef.current.injectJavaScript(js);
          } catch {}
        }}
        style={{ position: 'absolute', right: 8, bottom: 8, backgroundColor: colors.cardBg, borderWidth: 1, borderColor: colors.border, borderRadius: 20, paddingHorizontal: 12, paddingVertical: 8 }}
      >
        <Text style={{ color: colors.textDark, fontWeight: '600' }}>Ubicarme</Text>
      </Pressable>
    </View>
  );
}
