import { View, Text } from 'react-native';
import { WebView } from 'react-native-webview';
import { colors } from '../theme/colors';
import { generateMapHTML } from '../utils/mapHelper';

export default function MapPreview({ lat, lng, height = 180, title }) {
  if (lat == null || lng == null) {
    return (
      <View style={{ height, backgroundColor: colors.inputBg, borderWidth: 1, borderColor: colors.border, borderRadius: 6, alignItems: 'center', justifyContent: 'center' }}>
        <Text style={{ color: colors.textLight }}>Ubicación no disponible</Text>
      </View>
    );
  }

  const html = generateMapHTML({
    lat,
    lng,
    zoom: 15,
    interactive: true,  // Habilitado para zoom y movimiento
    marker: true,
    title: title || 'Ubicación'
  });

  return (
    <View style={{ height, borderRadius: 6, overflow: 'hidden', borderWidth: 1, borderColor: colors.border }}>
      <WebView
        originWhitelist={['*']}
        style={{ flex: 1 }}
        source={{ html }}
      />
    </View>
  );
}
