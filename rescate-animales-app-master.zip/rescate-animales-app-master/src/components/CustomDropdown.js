import React, { useState, useRef, useEffect } from 'react';
import { View, Text, Pressable, Animated, LayoutAnimation, Platform, UIManager } from 'react-native';
import { FontAwesome5 } from '@expo/vector-icons';
import { colors } from '../theme/colors';

if (Platform.OS === 'android') {
  if (UIManager.setLayoutAnimationEnabledExperimental) {
    UIManager.setLayoutAnimationEnabledExperimental(true);
  }
}

const CustomDropdown = ({ label, value, options, onValueChange, loading, placeholder = "Seleccione" }) => {
  const [isOpen, setIsOpen] = useState(false);
  const selectedOption = options.find(o => String(o.value) === String(value));
  const displayText = selectedOption ? selectedOption.label : placeholder;

  const toggleDropdown = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    setIsOpen(!isOpen);
  };

  const handleSelect = (val) => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    setIsOpen(false);
    onValueChange(val);
  };

  return (
    <View style={{ marginBottom: 16, zIndex: isOpen ? 1000 : 1 }}>
      {label && (
        <Text style={{ 
          marginBottom: 6, 
          color: colors.textDark, 
          fontWeight: '600', 
          fontSize: 14 
        }}>
          {label}
        </Text>
      )}
      
      <Pressable 
        onPress={toggleDropdown} 
        style={{ 
          borderWidth: 1, 
          borderColor: isOpen ? colors.blue : colors.border, 
          borderRadius: 8, 
          paddingHorizontal: 16,
          paddingVertical: 12,
          backgroundColor: colors.cardBg, 
          flexDirection: 'row', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          minHeight: 50
        }}
      >
        <Text style={{ color: value ? colors.textDark : colors.textLight, flex: 1, fontSize: 16 }}>
          {displayText}
        </Text>
        <FontAwesome5 
          name={isOpen ? "chevron-up" : "chevron-down"} 
          size={16} 
          color={isOpen ? colors.blue : colors.textLight} 
        />
      </Pressable>

      {isOpen && (
        <View style={{
          marginTop: 4,
          borderWidth: 1,
          borderColor: colors.border,
          borderRadius: 8,
          backgroundColor: colors.cardBg,
          overflow: 'hidden'
        }}>
          {options.map((item, index) => {
            const isSelected = String(item.value) === String(value);
            return (
              <Pressable
                key={index}
                onPress={() => handleSelect(item.value)}
                style={({ pressed }) => ({
                  padding: 16,
                  backgroundColor: pressed ? colors.bg : (isSelected ? colors.blue + '10' : 'transparent'),
                  borderBottomWidth: index === options.length - 1 ? 0 : 1,
                  borderBottomColor: colors.border + '40',
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between'
                })}
              >
                <Text style={{ 
                  fontSize: 16, 
                  color: isSelected ? colors.blue : colors.textDark,
                  fontWeight: isSelected ? '600' : '400'
                }}>
                  {item.label}
                </Text>
                {isSelected && (
                  <FontAwesome5 name="check" size={14} color={colors.blue} />
                )}
              </Pressable>
            );
          })}
        </View>
      )}
    </View>
  );
};

export default CustomDropdown;
