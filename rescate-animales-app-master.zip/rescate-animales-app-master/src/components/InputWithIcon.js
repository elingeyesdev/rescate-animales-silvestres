import { View, TextInput } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { moderateScale } from '../theme/layout';

export default function InputWithIcon({ icon, secureTextEntry, value, onChangeText, placeholder, style, accessibilityLabel, keyboardType, returnKeyType, onSubmitEditing, blurOnSubmit, multiline, size = 'md' }) {
  const h = size === 'lg' ? moderateScale(56) : (size === 'sm' ? moderateScale(40) : moderateScale(48));
  const fs = size === 'lg' ? moderateScale(16) : (size === 'sm' ? moderateScale(13) : moderateScale(14));
  const iconBoxW = size === 'lg' ? moderateScale(52) : (size === 'sm' ? moderateScale(40) : moderateScale(44));
  const iconSize = size === 'lg' ? moderateScale(22) : (size === 'sm' ? moderateScale(18) : moderateScale(20));
  return (
    <View
      style={[
        {
          flexDirection: 'row',
          alignItems: 'center',
          backgroundColor: colors.inputBg,
          borderWidth: 1,
          borderColor: colors.border,
          borderRadius: 6,
          overflow: 'hidden',
          marginBottom: 12,
          minHeight: h,
        },
        style,
      ]}
    >
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        secureTextEntry={secureTextEntry}
        accessibilityLabel={accessibilityLabel || placeholder}
        keyboardType={keyboardType}
        returnKeyType={returnKeyType}
        onSubmitEditing={onSubmitEditing}
        blurOnSubmit={blurOnSubmit}
        multiline={multiline}
        style={{ flex: 1, paddingHorizontal: moderateScale(14), fontSize: fs, textAlignVertical: 'center', minHeight: multiline ? moderateScale(80) : h, paddingVertical: multiline ? moderateScale(10) : undefined }}
        />
      <View
        style={{
          width: iconBoxW,
          alignSelf: 'stretch',
          backgroundColor: colors.cardBg,
          borderLeftWidth: 1,
          borderColor: colors.border,
          justifyContent: 'center',
          alignItems: 'center',
        }}
      >
        <MaterialIcons name={icon} size={iconSize} color={colors.icon} />
      </View>
    </View>
  );
}
