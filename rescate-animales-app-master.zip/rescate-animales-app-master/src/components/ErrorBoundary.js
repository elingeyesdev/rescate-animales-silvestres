import React from 'react';
import { View, Text, ScrollView, Pressable, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors } from '../theme/colors';
import { spacing, typography } from '../theme/layout';

class ErrorBoundary extends React.Component {
    constructor(props) {
        super(props);
        this.state = { hasError: false, error: null, errorInfo: null, errorCount: 0 };
    }

    static getDerivedStateFromError(error) {
        console.log('[ErrorBoundary] Error caught:', error);
        return { hasError: true };
    }

    componentDidCatch(error, errorInfo) {
        console.error('[ErrorBoundary] Component error:', error, errorInfo);

        this.setState(prevState => ({
            error,
            errorInfo,
            errorCount: prevState.errorCount + 1
        }));

        // Log para debugging
        if (__DEV__) {
            console.log('Error stack:', error.stack);
            console.log('Component stack:', errorInfo.componentStack);
        }
    }

    handleReset = () => {
        this.setState({ hasError: false, error: null, errorInfo: null });
    };

    handleGoHome = () => {
        this.setState({ hasError: false, error: null, errorInfo: null });

        // Intentar navegar al inicio
        if (this.props.navigation) {
            try {
                this.props.navigation.reset({
                    index: 0,
                    routes: [{ name: 'Main' }],
                });
            } catch (e) {
                console.error('Navigation reset failed:', e);
            }
        }
    };

    handleShowDetails = () => {
        const { error, errorInfo } = this.state;
        Alert.alert(
            'Detalles del Error',
            `${error?.toString()}\n\n${errorInfo?.componentStack || ''}`,
            [{ text: 'OK' }]
        );
    };

    render() {
        if (this.state.hasError) {
            const { error, errorCount } = this.state;

            return (
                <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
                    <ScrollView contentContainerStyle={{ padding: spacing.md }}>
                        <View style={{
                            backgroundColor: colors.cardBg,
                            borderRadius: 12,
                            padding: spacing.lg,
                            borderWidth: 2,
                            borderColor: colors.danger,
                        }}>
                            {/* Icono y título */}
                            <View style={{ alignItems: 'center', marginBottom: spacing.lg }}>
                                <View style={{
                                    width: 80,
                                    height: 80,
                                    borderRadius: 40,
                                    backgroundColor: colors.danger + '20',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    marginBottom: spacing.md,
                                }}>
                                    <Text style={{ fontSize: 40 }}>⚠️</Text>
                                </View>
                                <Text style={{
                                    fontSize: typography.xl,
                                    fontWeight: '700',
                                    color: colors.textDark,
                                    textAlign: 'center',
                                    marginBottom: spacing.xs,
                                }}>
                                    Algo salió mal
                                </Text>
                                <Text style={{
                                    fontSize: typography.md,
                                    color: colors.textLight,
                                    textAlign: 'center',
                                }}>
                                    La aplicación encontró un problema inesperado
                                </Text>
                            </View>

                            {/* Contador de errores */}
                            {errorCount > 1 && (
                                <View style={{
                                    backgroundColor: colors.warning + '20',
                                    padding: spacing.sm,
                                    borderRadius: 8,
                                    marginBottom: spacing.md,
                                    borderLeftWidth: 4,
                                    borderLeftColor: colors.warning,
                                }}>
                                    <Text style={{
                                        fontSize: typography.sm,
                                        color: colors.warning,
                                        textAlign: 'center',
                                        fontWeight: '600',
                                    }}>
                                        Este error ha ocurrido {errorCount} veces
                                    </Text>
                                </View>
                            )}

                            {/* Mensaje de error (solo en dev) */}
                            {__DEV__ && error && (
                                <ScrollView style={{
                                    maxHeight: 200,
                                    backgroundColor: '#000',
                                    padding: 12,
                                    borderRadius: 6,
                                    marginBottom: spacing.md
                                }}>
                                    <Text style={{ color: '#ff6b6b', fontFamily: 'monospace', fontSize: 12 }}>
                                        {error.toString()}
                                    </Text>
                                    {error.stack && (
                                        <Text style={{ color: '#ffa500', fontFamily: 'monospace', fontSize: 10, marginTop: 8 }}>
                                            {error.stack}
                                        </Text>
                                    )}
                                </ScrollView>
                            )}

                            {/* Botones de acción */}
                            <View style={{ gap: spacing.sm }}>
                                <Pressable
                                    onPress={this.handleReset}
                                    style={{
                                        backgroundColor: colors.blue,
                                        paddingVertical: 14,
                                        borderRadius: 8,
                                        alignItems: 'center',
                                    }}
                                >
                                    <Text style={{
                                        color: '#fff',
                                        fontWeight: '700',
                                        fontSize: typography.md,
                                    }}>
                                        Reintentar
                                    </Text>
                                </Pressable>

                                <Pressable
                                    onPress={this.handleGoHome}
                                    style={{
                                        backgroundColor: colors.cardBg,
                                        paddingVertical: 14,
                                        borderRadius: 8,
                                        alignItems: 'center',
                                        borderWidth: 1,
                                        borderColor: colors.border,
                                    }}
                                >
                                    <Text style={{
                                        color: colors.textDark,
                                        fontWeight: '600',
                                        fontSize: typography.md,
                                    }}>
                                        Volver al inicio
                                    </Text>
                                </Pressable>

                                {__DEV__ && (
                                    <Pressable
                                        onPress={this.handleShowDetails}
                                        style={{
                                            backgroundColor: colors.inputBg,
                                            paddingVertical: 12,
                                            borderRadius: 8,
                                            alignItems: 'center',
                                            borderWidth: 1,
                                            borderColor: colors.border
                                        }}
                                    >
                                        <Text style={{ color: colors.textDark, fontWeight: '600', fontSize: typography.sm }}>
                                            Ver Detalles Completos
                                        </Text>
                                    </Pressable>
                                )}
                            </View>

                            {/* Mensaje de ayuda */}
                            <View style={{
                                marginTop: spacing.lg,
                                padding: spacing.sm,
                                backgroundColor: colors.blue + '10',
                                borderRadius: 8,
                            }}>
                                <Text style={{
                                    fontSize: typography.sm,
                                    color: colors.textLight,
                                    textAlign: 'center',
                                }}>
                                    Si el problema persiste, intenta cerrar y volver a abrir la aplicación
                                </Text>
                            </View>
                        </View>
                    </ScrollView>
                </SafeAreaView>
            );
        }

        return this.props.children;
    }
}

export default ErrorBoundary;
