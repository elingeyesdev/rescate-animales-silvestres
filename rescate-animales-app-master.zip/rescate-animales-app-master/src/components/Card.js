import { View } from 'react-native';
import { colors } from '../theme/colors';
import { spacing } from '../theme/layout';

export default function Card({ children, footer }) {
  return (
    <View
      style={{
        width: '100%',
        alignSelf: 'center',
        borderRadius: 10,
        backgroundColor: colors.cardBg,
        shadowColor: '#000',
        shadowOpacity: 0.1,
        shadowRadius: 10,
        shadowOffset: { width: 0, height: 2 },
        elevation: 3,
        overflow: 'hidden',
      }}
    >
      <View style={{ borderTopWidth: 3, borderTopColor: colors.blue }} />
      <View style={{ padding: spacing.md }}>{children}</View>
      {footer ? <View style={{ backgroundColor: colors.cardFooterBg, padding: spacing.sm }}>{footer}</View> : null}
    </View>
  );
}
