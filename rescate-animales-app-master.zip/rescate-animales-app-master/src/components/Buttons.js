import { Pressable, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { spacing, typography } from '../theme/layout';

export function PrimaryButton({ title, onPress, disabled, style, accessibilityLabel, icon, emphasis }) {
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel || title}
      android_ripple={{ color: '#ffffff33' }}
      style={({ pressed }) => [
        {
          backgroundColor: disabled ? colors.neutral : colors.blue,
          paddingVertical: emphasis ? spacing.md : spacing.sm,
          paddingHorizontal: spacing.md,
          borderRadius: emphasis ? 10 : 6,
          alignItems: 'center',
          justifyContent: 'center',
          opacity: disabled ? 0.6 : 1,
          minHeight: emphasis ? 44 : 40,
          shadowColor: emphasis ? '#000' : undefined,
          shadowOpacity: emphasis ? 0.12 : undefined,
          shadowRadius: emphasis ? 6 : undefined,
          shadowOffset: emphasis ? { width: 0, height: 2 } : undefined,
          elevation: emphasis ? 2 : undefined,
        },
        pressed && !disabled ? { opacity: 0.9 } : null,
        style,
      ]}
    >
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center' }}>
        {icon ? (
          <MaterialIcons name={icon} size={emphasis ? 18 : 16} color={disabled ? colors.text : '#fff'} style={{ marginRight: 8 }} />
        ) : null}
        <Text style={{ color: disabled ? colors.text : '#fff', fontWeight: emphasis ? '700' : '600', fontSize: emphasis ? typography.md : typography.sm }}>{title}</Text>
      </View>
    </Pressable>
  );
}

export function SecondaryButton({ title, onPress, style, accessibilityLabel }) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel || title}
      android_ripple={{ color: '#00000011' }}
      style={({ pressed }) => [
        {
          backgroundColor: colors.cardBg,
          paddingVertical: spacing.xs,
          paddingHorizontal: spacing.md,
          borderRadius: 6,
          alignItems: 'center',
          justifyContent: 'center',
          minHeight: 40,
          borderWidth: 1,
          borderColor: colors.border,
        },
        pressed ? { opacity: 0.9 } : null,
        style,
      ]}
    >
      <Text style={{ color: colors.textDark, fontWeight: '600', fontSize: typography.sm }}>{title}</Text>
    </Pressable>
  );
}

export function DangerButton({ title, onPress, style, accessibilityLabel }) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel || title}
      android_ripple={{ color: '#ffffff33' }}
      style={({ pressed }) => [
        {
          backgroundColor: colors.danger,
          paddingVertical: spacing.xs,
          paddingHorizontal: spacing.md,
          borderRadius: 6,
          alignItems: 'center',
          justifyContent: 'center',
          minHeight: 40,
        },
        pressed ? { opacity: 0.9 } : null,
        style,
      ]}
    >
      <Text style={{ color: '#fff', fontWeight: '600', fontSize: typography.sm }}>{title}</Text>
    </Pressable>
  );
}
