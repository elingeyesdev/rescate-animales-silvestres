import { View, Text, Pressable } from 'react-native';
import { colors } from '../theme/colors';
import { moderateScale } from '../theme/layout';
import { FontAwesome5 } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';

export default function BrandHeader() {
  const { offlineMode, retryConnection } = useAuth();
  return (
    <View style={{ alignItems: 'center', marginBottom: 16 }}>
      <View
        style={{
          width: moderateScale(52),
          height: moderateScale(52),
          borderRadius: moderateScale(26),
          backgroundColor: colors.cardBg,
          justifyContent: 'center',
          alignItems: 'center',
          shadowColor: '#000',
          shadowOpacity: 0.08,
          shadowRadius: moderateScale(6),
          shadowOffset: { width: 0, height: 2 },
          elevation: 3,
        }}
      >
        <FontAwesome5 name="paw" size={26} color={colors.primary || colors.blue} />
      </View>
      <Text style={{ marginTop: moderateScale(8), fontSize: moderateScale(22) }}>
        <Text style={{ color: colors.textDark, fontWeight: '600' }}>Rescate</Text>
        <Text style={{ color: colors.textLight, fontWeight: '400' }}>Animales</Text>
      </Text>
      {offlineMode ? (
        <View style={{ marginTop: 6, alignItems: 'center' }}>
          <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
            <View style={{ paddingHorizontal: 10, paddingVertical: 4, borderRadius: 16, backgroundColor: colors.warning + '20', borderWidth: 1, borderColor: colors.warning }}>
              <Text style={{ color: colors.warning, fontSize: moderateScale(12), fontWeight: '600' }}>Modo Offline</Text>
            </View>
            <Pressable onPress={retryConnection} style={{ paddingHorizontal: 10, paddingVertical: 4, borderRadius: 16, backgroundColor: colors.cardBg, borderWidth: 1, borderColor: colors.border }}>
              <Text style={{ color: colors.textDark, fontSize: moderateScale(12), fontWeight: '600' }}>Reintentar conexión</Text>
            </Pressable>
          </View>
        </View>
      ) : null}
    </View>
  );
}
