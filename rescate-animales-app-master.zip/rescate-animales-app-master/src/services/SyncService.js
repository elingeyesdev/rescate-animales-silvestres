import NetInfo from '@react-native-community/netinfo';
import { getPendingReports, removePendingReport, markReportSynced, markReportUploading, computeReportFingerprint } from '../utils/offlineStorage';
import { createReport, buildReportForm } from '../api/reports';
import { getReportHistory, saveReportToHistory } from '../utils/reportHistory';

class SyncService {
    constructor() {
        this.isSyncing = false;
        this.listeners = [];
        this.unsubscribeNetInfo = null;
    }

    /**
     * Start monitoring network state and auto-sync
     * DISABLED: Auto-sync is now manual via PendingReportsScreen
     */
    start() {
        if (this.unsubscribeNetInfo) return;

        this.unsubscribeNetInfo = NetInfo.addEventListener(state => {
            console.log('[SyncService] Network state changed:', state.isConnected ? 'online' : 'offline');

            // Auto-sync when connection is restored
            if (state.isConnected && !this.isSyncing) {
                console.log('[SyncService] Connection restored, starting auto-sync...');
                this.syncPendingReports();
            }
        });
    }

    /**
     * Stop monitoring
     */
    stop() {
        if (this.unsubscribeNetInfo) {
            this.unsubscribeNetInfo();
            this.unsubscribeNetInfo = null;
        }
    }

    /**
     * Add a listener for sync events
     */
    addListener(callback) {
        this.listeners.push(callback);
        return () => {
            this.listeners = this.listeners.filter(cb => cb !== callback);
        };
    }

    /**
     * Notify all listeners
     */
    notify(event, data) {
        this.listeners.forEach(cb => cb(event, data));
    }

    /**
     * Sync all pending reports
     */
    async syncPendingReports() {
        if (this.isSyncing) return;

        try {
            this.isSyncing = true;
            const pending = await getPendingReports();
            const unsynced = pending.filter(r => !r.synced && !r.uploading);

            if (unsynced.length === 0) {
                this.notify('sync_complete', { count: 0 });
                return;
            }

            this.notify('sync_start', { count: unsynced.length });

            let successCount = 0;
            let failCount = 0;

            for (const report of unsynced) {
                try {
                    console.log('[SyncService] ========== SYNCING REPORT ==========');
                    console.log('[SyncService] Report ID:', report.id);
                    console.log('[SyncService] Report timestamp:', report.timestamp);

                    // Reconstruct the image object from base64
                    const reportData = { ...report.data };
                    console.log('[SyncService] Report data keys:', Object.keys(reportData));
                    console.log('[SyncService] Report has persona_id:', !!reportData.persona_id);
                    console.log('[SyncService] Report has traslado_inmediato:', !!reportData.traslado_inmediato);

                    if (reportData.imagen?.base64) {
                        // Convert base64 back to blob for upload
                        const { base64, ...imageData } = reportData.imagen;
                        reportData.imagen = {
                            ...imageData,
                            uri: `data:${imageData.type};base64,${base64}`
                        };
                        console.log('[SyncService] Image reconstructed from base64');
                    }

                    // FIX: Remove traslado_inmediato if persona_id is missing to avoid backend error
                    if (reportData.traslado_inmediato && !reportData.persona_id) {
                        console.log('[SyncService] WARNING: traslado_inmediato is true but persona_id is missing');
                        console.log('[SyncService] Removing traslado_inmediato to prevent backend error');
                        delete reportData.traslado_inmediato;
                        delete reportData.centro_id;
                    }

                    const fingerprint = reportData.fingerprint || computeReportFingerprint(reportData);
                    const history = await getReportHistory().catch(() => []);
                    const exists = Array.isArray(history) && history.some(h => h?.status === 'uploaded' && h?.data?.fingerprint === fingerprint);
                    if (exists) {
                        await removePendingReport(report.id);
                        successCount++;
                        this.notify('sync_progress', {
                            current: successCount + failCount,
                            total: unsynced.length,
                            success: successCount,
                            failed: failCount
                        });
                        continue;
                    }

                    await markReportUploading(report.id, true);
                    console.log('[SyncService] Building form...');
                    const form = buildReportForm(reportData);
                    console.log('[SyncService] Sending to API...');
                    const apiResponse = await createReport(form);
                    console.log('[SyncService] API Response:', apiResponse);
                    console.log('[SyncService] Report synced successfully:', report.id);

                    console.log('[SyncService] Removing from pending storage...');
                    const removed = await removePendingReport(report.id);
                    console.log('[SyncService] Report removal result:', removed);

                    if (!removed) {
                        console.error('[SyncService] WARNING: Failed to remove report from storage!');
                        throw new Error('Failed to remove report from local storage');
                    }

                    try {
                        const rid = apiResponse?.id || apiResponse?.report_id || apiResponse?.reporte_id || null;
                        await saveReportToHistory({ uploadedSuccessfully: true, report_id: rid, persona_id: reportData?.persona_id, fingerprint });
                        this.notify('report_uploaded', { reportId: rid, fingerprint, traslado_inmediato: !!reportData?.traslado_inmediato, centro_id: reportData?.centro_id });
                    } catch {}

                    successCount++;
                    console.log('[SyncService] ========== SYNC SUCCESS ==========');
                    this.notify('sync_progress', {
                        current: successCount + failCount,
                        total: unsynced.length,
                        success: successCount,
                        failed: failCount
                    });
                } catch (e) {
                    console.error('[SyncService] ========== SYNC ERROR ==========');
                    console.error('[SyncService] Error syncing report:', report.id);
                    console.error('[SyncService] Error object:', e);
                    // Stringify error details to avoid [object Object]
                    const errorDetails = {
                        status: e?.response?.status,
                        data: e?.response?.data,
                        message: e?.message,
                        code: e?.code
                    };
                    console.error('[SyncService] Error details:', JSON.stringify(errorDetails, null, 2));
                    failCount++;
                    this.notify('sync_error', {
                        reportId: report.id,
                        error: e.message || 'Unknown error'
                    });
                } finally {
                    await markReportUploading(report.id, false);
                }
            }

            this.notify('sync_complete', {
                total: unsynced.length,
                success: successCount,
                failed: failCount
            });
        } catch (e) {
            console.error('[SyncService] Error in sync process:', e);
            this.notify('sync_failed', { error: e.message });
        } finally {
            this.isSyncing = false;
        }
    }

    /**
     * Check if currently syncing
     */
    getSyncStatus() {
        return this.isSyncing;
    }
}

// Export singleton instance
export default new SyncService();
