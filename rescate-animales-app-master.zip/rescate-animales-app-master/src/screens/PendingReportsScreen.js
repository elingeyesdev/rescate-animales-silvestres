import { useState, useEffect } from 'react';
import { View, Text, ScrollView, Pressable, Alert, useWindowDimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { getPendingReports, removePendingReport, markReportUploading, computeReportFingerprint } from '../utils/offlineStorage';
import { getReportHistory, clearReportHistory, saveReportToHistory } from '../utils/reportHistory';
import { createReport, buildReportForm } from '../api/reports';
import useIsMounted from '../hooks/useIsMounted';

export default function PendingReportsScreen({ navigation }) {
    const [activeTab, setActiveTab] = useState('pending'); // 'pending' or 'history'
    const [reports, setReports] = useState([]);
    const [history, setHistory] = useState([]);
    const [loading, setLoading] = useState(true);
    const [uploadingIds, setUploadingIds] = useState(new Set());
    const isMounted = useIsMounted();
    const { width } = useWindowDimensions();
    const isWide = width > 600;
    const isTablet = width > 900;
    const containerStyle = isWide ? { maxWidth: isTablet ? 900 : 600, alignSelf: 'center', width: '100%' } : {};

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        if (isMounted.current) setLoading(true);
        const [pending, hist] = await Promise.all([
            getPendingReports(),
            getReportHistory()
        ]);
        if (isMounted.current) {
            setReports(pending);
            setHistory(hist);
            setLoading(false);
        }
    };

    const handleUploadReport = async (report) => {
        if (uploadingIds.has(report.id)) return;

        if (isMounted.current) setUploadingIds(prev => new Set(prev).add(report.id));

        try {
            console.log('[PendingReports] Uploading report:', report.id);

            const reportData = { ...report.data };

            const fingerprint = reportData.fingerprint || computeReportFingerprint(reportData);
            const history = await getReportHistory().catch(() => []);
            const exists = Array.isArray(history) && history.some(h => h?.status === 'uploaded' && h?.data?.fingerprint === fingerprint);
            if (exists) {
                const removed = await removePendingReport(report.id);
                if (removed) {
                    Alert.alert('Éxito', 'Este reporte ya estaba subido');
                    loadData();
                }
                return;
            }

            await markReportUploading(report.id, true);

            if (reportData.imagen?.base64) {
                const { base64, ...imageData } = reportData.imagen;
                reportData.imagen = {
                    ...imageData,
                    uri: `data:${imageData.type};base64,${base64}`
                };
            }

            const form = buildReportForm(reportData);
            const res = await createReport(form);

            const removed = await removePendingReport(report.id);
            try {
                const rid = res?.id || res?.report_id || res?.reporte_id || null;
                await saveReportToHistory({ uploadedSuccessfully: true, report_id: rid, persona_id: reportData?.persona_id, fingerprint });
                if (rid && reportData?.traslado_inmediato && reportData?.centro_id) {
                    try { navigation.getParent()?.navigate('Transfers', { reportId: rid, reporte_id: rid, primer_traslado: true }); } catch {}
                }
            } catch {}

            if (removed) {
                Alert.alert(
                    'Éxito',
                    'El reporte se subió correctamente',
                    [{ text: 'OK', onPress: () => loadData() }]
                );
            } else {
                Alert.alert(
                    'Advertencia',
                    'El reporte se subió pero no se pudo eliminar de pendientes.',
                    [{ text: 'OK', onPress: () => loadData() }]
                );
            }
        } catch (e) {
            console.error('[PendingReports] Error uploading:', e);
            Alert.alert(
                'Error al Subir',
                `No se pudo subir el reporte:\n\n${e?.response?.data?.message || e?.message || 'Error desconocido'}`,
                [{ text: 'OK' }]
            );
        } finally {
            if (isMounted.current) {
                setUploadingIds(prev => {
                    const newSet = new Set(prev);
                    newSet.delete(report.id);
                    return newSet;
                });
            }
            await markReportUploading(report.id, false);
        }
    };

    const handleDeleteReport = (report) => {
        Alert.alert(
            'Eliminar Reporte',
            `¿Estás seguro de que deseas eliminar este reporte pendiente?`,
            [
                { text: 'Cancelar', style: 'cancel' },
                {
                    text: 'Eliminar',
                    style: 'destructive',
                    onPress: async () => {
                        const success = await removePendingReport(report.id);
                        if (success) {
                            Alert.alert('Eliminado', 'El reporte pendiente ha sido eliminado');
                            loadData();
                        } else {
                            Alert.alert('Error', 'No se pudo eliminar el reporte');
                        }
                    }
                }
            ]
        );
    };

    const handleClearHistory = () => {
        Alert.alert(
            'Limpiar Historial',
            `¿Estás seguro de que deseas eliminar todo el historial (${history.length} reportes)?`,
            [
                { text: 'Cancelar', style: 'cancel' },
                {
                    text: 'Limpiar',
                    style: 'destructive',
                    onPress: async () => {
                        await clearReportHistory();
                        Alert.alert('Completado', 'Historial limpiado');
                        loadData();
                    }
                }
            ]
        );
    };

    const formatDate = (timestamp) => {
        const date = new Date(timestamp);
        return date.toLocaleString('es-ES', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    const currentData = activeTab === 'pending' ? reports : history;

    return (
        <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
            {/* Header */}
            <View style={{
                flexDirection: 'row',
                alignItems: 'center',
                padding: 16,
                borderBottomWidth: 1,
                borderBottomColor: colors.border
            }}>
                <Pressable onPress={() => navigation.goBack()} style={{ marginRight: 16 }}>
                    <MaterialIcons name="arrow-back" size={24} color={colors.textDark} />
                </Pressable>
                <Text style={{ fontSize: 20, fontWeight: '700', color: colors.textDark, flex: 1 }}>
                    Mis Reportes
                </Text>
            </View>

            {/* Tabs */}
            <View style={{ flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: colors.border }}>
                <Pressable
                    onPress={() => setActiveTab('pending')}
                    style={{
                        flex: 1,
                        padding: 16,
                        borderBottomWidth: 3,
                        borderBottomColor: activeTab === 'pending' ? colors.blue : 'transparent',
                        backgroundColor: activeTab === 'pending' ? colors.blue + '10' : 'transparent'
                    }}
                >
                    <Text style={{
                        textAlign: 'center',
                        fontWeight: '700',
                        color: activeTab === 'pending' ? colors.blue : colors.textLight
                    }}>
                        Pendientes ({reports.length})
                    </Text>
                </Pressable>

                <Pressable
                    onPress={() => setActiveTab('history')}
                    style={{
                        flex: 1,
                        padding: 16,
                        borderBottomWidth: 3,
                        borderBottomColor: activeTab === 'history' ? colors.blue : 'transparent',
                        backgroundColor: activeTab === 'history' ? colors.blue + '10' : 'transparent'
                    }}
                >
                    <Text style={{
                        textAlign: 'center',
                        fontWeight: '700',
                        color: activeTab === 'history' ? colors.blue : colors.textLight
                    }}>
                        Historial ({history.length})
                    </Text>
                </Pressable>
            </View>

            {/* Action Buttons */}
            {currentData.length > 0 && (
                <View style={{ padding: 12, borderBottomWidth: 1, borderBottomColor: colors.border, gap: 8 }}>
                    {activeTab === 'history' && (
                        <Pressable
                            onPress={handleClearHistory}
                            style={{
                                backgroundColor: colors.danger,
                                padding: 14,
                                borderRadius: 8,
                                flexDirection: 'row',
                                alignItems: 'center',
                                justifyContent: 'center'
                            }}
                        >
                            <MaterialIcons name="delete-sweep" size={22} color="#fff" style={{ marginRight: 8 }} />
                            <Text style={{ color: '#fff', fontWeight: '700', fontSize: 16 }}>Limpiar Historial</Text>
                        </Pressable>
                    )}
                </View>
            )}

            {/* Content */}
            <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16 }}>
                <View style={containerStyle}>
                    {loading ? (
                        <Text style={{ color: colors.textLight, textAlign: 'center', marginTop: 20 }}>
                            Cargando...
                        </Text>
                    ) : currentData.length === 0 ? (
                        <View style={{ alignItems: 'center', marginTop: 40 }}>
                            <MaterialIcons
                                name={activeTab === 'pending' ? 'cloud-done' : 'history'}
                                size={64}
                                color={colors.textLight}
                            />
                            <Text style={{
                                color: colors.textDark,
                                fontSize: 18,
                                fontWeight: '600',
                                marginTop: 16,
                                textAlign: 'center'
                            }}>
                                {activeTab === 'pending' ? 'No hay reportes pendientes' : 'No hay historial'}
                            </Text>
                            <Text style={{ color: colors.textLight, marginTop: 8, textAlign: 'center' }}>
                                {activeTab === 'pending'
                                    ? 'Todos tus reportes están sincronizados'
                                    : 'Los reportes que crees aparecerán aquí'}
                            </Text>
                        </View>
                    ) : (
                        (Array.isArray(currentData) ? currentData : []).map((item, index) => {
                            const isUploading = uploadingIds.has(item.id);
                            const isPending = activeTab === 'pending';
                            const status = item.status || (item.data?.uploadedSuccessfully ? 'uploaded' : 'pending');

                            return (
                                <View
                                    key={item.id}
                                    style={{
                                        backgroundColor: colors.cardBg,
                                        borderLeftWidth: 4,
                                        borderLeftColor: status === 'uploaded' ? colors.success : colors.warning,
                                        borderRadius: 8,
                                        padding: 16,
                                        marginBottom: 12,
                                        borderWidth: 1,
                                        borderColor: colors.border,
                                        opacity: isUploading ? 0.6 : 1
                                    }}
                                >
                                    <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
                                        <MaterialIcons
                                            name={status === 'uploaded' ? 'cloud-done' : 'cloud-queue'}
                                            size={20}
                                            color={status === 'uploaded' ? colors.success : colors.warning}
                                            style={{ marginRight: 8 }}
                                        />
                                        <Text style={{
                                            color: colors.textDark,
                                            fontWeight: '700',
                                            flex: 1
                                        }}>
                                            Reporte #{index + 1}
                                        </Text>
                                        <Text style={{
                                            backgroundColor: status === 'uploaded' ? colors.success : colors.warning,
                                            color: '#fff',
                                            paddingHorizontal: 8,
                                            paddingVertical: 2,
                                            borderRadius: 4,
                                            fontSize: 12,
                                            fontWeight: '600'
                                        }}>
                                            {status === 'uploaded' ? 'Subido' : 'Pendiente'}
                                        </Text>
                                    </View>

                                    <Text style={{
                                        color: colors.textLight,
                                        fontSize: 12,
                                        marginBottom: 8
                                    }}>
                                        {formatDate(item.timestamp)}
                                    </Text>

                                    <View style={{ marginBottom: 12 }}>
                                        {item.data?.latitud && item.data?.longitud && (
                                            <Text style={{ color: colors.textLight, fontSize: 12 }}>
                                                📍 {item.data.latitud.toFixed(5)}, {item.data.longitud.toFixed(5)}
                                            </Text>
                                        )}
                                        {item.data?.tamano && (
                                            <Text style={{ color: colors.textLight, fontSize: 12 }}>
                                                📏 Tamaño: {item.data.tamano}
                                            </Text>
                                        )}
                                        {item.data?.observaciones && (
                                            <Text style={{ color: colors.textLight, fontSize: 12 }}>
                                                📝 {item.data.observaciones.substring(0, 60)}
                                                {item.data.observaciones.length > 60 ? '...' : ''}
                                            </Text>
                                        )}
                                    </View>

                                    {isPending && (
                                        <View style={{ flexDirection: 'row', gap: 8 }}>
                                            <Pressable
                                                onPress={() => handleUploadReport(item)}
                                                disabled={isUploading}
                                                style={{
                                                    flex: 1,
                                                    backgroundColor: isUploading ? colors.textLight : colors.success,
                                                    padding: 12,
                                                    borderRadius: 6,
                                                    flexDirection: 'row',
                                                    alignItems: 'center',
                                                    justifyContent: 'center'
                                                }}
                                            >
                                                <MaterialIcons
                                                    name={isUploading ? 'hourglass-empty' : 'cloud-upload'}
                                                    size={20}
                                                    color="#fff"
                                                    style={{ marginRight: 6 }}
                                                />
                                                <Text style={{ color: '#fff', fontWeight: '700', fontSize: 15 }}>
                                                    {isUploading ? 'Subiendo...' : 'Subir'}
                                                </Text>
                                            </Pressable>

                                            <Pressable
                                                onPress={() => handleDeleteReport(item)}
                                                disabled={isUploading}
                                                style={{
                                                    flex: 1,
                                                    backgroundColor: isUploading ? colors.textLight : colors.danger,
                                                    padding: 12,
                                                    borderRadius: 6,
                                                    flexDirection: 'row',
                                                    alignItems: 'center',
                                                    justifyContent: 'center'
                                                }}
                                            >
                                                <MaterialIcons name="delete" size={20} color="#fff" style={{ marginRight: 6 }} />
                                                <Text style={{ color: '#fff', fontWeight: '700', fontSize: 15 }}>
                                                    Eliminar
                                                </Text>
                                            </Pressable>
                                        </View>
                                    )}
                                </View>
                            );
                        })
                    )}
                </View>
            </ScrollView>
        </SafeAreaView>
    );
}
