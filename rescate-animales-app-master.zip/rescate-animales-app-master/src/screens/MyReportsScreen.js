import { useEffect, useState, useRef } from 'react';
import { View, Text, Pressable, useWindowDimensions, ScrollView, Alert } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import BrandHeader from '../components/BrandHeader';
import { colors } from '../theme/colors';
import { listReports } from '../api/reports';
import { WebView } from 'react-native-webview';
import { listAnimalFiles } from '../api/animalFiles';
import { getReportHistory } from '../utils/reportHistory';
import { getPendingReports } from '../utils/offlineStorage';
import * as Location from 'expo-location';
import apiClient from '../api/client';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '../context/AuthContext';
import useIsMounted from '../hooks/useIsMounted';
import CentersMap from '../components/CentersMap';
import { listCenters } from '../api/centers';

export default function MyReportsScreen({ navigation }) {
  const { height, width } = useWindowDimensions();
  const [items, setItems] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const { user, isAuthenticated, hasRole, offlineMode } = useAuth();
  const [rescuedCount, setRescuedCount] = useState(0);
  const [releasedCount, setReleasedCount] = useState(0);
  const [reportsCount, setReportsCount] = useState(0);
  const [transfersCount, setTransfersCount] = useState(0);
  const isMounted = useIsMounted();
  const mapRef = useRef(null);
  const [mapFilter, setMapFilter] = useState('centers');
  const [centers, setCenters] = useState([]);
  const [loadingCenters, setLoadingCenters] = useState(false);
  const [selectedCenterId, setSelectedCenterId] = useState(null);

  const load = async () => {
    try {
      if (offlineMode) { if (isMounted.current) setItems([]); return; }
      const pid = user?.persona?.id || user?.person?.id || user?.id || null;
      let arr = await listReports({ mine: 1, per_page: 1000 }).catch(() => []);
      arr = Array.isArray(arr) ? arr : [];
      if (arr.length === 0) {
        const all = await listReports({ per_page: 1000 }).catch(() => []);
        arr = Array.isArray(all) ? all : [];
      }
      const filtered = pid ? arr.filter((r) => String(r.persona_id || r.user_id || r.person_id) === String(pid)) : arr;
      if (isMounted.current) setItems(filtered);
    } catch (e) {
      try {
        const fallback = await apiClient.get('/reports', { params: { per_page: 1000 } }).catch(() => ({ data: [] }));
        const data = Array.isArray(fallback?.data?.data) ? fallback.data.data : (Array.isArray(fallback?.data) ? fallback.data : []);
        const pid = user?.persona?.id || user?.person?.id || user?.id || null;
        const filtered = pid ? data.filter((r) => String(r.persona_id || r.user_id || r.person_id) === String(pid)) : data;
        if (isMounted.current) setItems(filtered);
      } catch (e2) {
        console.log('Error cargando reports', e2?.response || e2);
      }
    }
  };

  const formatDate = (s) => {
    if (!s) return 'N/D';
    const d = new Date(s);
    if (isNaN(d.getTime())) return String(s);
    const dd = String(d.getDate()).padStart(2, '0');
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const yy = d.getFullYear();
    return `${dd}/${mm}/${yy}`;
  };

  useEffect(() => {
    if (isAuthenticated) {
      load();
    } else {
      if (isMounted.current) setItems([]);
    }
  }, [isAuthenticated]);

  useEffect(() => {
    (async () => {
      try {
        const [files, reps] = await Promise.all([
          listAnimalFiles({ per_page: 1000 }).catch(() => []),
          listReports({ per_page: 1000 }).catch(() => []),
        ]);
        if (isMounted.current) {
          setRescuedCount(Array.isArray(files) ? files.length : 0);
          setReportsCount(Array.isArray(reps) ? reps.length : 0);
        }
      } catch { }
      try {
        const trRes = await apiClient.get('/transfers', { params: { per_page: 1000 } }).catch(() => ({ data: [] }));
        const trArr = Array.isArray(trRes?.data?.data) ? trRes.data.data : (Array.isArray(trRes?.data) ? trRes.data : []);
        if (isMounted.current) setTransfersCount(Array.isArray(trArr) ? trArr.length : 0);
      } catch { }
      try {
        const rlRes = await apiClient.get('/releases', { params: { per_page: 1000 } }).catch(() => ({ data: [] }));
        const rlArr = Array.isArray(rlRes?.data?.data) ? rlRes.data.data : (Array.isArray(rlRes?.data) ? rlRes.data : []);
        if (isMounted.current) setReleasedCount(Array.isArray(rlArr) ? rlArr.length : 0);
      } catch { }
    })();
  }, [isAuthenticated]);

  useEffect(() => {
    (async () => {
      try {
        setLoadingCenters(true);
        const cs = await listCenters({ perPage: 1000 }).catch(() => []);
        if (isMounted.current) setCenters(Array.isArray(cs) ? cs : []);
      } finally {
        if (isMounted.current) setLoadingCenters(false);
      }
    })();
  }, []);

  const gap = 12;
  const col = width > 900 ? 4 : (width > 600 ? 3 : (width > 400 ? 2 : 1));
  const availableWidth = width - 32; // 32 = paddingHorizontal * 2
  const tileW = (availableWidth - (gap * (col - 1))) / col;

  const onlinePoints = (Array.isArray(items) ? items : [])
    .map((r) => {
      const lat = Number(r.latitud ?? r.latitude ?? r.lat);
      const lng = Number(r.longitud ?? r.longitude ?? r.lng);
      if (!isFinite(lat) || !isFinite(lng)) return null;
      const incidentRaw = r?.tipo_incidente?.nombre || r?.tipo_incidente_nombre || r?.tipo_incidente_name || r?.incidente?.nombre || r?.incidente || r?.incident?.nombre || r?.incident?.name || null;
      const incident = incidentRaw ? String(incidentRaw) : null;
      const size = r?.tamano || r?.size || null;
      const titleRaw = r?.titulo || r?.title || (incident ? ('Hallazgo: ' + incident) : null);
      const title = titleRaw ? String(titleRaw) : ('Hallazgo N°' + String(r.id));
      return { id: r.id, title, date: formatDate(r.created_at || r.fecha), incident, size, lat, lng };
    })
    .filter(Boolean);
  const [offlinePoints, setOfflinePoints] = useState([]);
  useEffect(() => {
    (async () => {
      if (!offlineMode) { setOfflinePoints([]); return; }
      try {
        const [hist, pending] = await Promise.all([
          getReportHistory().catch(() => []),
          getPendingReports().catch(() => []),
        ]);
        const mapHist = (Array.isArray(hist) ? hist : []).map((h) => {
          const d = h?.data || {};
          const lat = Number(d.latitud);
          const lng = Number(d.longitud);
          if (!isFinite(lat) || !isFinite(lng)) return null;
          const incident = null;
          const size = d?.tamano || null;
          const title = 'Hallazgo (offline)';
          return { id: h.id, title, date: formatDate(h.timestamp), incident, size, lat, lng };
        }).filter(Boolean);
        const mapPend = (Array.isArray(pending) ? pending : []).map((p) => {
          const d = p?.data || {};
          const lat = Number(d.latitud);
          const lng = Number(d.longitud);
          if (!isFinite(lat) || !isFinite(lng)) return null;
          const incident = null;
          const size = d?.tamano || null;
          const title = 'Pendiente (offline)';
          return { id: p.id, title, date: formatDate(p.timestamp), incident, size, lat, lng };
        }).filter(Boolean);
        setOfflinePoints([...mapHist, ...mapPend]);
      } catch { setOfflinePoints([]); }
    })();
  }, [offlineMode]);
  const points = [...onlinePoints, ...offlinePoints];
  const lat0 = points.length > 0 ? points[0].lat : -17.7833;
  const lng0 = points.length > 0 ? points[0].lng : -63.1821;
  const mapHtml = `<!DOCTYPE html><html><head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <style>html,body,#map{height:100%;margin:0;padding:0}</style>
  </head><body>
    <div id="map"></div>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script>
      const map=L.map('map', {zoomControl: true, attributionControl: false}).setView([${lat0},${lng0}], ${points.length > 0 ? 12 : 12});
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19, attribution: ''}).addTo(map);
      const pts=${JSON.stringify(points)};
      pts.forEach(p=>{
        const lines=[];
        if (p.title) lines.push('<b>' + p.title + '</b>');
        if (p.incident) lines.push('Incidente: ' + p.incident);
        if (p.size) lines.push('Tamaño: ' + p.size);
        if (p.date) lines.push('Fecha: ' + p.date);
        const html=lines.join('<br/>' );
        L.marker([p.lat,p.lng]).addTo(map).bindPopup(html);
      });
      window.addEventListener('message', (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data && data.action === 'center' && typeof data.lat === 'number' && typeof data.lng === 'number') {
            map.setView([data.lat, data.lng], 14, { animate: true });
          }
        } catch (e) {}
      });
    </script>
  </body></html>`;
  const go = (route) => {
    const local = new Set(['MyReports', 'ReportCreate', 'ApprovedReports', 'AnimalFileCreate', 'Reports', 'Transfers']);
    if (local.has(route)) navigation.navigate(route);
    else navigation.getParent()?.navigate(route);
  };
  const ActionTile = ({ icon, title, subtitle, color, onPress, requireOnline }) => {
    const disabled = offlineMode && !!requireOnline;
    return (
      <Pressable onPress={() => { if (disabled) { Alert.alert('Modo offline', 'No disponible sin internet'); } else { onPress && onPress(); } }} style={{ minWidth: tileW, flex: 1, borderRadius: 14, overflow: 'hidden', borderWidth: 1, borderColor: colors.border, backgroundColor: colors.cardBg, opacity: disabled ? 0.7 : 1 }}>
        <View style={{ height: 124, padding: 16, justifyContent: 'space-between' }}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <View style={{ width: 42, height: 42, borderRadius: 21, backgroundColor: color + '22', alignItems: 'center', justifyContent: 'center', marginRight: 10 }}>
              <MaterialIcons name={icon} size={22} color={color} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ color: colors.textDark, fontWeight: '700', fontSize: 18 }}>{title}</Text>
              {!!subtitle && <Text style={{ color: colors.textLight, marginTop: 2 }}>{subtitle}</Text>}
            </View>
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'flex-end' }}>
            <Text style={{ color: color, fontWeight: '700' }}>Abrir</Text>
          </View>
          {disabled ? (
            <View style={{ marginTop: 8, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8, backgroundColor: colors.warning + '20', borderWidth: 1, borderColor: colors.warning }}>
              <Text style={{ color: colors.warning, fontWeight: '600', fontSize: 12 }}>No disponible sin internet</Text>
            </View>
          ) : null}
        </View>
      </Pressable>
    );
  };

  const MetricCard = ({ value, title, color, icon, progress }) => (
    <View style={{ flex: 1, minWidth: 200, borderRadius: 14, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.cardBg }}>
      <View style={{ padding: 16 }}>
        <Text style={{ color: color, fontWeight: '800', fontSize: 24 }}>{isFinite(value) ? String(value) : '—'}</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 6 }}>
          <Text style={{ color: colors.textDark }}>{title}</Text>
          <View style={{ marginLeft: 'auto' }}>
            <MaterialIcons name={icon} size={20} color={color} />
          </View>
        </View>
        {progress != null ? (
          <View style={{ marginTop: 8 }}>
            <View style={{ height: 6, borderRadius: 3, backgroundColor: colors.inputBg, overflow: 'hidden' }}>
              <View style={{ width: `${Math.max(0, Math.min(100, progress))}%`, height: 6, backgroundColor: color }} />
            </View>
            <Text style={{ color: colors.textLight, marginTop: 4 }}>{Math.round(progress)}% tasa de éxito</Text>
          </View>
        ) : null}
      </View>
    </View>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <ScrollView contentContainerStyle={{ paddingHorizontal: 16, paddingTop: 24, paddingBottom: 32 }}>
        <BrandHeader />
        <View style={{ padding: 16, borderRadius: 12, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.cardBg, marginBottom: 16 }}>
          <Text style={{ color: colors.textDark, fontWeight: '700', fontSize: 18 }}>Elige una acción</Text>
        </View>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 16 }}>
          <ActionTile icon="add-circle" title="Registrar hallazgo" subtitle="Captura y envía un nuevo reporte" color={colors.blue} onPress={() => go('ReportCreate')} />
          {hasRole(['admin', 'encargado']) ? (
            <ActionTile icon="verified" title="Aprobados" subtitle="Gestiona hallazgos aprobados" color={colors.blue} onPress={() => go('ApprovedReports')} requireOnline />
          ) : null}
          {hasRole(['admin', 'encargado']) ? (
            <ActionTile icon="assignment" title="Crear Hoja de Vida" subtitle="Crea ficha de animal" color={colors.blue} onPress={() => go('AnimalFileCreate')} requireOnline />
          ) : null}
          <ActionTile icon="description" title="Hoja de vida" subtitle="Consulta fichas existentes" color={colors.blue} onPress={() => go('HojaDeVida')} requireOnline />
          {hasRole(['veterinario']) ? (
            <ActionTile icon="medical-services" title="Evaluaciones" subtitle="Registra y consulta evaluaciones" color={colors.blue} onPress={() => go('Evaluations')} requireOnline />
          ) : null}
          {hasRole(['cuidador']) ? (
            <ActionTile icon="health-and-safety" title="Cuidados" subtitle="Registra y consulta cuidados" color={colors.blue} onPress={() => go('Cares')} requireOnline />
          ) : null}
          <ActionTile icon="timeline" title="Historial" subtitle="Revisa eventos del animal" color={colors.blue} onPress={() => go('History')} requireOnline />
          <ActionTile icon="cloud-upload" title="Reportes Pendientes" subtitle="Gestiona reportes offline" color={colors.warning} onPress={() => go('PendingReports')} />
          <ActionTile icon="analytics" title="Reportes" subtitle="Indicadores y actividad" color={colors.blue} onPress={() => go('Reports')} requireOnline />
          <ActionTile icon="local-shipping" title="Traslados" subtitle="Gestiona movimientos" color={colors.blue} onPress={() => go('Transfers')} requireOnline />
        </View>
        <View style={{ marginBottom: 16 }}>
          <View style={{ padding: 12, borderRadius: 12, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.cardBg, marginBottom: 8, flexDirection: 'row', alignItems: 'center' }}>
            <MaterialIcons name="map" size={18} color={colors.icon} style={{ marginRight: 8 }} />
            <View style={{ flex: 1 }}>
              <Text style={{ color: colors.textDark, fontWeight: '700', fontSize: 16 }}>Mapa de Centros</Text>
              <Text style={{ color: colors.textLight, marginTop: 2 }}>Explora y selecciona centros</Text>
            </View>
            <View style={{ paddingHorizontal: 10, paddingVertical: 6, borderRadius: 16, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.cardFooterBg }}>
              <Text style={{ color: colors.textDark, fontWeight: '700' }}>{Array.isArray(centers) ? centers.length : 0}</Text>
            </View>
          </View>
          <View style={{ height: 240, borderRadius: 12, overflow: 'hidden', borderWidth: 1, borderColor: colors.border, backgroundColor: colors.cardBg, marginBottom: 12 }}>
            <CentersMap centers={centers} selectedId={selectedCenterId} onSelect={(c) => setSelectedCenterId(c?.id)} height={240} />
          </View>
        </View>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 12 }}>
          <MetricCard value={rescuedCount} title="Animales Rescatados" color={colors.blue} icon="pets" />
          <MetricCard value={releasedCount} title="Devueltos al Hábitat" color={colors.success} icon="check-circle" progress={rescuedCount > 0 ? (releasedCount * 100) / rescuedCount : 0} />
          <MetricCard value={reportsCount} title="Hallazgos Recibidos" color={colors.warning} icon="assignment" />
          <MetricCard value={transfersCount} title="Traslados" color={colors.blue} icon="local-shipping" />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
