import { useState, useEffect } from 'react';
import { View, Text, ScrollView, useWindowDimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors } from '../theme/colors';
import { PrimaryButton } from '../components/Buttons';
import useIsMounted from '../hooks/useIsMounted';

export default function ErrorLogsScreen() {
    const { width } = useWindowDimensions();
    const isWide = width > 600;
    const isTablet = width > 900;
    const containerStyle = isWide ? { maxWidth: isTablet ? 900 : 600, alignSelf: 'center', width: '100%' } : {};

    return (
        <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
            <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16 }}>
                <View style={containerStyle}>
                    <Text style={{ fontSize: 20, fontWeight: 'bold', marginBottom: 16, color: colors.textDark }}>
                        Logs de Errores
                    </Text>
                    <View style={{ padding: 20, backgroundColor: colors.cardBg, borderRadius: 8, alignItems: 'center' }}>
                        <Text style={{ color: colors.textLight, textAlign: 'center' }}>
                            El sistema de logs ha sido desactivado para mejorar el rendimiento.
                        </Text>
                    </View>
                </View>
            </ScrollView>
        </SafeAreaView>
    );
}
