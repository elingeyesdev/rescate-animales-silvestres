import { useEffect, useState } from 'react';
import { View, Text, ActivityIndicator, FlatList, Modal, Pressable, Image, TextInput, ScrollView, useWindowDimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { useAuth } from '../context/AuthContext';
import { Alert } from 'react-native';
import Card from '../components/Card';
import { PrimaryButton, SecondaryButton } from '../components/Buttons';
import { colors } from '../theme/colors';
import { spacing, typography } from '../theme/layout';
import { listMedicalEvaluations, createMedicalEvaluation } from '../api/medicalEvaluations';
import { listAnimalFiles, getAnimalFile } from '../api/animalFiles';
import { MaterialIcons } from '@expo/vector-icons';
import CustomDropdown from '../components/CustomDropdown';
import { resolveImageUrl } from '../api/reports';
import * as ImagePicker from 'expo-image-picker';
import apiClient from '../api/client';
import { listReleases } from '../api/releases';
import useIsMounted from '../hooks/useIsMounted';

export default function EvaluationsScreen({ route, animalFileId: propAnimalFileId }) {
  const isMounted = useIsMounted();
  const navigation = useNavigation();
  const { hasRole } = useAuth();
  const { width } = useWindowDimensions();
  const isWide = width > 600;
  const isTablet = width > 900;
  const containerStyle = isWide ? { maxWidth: isTablet ? 900 : 600, alignSelf: 'center', width: '100%' } : {};

  const paramAnimalFileId = propAnimalFileId ?? route?.params?.animalFileId;
  const [selectedAnimalFileId, setSelectedAnimalFileId] = useState(null);
  const animalFileId = paramAnimalFileId ?? selectedAnimalFileId;
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [file, setFile] = useState(null);
  const [previewImage, setPreviewImage] = useState(null);
  const [pickerLoading, setPickerLoading] = useState(false);
  const [pickerItems, setPickerItems] = useState([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [vetId, setVetId] = useState('');
  const [aptoTraslado, setAptoTraslado] = useState('si');
  const [descripcion, setDescripcion] = useState('');
  const [diagnostico, setDiagnostico] = useState('');
  const [tratamientoId, setTratamientoId] = useState('');
  const [tratamientoTexto, setTratamientoTexto] = useState('');
  const [estadoId, setEstadoId] = useState('');
  const [peso, setPeso] = useState('');
  const [temperatura, setTemperatura] = useState('');
  const [recomendacion, setRecomendacion] = useState('');
  const [observaciones, setObservaciones] = useState('');
  const [image, setImage] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [statusOptions, setStatusOptions] = useState([]);
  const [loadingStatuses, setLoadingStatuses] = useState(false);
  const [vetOptions, setVetOptions] = useState([]);
  const [treatmentOptions, setTreatmentOptions] = useState([]);
  const [hasRelease, setHasRelease] = useState(false);
  const [veterinariansMap, setVeterinariansMap] = useState({}); // Map: id -> nombre
  const [treatmentsMap, setTreatmentsMap] = useState({}); // Map: id -> nombre

  const getColor = () => colors.success;
  const iconName = 'medical-services';

  useEffect(() => {
    (async () => {
      if (!animalFileId) {
        if (isMounted.current) {
          setItems([]);
          setLoading(false);
          setHasRelease(false);
        }
        return;
      }
      try {
        if (page === 1) {
          if (isMounted.current) setLoading(true);
        } else {
          if (isMounted.current) setLoadingMore(true);
        }
        const f = await getAnimalFile(Number(animalFileId)).catch(() => null);
        const data = await listMedicalEvaluations(animalFileId, page);
        const arr = Array.isArray(data) ? data : [];
        
        if (isMounted.current) {
          setFile(f);
          setItems((prev) => (page === 1 ? arr : [...prev, ...arr]));
          if (arr.length === 0) setHasMore(false);
        }

        // Load veterinarian and treatment names for evaluations (optimized: single parallel request)
        if (page === 1 && arr.length > 0) {
          try {
            // Fetch veterinarians and treatments in parallel
            const [vetsRes, treatsRes] = await Promise.all([
              apiClient.get('/veterinarians').catch(() => ({ data: [] })),
              apiClient.get('/treatment-types').catch(() => ({ data: [] })),
            ]);

            const vets = Array.isArray(vetsRes?.data?.data) ? vetsRes.data.data : (Array.isArray(vetsRes?.data) ? vetsRes.data : []);
            const treats = Array.isArray(treatsRes?.data?.data) ? treatsRes.data.data : (Array.isArray(treatsRes?.data) ? treatsRes.data : []);

            // Create maps for quick lookup
            const vetMap = {};
            vets.forEach((v) => {
              if (v?.id) {
                vetMap[String(v.id)] = v?.person?.nombre || v?.nombre || `Veterinario ${v.id}`;
              }
            });

            const treatMap = {};
            treats.forEach((t) => {
              if (t?.id) {
                treatMap[String(t.id)] = t?.nombre || t?.name || `Tratamiento ${t.id}`;
              }
            });

            if (isMounted.current) {
              setVeterinariansMap((prev) => ({ ...prev, ...vetMap }));
              setTreatmentsMap((prev) => ({ ...prev, ...treatMap }));
            }
          } catch (e) {
            console.log('Error loading veterinarians/treatments', e);
          }
        }

        // Check for releases
        const releases = await listReleases(animalFileId).catch(() => []);
        if (isMounted.current) {
          setHasRelease(Array.isArray(releases) && releases.length > 0);
        }
      } catch (e) {
        if (isMounted.current) {
          if (page === 1) setItems([]);
          setHasMore(false);
          setHasRelease(false);
        }
      } finally {
        if (isMounted.current) {
          setLoading(false);
          setLoadingMore(false);
        }
      }
    })();
  }, [animalFileId, page]);

  useEffect(() => {
    (async () => {
      if (animalFileId) return;
      if (isMounted.current) setPickerLoading(true);
      try {
        const data = await listAnimalFiles({});
        if (isMounted.current) setPickerItems(Array.isArray(data) ? data : []);
      } finally {
        if (isMounted.current) setPickerLoading(false);
      }
    })();
  }, [animalFileId]);

  useEffect(() => {
    (async () => {
      if (!animalFileId) return;
      if (isMounted.current) setLoadingStatuses(true);
      try {
        const res = await apiClient.get('/animal-statuses').catch(() => ({ data: [] }));
        const arr = Array.isArray(res?.data?.data) ? res.data.data : (Array.isArray(res?.data) ? res.data : []);
        if (isMounted.current) setStatusOptions(arr);
        const vetsRes = await apiClient.get('/veterinarians').catch(() => ({ data: [] }));
        const vets = Array.isArray(vetsRes?.data?.data) ? vetsRes.data.data : (Array.isArray(vetsRes?.data) ? vetsRes.data : []);
        if (isMounted.current) setVetOptions(Array.isArray(vets) ? vets : []);
        const treatsRes = await apiClient.get('/treatment-types').catch(() => ({ data: [] }));
        const treats = Array.isArray(treatsRes?.data?.data) ? treatsRes.data.data : (Array.isArray(treatsRes?.data) ? treatsRes.data : []);
        if (isMounted.current) setTreatmentOptions(Array.isArray(treats) ? treats : []);
      } finally {
        if (isMounted.current) setLoadingStatuses(false);
      }
    })();
  }, [animalFileId]);

  const pickImageFromGallery = async () => {
    try {
      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        Alert.alert('Permiso denegado', 'Se requiere acceso a la galería.');
        return;
      }
      const res = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        quality: 0.85,
      });
      if (!res.canceled && res.assets?.[0]) {
        const a = res.assets[0];
        const mime = a.mimeType || a.type || '';
        const name = a.fileName || a.uri || '';
        const okMime = String(mime).toLowerCase().startsWith('image/');
        const okExt = /(\.jpe?g|\.png)$/i.test(String(name));
        if (!okMime && !okExt) {
          Alert.alert('Formato inválido', 'Solo JPG o PNG.');
          return;
        }
        if (isMounted.current) setImage(a);
      }
    } catch (e) {
      console.log('Error picking image from gallery', e);
      Alert.alert('Error', 'No se pudo abrir la galería');
    }
  };

  const pickImageFromCamera = async () => {
    try {
      const perm = await ImagePicker.requestCameraPermissionsAsync();
      if (!perm.granted) {
        Alert.alert('Permiso denegado', 'Se requiere acceso a la cámara.');
        return;
      }
      const res = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        quality: 0.8,
      });
      if (!res.canceled && res.assets?.[0]) {
        const a = res.assets[0];
        const mime = a.mimeType || a.type || '';
        const name = a.fileName || a.uri || '';
        const okMime = String(mime).toLowerCase().startsWith('image/');
        const okExt = /(\.jpe?g|\.png)$/i.test(String(name));
        if (!okMime && !okExt) {
          Alert.alert('Formato inválido', 'Solo JPG o PNG.');
          return;
        }
        if (isMounted.current) setImage(a);
      }
    } catch (e) {
      console.log('Error picking image from camera', e);
      Alert.alert('Error', 'No se pudo abrir la cámara');
    }
  };

  const submitEvaluation = async () => {
    if (!animalFileId) return;
    if (!vetId || !aptoTraslado) {
      Alert.alert('Campos requeridos', 'Selecciona veterinario y si es apto para traslado.');
      return;
    }
    if (isMounted.current) setSubmitting(true);
    try {
      const payload = {
        animal_file_id: Number(animalFileId),
        veterinario_id: Number(vetId),
        apto_traslado: String(aptoTraslado),
        descripcion: descripcion || undefined,
        diagnostico: diagnostico || undefined,
        tratamiento_id: tratamientoId ? Number(tratamientoId) : undefined,
        tratamiento_texto: tratamientoId ? undefined : (tratamientoTexto || undefined),
        estado_id: estadoId ? Number(estadoId) : undefined,
        peso: peso ? Number(peso) : undefined,
        temperatura: temperatura ? Number(temperatura) : undefined,
        recomendacion: recomendacion || undefined,
        fecha: (() => {
          const today = new Date();
          const dd = String(today.getDate()).padStart(2, '0');
          const mm = String(today.getMonth() + 1).padStart(2, '0');
          const yyyy = today.getFullYear();
          return `${dd}/${mm}/${yyyy}`; // Fecha de hoy en formato dd/mm/yyyy
        })(),
        observaciones: observaciones || undefined,
      };
      if (image?.uri) {
        const name = image.fileName || image.uri || '';
        const mime = image.mimeType || image.type || '';
        const ext = String(name).toLowerCase().match(/\.(jpe?g|png|gif)$/)?.[1] || '';
        const typeResolved = String(mime).toLowerCase().startsWith('image/') ? mime : (ext === 'png' ? 'image/png' : ext === 'gif' ? 'image/gif' : 'image/jpeg');
        payload.imagen = { uri: image.uri, name: image.fileName || 'evaluacion.jpg', type: typeResolved };
      }
      await createMedicalEvaluation(payload);
      if (isMounted.current) {
        setPage(1);
        setHasMore(true);
        const refreshed = await listMedicalEvaluations(animalFileId, 1);
        if (isMounted.current) setItems(Array.isArray(refreshed) ? refreshed : []);
      }
      Alert.alert('Éxito', 'Evaluación registrada correctamente.', [
        { text: 'OK', onPress: () => { try { navigation.getParent()?.navigate('MyReports'); } catch { } } }
      ]);
    } catch (e) {
      const msg = e?.response?.data?.message || e?.message || 'No se pudo registrar la evaluación';
      const errorsObj = e?.response?.data?.errors || {};
      const errors = Array.isArray(errorsObj) ? errorsObj : Object.values(errorsObj).flat().filter(Boolean);
      const first = errors && errors.length > 0 ? `\n${errors[0]}` : '';
      Alert.alert('Error', `${msg}${first}`);
    } finally {
      if (isMounted.current) setSubmitting(false);
    }
  };

  if (loading) return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg, justifyContent: 'center', alignItems: 'center' }}>
      <ActivityIndicator />
    </SafeAreaView>
  );

  if (!animalFileId) return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <ScrollView style={{ padding: spacing.md }} contentContainerStyle={{ paddingBottom: spacing.lg }} keyboardShouldPersistTaps="handled">
        <View style={containerStyle}>
          <Card>
            <Text style={{ textAlign: 'center', color: colors.textDark, marginBottom: spacing.sm, fontWeight: '600', fontSize: typography.lg }}>Selecciona ficha</Text>
          {pickerLoading ? (
            <View style={{ alignItems: 'center', paddingVertical: spacing.sm }}>
              <ActivityIndicator />
            </View>
          ) : (
            <View>
              <CustomDropdown
                label="Ficha"
                placeholder="Seleccione"
                value={selectedAnimalFileId != null ? String(selectedAnimalFileId) : ''}
                onValueChange={(val) => setSelectedAnimalFileId(val ? Number(val) : null)}
                options={pickerItems.map(item => ({
                  label: String(item?.animal?.nombre || item?.animal_nombre || `Ficha ${item.id}`),
                  value: String(item.id)
                }))}
              />
            </View>
          )}
          </Card>
        </View>
      </ScrollView>
    </SafeAreaView>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <ScrollView style={{ padding: spacing.md }} contentContainerStyle={{ paddingBottom: spacing.md + 60 }} keyboardShouldPersistTaps="handled">
        <View style={containerStyle}>
          <Card>
            <Text style={{ textAlign: 'center', color: colors.textDark, marginBottom: spacing.sm, fontWeight: '600', fontSize: typography.lg }}>Evaluaciones médicas</Text>
          <View style={{ marginBottom: spacing.md }}>
            <View style={{ flexDirection: 'row' }}>
              <View style={{ width: 120, marginRight: spacing.sm }}>
                {(() => {
                  const u = resolveImageUrl(file?.imagen_url || file?.imagen); return u ? (
                    <Image source={{ uri: u }} style={{ width: 120, height: 160, borderRadius: 6, borderWidth: 1, borderColor: colors.border }} />
                  ) : (
                    <View style={{ width: 120, height: 160, borderRadius: 6, borderWidth: 1, borderColor: colors.border, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.cardFooterBg }}>
                      <Text style={{ color: colors.textLight }}>Sin imagen</Text>
                    </View>
                  );
                })()}
              </View>
              <View style={{ flex: 1 }}>
                <View style={{ marginBottom: 6 }}>
                  <Text style={{ color: colors.textDark, fontWeight: '600' }}>Animal</Text>
                  <Text style={{ color: colors.text }}>{file?.animal?.nombre || '—'}</Text>
                </View>
                <View style={{ marginBottom: 6 }}>
                  <Text style={{ color: colors.textDark, fontWeight: '600' }}>Última actualización (no médica)</Text>
                  <Text style={{ color: colors.text }}>{file?.updated_at ? formatDate(file?.updated_at) : '—'}</Text>
                </View>
                <View style={{ marginTop: spacing.xs }}>
                  <Text style={{ color: colors.textDark, fontWeight: '600' }}>Últimas evaluaciones médicas ({items.length})</Text>
                  {items.length === 0 && <Text style={{ color: colors.textLight }}>-</Text>}
                </View>
              </View>
            </View>
          </View>
          <View style={{ marginBottom: spacing.md, borderWidth: 1, borderColor: colors.border, borderRadius: 6, backgroundColor: colors.cardBg }}>
            {hasRelease ? (
              <View style={{ padding: spacing.md }}>
                <View style={{ padding: spacing.sm, backgroundColor: colors.warning + '20', borderRadius: 6, borderWidth: 1, borderColor: colors.warning, marginBottom: spacing.sm }}>
                  <Text style={{ color: colors.textDark, textAlign: 'center', fontSize: typography.sm }}>Este animal tiene una liberación registrada. No se pueden agregar evaluaciones médicas.</Text>
                </View>
              </View>
            ) : (
              <ScrollView style={{ maxHeight: 520 }} contentContainerStyle={{ padding: spacing.sm, paddingBottom: spacing.md + 20 }} nestedScrollEnabled={true}>
                <Text style={{ color: colors.textDark, fontWeight: '600', marginBottom: spacing.xs }}>Registrar evaluación</Text>
                <View style={{ marginBottom: spacing.xs }}>
                  <CustomDropdown
                    label="Veterinario/a responsable"
                    placeholder="Seleccione"
                    value={vetId}
                    onValueChange={setVetId}
                    options={vetOptions.map(v => ({
                      label: String(v?.person?.nombre || v?.nombre || `Veterinario ${v.id}`),
                      value: String(v.id)
                    }))}
                  />
                </View>
                <View style={{ marginBottom: spacing.xs }}>
                  <Text style={{ color: colors.textLight, marginBottom: 4 }}>¿Apto para traslado inmediato?</Text>
                  <View style={{ flexDirection: 'row' }}>
                    {['si', 'no', 'con_restricciones'].map((opt) => (
                      <Pressable key={opt} onPress={() => setAptoTraslado(opt)} style={{ paddingVertical: 8, paddingHorizontal: 12, borderWidth: 1, borderColor: colors.border, borderRadius: 20, marginRight: 8, backgroundColor: aptoTraslado === opt ? colors.cardFooterBg : colors.cardBg }}>
                        <Text style={{ color: colors.text }}>{opt === 'si' ? 'Sí' : (opt === 'no' ? 'No' : 'Con restricciones')}</Text>
                      </Pressable>
                    ))}
                  </View>
                </View>
                <View style={{ marginBottom: spacing.xs }}>
                  <Text style={{ color: colors.textLight, marginBottom: 4 }}>Descripción</Text>
                  <TextInput value={descripcion} onChangeText={setDescripcion} placeholder="Descripción" multiline style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 6, paddingHorizontal: 10, paddingVertical: 8, minHeight: 60, color: colors.text }} />
                </View>
                <View style={{ marginBottom: spacing.xs }}>
                  <Text style={{ color: colors.textLight, marginBottom: 4 }}>Diagnóstico</Text>
                  <TextInput value={diagnostico} onChangeText={setDiagnostico} placeholder="Detalles del diagnóstico" multiline style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 6, paddingHorizontal: 10, paddingVertical: 8, minHeight: 60, color: colors.text }} />
                </View>
                <View style={{ marginBottom: spacing.xs }}>
                  <CustomDropdown
                    label="Tratamiento (catálogo)"
                    placeholder="Seleccione"
                    value={tratamientoId}
                    onValueChange={setTratamientoId}
                    options={treatmentOptions.map(t => ({
                      label: String(t?.nombre || t?.name || `Tratamiento ${t.id}`),
                      value: String(t.id)
                    }))}
                  />
                  <Text style={{ color: colors.textLight, marginTop: 6, marginBottom: 4 }}>Tratamiento (descripción)</Text>
                  <TextInput value={tratamientoTexto} onChangeText={setTratamientoTexto} placeholder="Describe el tratamiento" style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 6, paddingHorizontal: 10, paddingVertical: 8, color: colors.text }} />
                </View>
                <View style={{ marginBottom: spacing.xs }}>
                  <CustomDropdown
                    label="Nuevo estado del animal"
                    placeholder="Seleccione"
                    value={estadoId}
                    onValueChange={setEstadoId}
                    options={statusOptions.map(s => ({
                      label: String(s?.nombre || s?.name || s.id),
                      value: String(s.id)
                    }))}
                  />
                </View>
                <View style={{ flexDirection: 'row' }}>
                  <View style={{ flex: 1, marginRight: 6 }}>
                    <Text style={{ color: colors.textLight, marginBottom: 4 }}>Peso (kg)</Text>
                    <TextInput value={peso} onChangeText={setPeso} placeholder="Peso" keyboardType="numeric" style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 6, paddingHorizontal: 10, paddingVertical: 8, color: colors.text }} />
                  </View>
                  <View style={{ flex: 1, marginLeft: 6 }}>
                    <Text style={{ color: colors.textLight, marginBottom: 4 }}>Temperatura (°C)</Text>
                    <TextInput value={temperatura} onChangeText={setTemperatura} placeholder="Temperatura" keyboardType="numeric" style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 6, paddingHorizontal: 10, paddingVertical: 8, color: colors.text }} />
                  </View>
                </View>
                <View style={{ marginTop: spacing.xs }}>
                  <CustomDropdown
                    label="Recomendación posterior"
                    placeholder="Seleccione"
                    value={recomendacion}
                    onValueChange={setRecomendacion}
                    options={[
                      { label: 'Traslado', value: 'traslado' },
                      { label: 'Observación 24h', value: 'observacion_24h' },
                      { label: 'Nueva revisión', value: 'nueva_revision' },
                      { label: 'Tratamiento prolongado', value: 'tratamiento_prolongado' }
                    ]}
                  />
                </View>
                <View style={{ marginTop: spacing.xs }}>
                  <Text style={{ color: colors.textLight, marginBottom: 4 }}>Observaciones adicionales</Text>
                  <TextInput value={observaciones} onChangeText={setObservaciones} placeholder="Añade observaciones adicionales" multiline style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 6, paddingHorizontal: 10, paddingVertical: 8, minHeight: 60, color: colors.text }} />
                </View>
                <View style={{ marginTop: spacing.xs }}>
                  <Text style={{ color: colors.textLight, marginBottom: 4 }}>Evidencia</Text>
                </View>
                <View style={{ marginBottom: spacing.xs }}>
                  <PrimaryButton title={image ? 'Tomar otra foto' : 'Tomar foto'} onPress={pickImageFromCamera} style={{ marginBottom: spacing.xs }} />
                  <SecondaryButton title={image ? 'Cambiar imagen' : 'Subir imagen'} onPress={pickImageFromGallery} />
                </View>
                {image ? (
                  <View style={{ marginTop: spacing.xs, marginBottom: spacing.xs }}>
                    <Image source={{ uri: image.uri }} style={{ width: '100%', height: 200, borderRadius: 6, borderWidth: 1, borderColor: colors.border }} resizeMode="cover" />
                  </View>
                ) : null}
                <Pressable onPress={submitEvaluation} disabled={submitting || hasRelease} style={{ backgroundColor: hasRelease ? colors.neutral : colors.blue, paddingVertical: 12, borderRadius: 6, alignItems: 'center', marginTop: spacing.sm, opacity: hasRelease ? 0.6 : 1 }}>
                  <Text style={{ color: '#fff', fontWeight: '700' }}>{submitting ? 'Guardando...' : 'Registrar evaluación'}</Text>
                </Pressable>
              </ScrollView>
            )}
          </View>
          {items.length === 0 ? (
            <Text style={{ color: colors.text, marginBottom: spacing.xs }}>Sin evaluaciones</Text>
          ) : (
            <FlatList
              data={items}
              scrollEnabled={false}
              keyExtractor={(item, idx) => String(item.id || idx)}
              renderItem={({ item }) => {
                const title = item.descripcion || 'Evaluación médica';
                const date = formatDate(item.fecha || item.created_at);
                const time = item.hora || item.time || null;
                const color = getColor();
                const hasDetails = Array.isArray(item.details) && item.details.length > 0;
                const raw = item.imagen_url || item.image_url || item.image || null;
                const imgUri = raw ? resolveImageUrl(raw) : null;
                return (
                  <View style={{ flexDirection: 'row', paddingVertical: spacing.sm }}>
                    <View style={{ width: 28, alignItems: 'center' }}>
                      <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: color, marginTop: spacing.xs }} />
                    </View>
                    <View style={{ flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: 8, padding: spacing.sm, backgroundColor: colors.cardBg }}>
                      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: spacing.xs }}>
                        <MaterialIcons name={iconName} size={18} color={color} style={{ marginRight: 8 }} />
                        <Text style={{ color: colors.textDark, fontWeight: '600', fontSize: typography.md }}>{title}</Text>
                      </View>
                      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: spacing.xs }}>
                        {/*<MaterialIcons name="access-time" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                        <Text style={{ color: colors.textLight, marginRight: 12 }}>{time || '—'}</Text>*/}
                        <MaterialIcons name="event" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                        <Text style={{ color: colors.textLight }}>{date}</Text>
                      </View>
                      <View style={{ marginBottom: spacing.xs }}>
                        <View style={{ flexDirection: 'row', marginBottom: 4 }}>
                          <Text style={{ color: colors.textLight, marginRight: 6 }}>Veterinario:</Text>
                          <Text style={{ color: colors.text }}>
                            {item?.veterinario?.nombre ||
                              veterinariansMap[String(item?.veterinario_id || item?.veterinario?.id)] ||
                              'N/D'}
                          </Text>
                        </View>
                        <View style={{ flexDirection: 'row', marginBottom: 4 }}>
                          <Text style={{ color: colors.textLight, marginRight: 6 }}>Tratamiento:</Text>
                          <Text style={{ color: colors.text }}>
                            {item?.tratamiento?.nombre ||
                              item?.tratamiento_texto ||
                              treatmentsMap[String(item?.tratamiento_id || item?.tratamiento?.id)] ||
                              'N/D'}
                          </Text>
                        </View>
                      </View>
                      {hasDetails ? (
                        <View style={{ marginBottom: spacing.xs }}>
                          {item.details.map((d, idx) => (
                            <View key={String(idx)} style={{ flexDirection: 'row', marginBottom: 4 }}>
                              <Text style={{ color: colors.textLight, marginRight: 6 }}>{String(d.label || 'Dato')}:</Text>
                              <Text style={{ color: colors.text }}>{String(d.value || '')}</Text>
                            </View>
                          ))}
                        </View>
                      ) : null}
                      {imgUri ? (
                        <View style={{ marginTop: spacing.sm, alignItems: 'flex-end' }}>
                          {renderThumb(imgUri, (u) => setPreviewImage(u))}
                        </View>
                      ) : null}
                    </View>
                  </View>
                );
              }}
              onEndReachedThreshold={0.5}
              onEndReached={() => {
                if (!animalFileId) return;
                if (loadingMore) return;
                if (!hasMore) return;
                setPage((p) => p + 1);
              }}
            />
          )}
          </Card>
        </View>
        <Modal visible={!!previewImage} transparent animationType="fade" onRequestClose={() => setPreviewImage(null)}>
          <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' }}>
            <View style={{ width: '88%', maxWidth: 500, backgroundColor: colors.cardBg, borderRadius: 8, padding: spacing.md }}>
              <Text style={{ color: colors.textDark, fontWeight: '600', textAlign: 'center', marginBottom: spacing.sm }}>Imagen</Text>
              {previewImage ? (
                <Image source={{ uri: String(previewImage) }} style={{ width: '100%', height: 280, borderRadius: 6 }} resizeMode="cover" />
              ) : null}
              <Pressable onPress={() => setPreviewImage(null)} style={{ marginTop: spacing.md, alignItems: 'center', backgroundColor: colors.neutral, padding: spacing.sm, borderRadius: 6 }}>
                <Text style={{ color: colors.text, fontWeight: '600' }}>Cerrar</Text>
              </Pressable>
            </View>
          </View>
        </Modal>
      </ScrollView>
      {hasRole(['veterinario']) ? (
        <View style={{ position: 'absolute', left: spacing.md, right: spacing.md, bottom: spacing.md }}>
          <PrimaryButton title="Registrar evaluación" onPress={submitEvaluation} disabled={submitting || !animalFileId || !vetId || !aptoTraslado} />
        </View>
      ) : null}
    </SafeAreaView>
  );
}
const isValidHttp = (u) => typeof u === 'string' && (u.startsWith('http://') || u.startsWith('https://'));
const renderThumb = (uri, onPress) => {
  if (uri && isValidHttp(uri)) {
    return (
      <Pressable onPress={() => onPress(uri)} accessibilityLabel="Abrir imagen de evaluación">
        <Image source={{ uri: String(uri) }} style={{ width: 120, height: 90, borderRadius: 6, borderWidth: 1, borderColor: colors.border }} />
      </Pressable>
    );
  }
  return (
    <View style={{ width: 120, height: 90, borderRadius: 6, borderWidth: 1, borderColor: colors.border, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.cardFooterBg }}>
      <MaterialIcons name="image" size={22} color={colors.icon} />
      <Text style={{ color: colors.textLight, marginTop: 4 }}>Sin imagen</Text>
    </View>
  );
};
const formatDate = (s) => {
  if (!s) return 'N/D';
  const d = new Date(s);
  if (isNaN(d.getTime())) return String(s);
  const dd = String(d.getDate()).padStart(2, '0');
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const yy = d.getFullYear();
  return `${dd}/${mm}/${yy}`;
};
