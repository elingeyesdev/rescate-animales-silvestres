import { useEffect, useState } from 'react';
import { View, Text, ActivityIndicator, FlatList, Pressable, Image, TextInput, ScrollView, Alert, Modal, useWindowDimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '../context/AuthContext';
import { useNavigation } from '@react-navigation/native';
import Card from '../components/Card';
import { PrimaryButton, SecondaryButton } from '../components/Buttons';
import { colors } from '../theme/colors';
import { spacing, typography } from '../theme/layout';
import { listAnimalCares, createAnimalCare } from '../api/animalCares';
import { listAnimalFiles } from '../api/animalFiles';
// Picker removed
import { MaterialIcons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import apiClient from '../api/client';
import { listAnimalHistories } from '../api/animalHistories';
import { listReleases } from '../api/releases';
import useIsMounted from '../hooks/useIsMounted';
import CustomDropdown from '../components/CustomDropdown';

export default function CaresScreen({ route, animalFileId: propAnimalFileId }) {
  const navigation = useNavigation();
  const { hasRole } = useAuth();
  const isMounted = useIsMounted();
  const { width } = useWindowDimensions();
  const isWide = width > 600;
  const isTablet = width > 900;
  const containerStyle = isWide ? { maxWidth: isTablet ? 900 : 600, alignSelf: 'center', width: '100%' } : {};

  const paramAnimalFileId = propAnimalFileId ?? route?.params?.animalFileId;
  const [selectedAnimalFileId, setSelectedAnimalFileId] = useState(null);
  const animalFileId = paramAnimalFileId ?? selectedAnimalFileId;
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pickerLoading, setPickerLoading] = useState(false);
  const [pickerItems, setPickerItems] = useState([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [careTypeId, setCareTypeId] = useState('');
  const [careTypeOptions, setCareTypeOptions] = useState([]);
  const [descripcion, setDescripcion] = useState('');
  const [observaciones, setObservaciones] = useState('');
  const [image, setImage] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [hasRelease, setHasRelease] = useState(false);

  const getIconAndColor = (tipoNombre) => {
    const t = String(tipoNombre || '').toLowerCase();
    if (t.includes('alimen')) return { icon: 'restaurant', color: colors.blue };
    if (t.includes('higien')) return { icon: 'local-laundry-service', color: colors.warning };
    if (t.includes('vacun') || t.includes('medic')) return { icon: 'local-hospital', color: colors.success };
    return { icon: 'info', color: colors.neutral };
  };

  useEffect(() => {
    (async () => {
      if (!animalFileId) {
        if (isMounted.current) {
          setItems([]);
          setLoading(false);
          setHasRelease(false);
        }
        return;
      }
      try {
        if (isMounted.current) {
          if (page === 1) setLoading(true);
          else setLoadingMore(true);
        }
        const data = await listAnimalCares(animalFileId, page);
        if (isMounted.current) {
          const arr = Array.isArray(data) ? data : [];
          setItems((prev) => (page === 1 ? arr : [...prev, ...arr]));
          if (arr.length === 0) setHasMore(false);
        }
        // Check for releases
        if (page === 1) {
          const releases = await listReleases(animalFileId).catch(() => []);
          if (isMounted.current) {
            setHasRelease(Array.isArray(releases) && releases.length > 0);
          }
        }
      } catch (e) {
        if (isMounted.current) {
          if (page === 1) setItems([]);
          setHasMore(false);
          setHasRelease(false);
          console.error("Error loading cares:", e);
        }
      } finally {
        if (isMounted.current) {
          setLoading(false);
          setLoadingMore(false);
        }
      }
    })();
  }, [animalFileId, page, isMounted]);

  useEffect(() => {
    (async () => {
      if (animalFileId) return;
      if (isMounted.current) setPickerLoading(true);
      try {
        const data = await listAnimalFiles({});
        if (isMounted.current) {
          setPickerItems(Array.isArray(data) ? data : []);
        }
      } catch (e) {
        console.error("Error loading animal files:", e);
      } finally {
        if (isMounted.current) setPickerLoading(false);
      }
    })();
  }, [animalFileId, isMounted]);

  useEffect(() => {
    (async () => {
      if (!animalFileId) return;
      try {
        const res = await apiClient.get('/care-types').catch(() => ({ data: [] }));
        if (isMounted.current) {
          const arr = Array.isArray(res?.data?.data) ? res.data.data : (Array.isArray(res?.data) ? res.data : []);
          setCareTypeOptions(Array.isArray(arr) ? arr : []);
        }
      } catch (e) {
         console.error("Error loading care types:", e);
      }
    })();
  }, [animalFileId, isMounted]);

  const pickImageFromGallery = async () => {
    try {
        const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (!perm.granted) {
            Alert.alert('Permiso denegado', 'Se requiere acceso a la galería para adjuntar imágenes.');
            return;
        }
        const res = await ImagePicker.launchImageLibraryAsync({
          mediaTypes: ImagePicker.MediaTypeOptions.Images,
          quality: 0.85,
        });
        if (!res.canceled && res.assets?.[0]) {
          const a = res.assets[0];
          const mime = a.mimeType || a.type || '';
          const name = a.fileName || a.uri || '';
          const okMime = String(mime).toLowerCase().startsWith('image/');
          const okExt = /\.(jpe?g|png)$/i.test(String(name));
          if (!okMime && !okExt) {
             Alert.alert('Formato inválido', 'Solo se permiten imágenes JPG o PNG.');
             return;
          }
          if (isMounted.current) setImage(a);
        }
    } catch (e) {
        console.error("Error picking image from gallery:", e);
        Alert.alert('Error', 'No se pudo abrir la galería.');
    }
  };

  const pickImageFromCamera = async () => {
    try {
        const perm = await ImagePicker.requestCameraPermissionsAsync();
        if (!perm.granted) {
            Alert.alert('Permiso denegado', 'Se requiere acceso a la cámara.');
            return;
        }
        const res = await ImagePicker.launchCameraAsync({
          mediaTypes: ImagePicker.MediaTypeOptions.Images,
          quality: 0.8,
        });
        if (!res.canceled && res.assets?.[0]) {
          const a = res.assets[0];
          const mime = a.mimeType || a.type || '';
          const name = a.fileName || a.uri || '';
          const okMime = String(mime).toLowerCase().startsWith('image/');
          const okExt = /\.(jpe?g|png)$/i.test(String(name));
          if (!okMime && !okExt) {
             Alert.alert('Formato inválido', 'Solo se permiten imágenes JPG o PNG.');
             return;
          }
          if (isMounted.current) setImage(a);
        }
    } catch (e) {
        console.error("Error taking photo:", e);
        Alert.alert('Error', 'No se pudo abrir la cámara.');
    }
  };

  const submitCare = async () => {
    if (!animalFileId) return;
    if (!careTypeId) {
        Alert.alert('Error', 'Debes seleccionar un tipo de cuidado.');
        return;
    }
    if (isMounted.current) setSubmitting(true);
    try {
      const payload = {
        animal_file_id: Number(animalFileId),
        tipo_cuidado_id: Number(careTypeId),
        descripcion: descripcion || undefined,
        observaciones: observaciones || undefined,
        fecha: (() => {
          const today = new Date();
          const dd = String(today.getDate()).padStart(2, '0');
          const mm = String(today.getMonth() + 1).padStart(2, '0');
          const yyyy = today.getFullYear();
          return `${dd}/${mm}/${yyyy}`; // Fecha de hoy en formato dd/mm/yyyy
        })(),
      };
      if (image?.uri) {
        const name = image.fileName || image.uri || '';
        const mime = image.mimeType || image.type || '';
        const ext = String(name).toLowerCase().match(/\.(jpe?g|png|gif)$/)?.[1] || '';
        const typeResolved = String(mime).toLowerCase().startsWith('image/') ? mime : (ext === 'png' ? 'image/png' : ext === 'gif' ? 'image/gif' : 'image/jpeg');
        payload.imagen = { uri: image.uri, name: image.fileName || 'cuidado.jpg', type: typeResolved };
      }
      await createAnimalCare(payload);
      if (isMounted.current) {
          setPage(1);
          setHasMore(true);
          // Limpiar formulario
          setDescripcion('');
          setObservaciones('');
          setImage(null);
          setCareTypeId('');
      }
      const refreshed = await listAnimalCares(animalFileId, 1);
      if (isMounted.current) {
          setItems(Array.isArray(refreshed) ? refreshed : []);
      }
      // Actualizar historial en segundo plano
      listAnimalHistories(Number(animalFileId)).catch(() => {});
      
      Alert.alert("Éxito", "Cuidado registrado correctamente");
    } catch (e) {
      console.error("Error submitting care:", e);
      const msg = e?.response?.data?.message || e?.message || 'No se pudo registrar el cuidado';
      const errorsObj = e?.response?.data?.errors || {};
      const errors = Array.isArray(errorsObj) ? errorsObj : Object.values(errorsObj).flat().filter(Boolean);
      const first = errors && errors.length > 0 ? `\n${errors[0]}` : '';
      Alert.alert('Error', `${msg}${first}`);
    } finally {
      if (isMounted.current) setSubmitting(false);
    }
  };

  if (loading) return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg, justifyContent: 'center', alignItems: 'center' }}>
      <ActivityIndicator />
    </SafeAreaView>
  );

  if (!animalFileId) return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <ScrollView style={{ padding: spacing.md }} contentContainerStyle={{ paddingBottom: spacing.lg }} keyboardShouldPersistTaps="handled">
        <View style={containerStyle}>
          <Card>
            <Text style={{ textAlign: 'center', color: colors.textDark, marginBottom: spacing.sm, fontWeight: '600', fontSize: typography.lg }}>Selecciona ficha</Text>
            {pickerLoading ? (
              <View style={{ alignItems: 'center', paddingVertical: spacing.sm }}>
                <ActivityIndicator />
              </View>
            ) : (
              <CustomDropdown 
                label="Selecciona ficha"
                value={selectedAnimalFileId != null ? String(selectedAnimalFileId) : ''}
                options={pickerItems.map(item => ({
                  label: String(item?.animal?.nombre || item?.animal_nombre || `Ficha ${item.id}`),
                  value: String(item.id)
                }))}
                onValueChange={(val) => setSelectedAnimalFileId(val ? Number(val) : null)}
                loading={pickerLoading}
              />
            )}
          </Card>
        </View>
      </ScrollView>
    </SafeAreaView>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <ScrollView style={{ padding: spacing.md }} contentContainerStyle={{ paddingBottom: spacing.lg }} keyboardShouldPersistTaps="handled">
        <View style={containerStyle}>
          <Card>
            <Text style={{ textAlign: 'center', color: colors.textDark, marginBottom: spacing.sm, fontWeight: '600', fontSize: typography.lg }}>Cuidados</Text>
          <View style={{ marginBottom: spacing.md, borderWidth: 1, borderColor: colors.border, borderRadius: 6, backgroundColor: colors.cardBg }}>
            <ScrollView style={{ maxHeight: 520 }} contentContainerStyle={{ padding: spacing.sm }}>
              {hasRelease ? (
                <View style={{ padding: spacing.sm, backgroundColor: colors.warning + '20', borderRadius: 6, borderWidth: 1, borderColor: colors.warning, marginBottom: spacing.sm }}>
                  <Text style={{ color: colors.textDark, textAlign: 'center', fontSize: typography.sm }}>Este animal tiene una liberación registrada. No se pueden agregar cuidados.</Text>
                </View>
              ) : (
                <>
                  <Text style={{ color: colors.textDark, fontWeight: '600', marginBottom: spacing.xs }}>Registrar cuidado</Text>
                  <View style={{ marginBottom: spacing.xs }}>
                    <Text style={{ color: colors.textLight, marginBottom: 4 }}>Tipo de cuidado (catálogo)</Text>
                    <CustomDropdown 
                      label="Tipo de cuidado"
                      value={careTypeId}
                      options={careTypeOptions.map(t => ({
                        label: String(t?.nombre || t?.name || `Cuidado ${t.id}`),
                        value: String(t.id)
                      }))}
                      onValueChange={(val) => setCareTypeId(val ? String(val) : '')}
                    />
                  </View>
                  <View style={{ marginBottom: spacing.xs }}>
                    <Text style={{ color: colors.textLight, marginBottom: 4 }}>Descripción del cuidado</Text>
                    <TextInput value={descripcion} onChangeText={setDescripcion} placeholder="Describe el cuidado realizado" multiline style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 6, paddingHorizontal: 10, paddingVertical: 8, minHeight: 60, color: colors.text }} />
                  </View>
                  <View style={{ marginBottom: spacing.xs }}>
                    <Text style={{ color: colors.textLight, marginBottom: 4 }}>Observaciones adicionales</Text>
                    <TextInput value={observaciones} onChangeText={setObservaciones} placeholder="Añade observaciones adicionales" multiline style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 6, paddingHorizontal: 10, paddingVertical: 8, minHeight: 60, color: colors.text }} />
                  </View>
                  <View style={{ marginTop: spacing.xs }}>
                    <Text style={{ color: colors.textLight, marginBottom: 4 }}>Evidencia</Text>
                  </View>
                  <View style={{ marginBottom: spacing.xs }}>
                    <PrimaryButton title={image ? 'Tomar otra foto' : 'Tomar foto'} onPress={pickImageFromCamera} style={{ marginBottom: spacing.xs }} />
                    <SecondaryButton title={image ? 'Cambiar imagen' : 'Subir imagen'} onPress={pickImageFromGallery} />
                  </View>
                  {image ? (
                    <View style={{ marginTop: spacing.xs, marginBottom: spacing.xs }}>
                      <Image source={{ uri: image.uri }} style={{ width: '100%', height: 200, borderRadius: 6, borderWidth: 1, borderColor: colors.border }} resizeMode="cover" />
                    </View>
                  ) : null}
                  <Pressable onPress={submitCare} disabled={submitting || hasRelease} style={{ backgroundColor: hasRelease ? colors.neutral : colors.blue, paddingVertical: 12, borderRadius: 6, alignItems: 'center', marginTop: spacing.sm, opacity: hasRelease ? 0.6 : 1 }}>
                    <Text style={{ color: '#fff', fontWeight: '700' }}>{submitting ? 'Guardando...' : 'Registrar Cuidado'}</Text>
                  </Pressable>
                </>
              )}
            </ScrollView>
          </View>
          {items.length === 0 ? (
            <Text style={{ color: colors.text }}>Sin cuidados registrados</Text>
          ) : (
            <FlatList
              data={items}
              scrollEnabled={false}
              keyExtractor={(item, idx) => String(item.id || idx)}
              renderItem={({ item }) => {
                const tipo = item?.tipo?.nombre || item?.tipo_nombre || 'Cuidado';
                const dateSource = item.fecha || item.created_at;
                const date = formatDate(dateSource);
                const time = item.hora || item.time || formatTime(dateSource);
                const { icon, color } = getIconAndColor(tipo);
                const hasDetails = Array.isArray(item.details) && item.details.length > 0;
                return (
                  <View style={{ flexDirection: 'row', paddingVertical: spacing.sm }}>
                    <View style={{ width: 28, alignItems: 'center' }}>
                      <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: color, marginTop: spacing.xs }} />
                    </View>
                    <View style={{ flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: 8, padding: spacing.sm, backgroundColor: colors.cardBg }}>
                      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: spacing.xs }}>
                        <MaterialIcons name={icon} size={18} color={color} style={{ marginRight: 8 }} />
                        <Text style={{ color: colors.textDark, fontWeight: '600', fontSize: typography.md }}>{tipo}</Text>
                      </View>
                      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: spacing.xs }}>
                        {/*<MaterialIcons name="access-time" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                        <Text style={{ color: colors.textLight, marginRight: 12 }}>{time || '—'}</Text>*/}
                        <MaterialIcons name="event" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                        <Text style={{ color: colors.textLight }}>{date}</Text>
                      </View>
                      {!!(item.descripcion || item.detalle) && (
                        <Text style={{ color: colors.text }}>{item.descripcion || item.detalle}</Text>
                      )}
                      {hasDetails ? (
                        <View style={{ marginTop: spacing.xs }}>
                          {item.details.map((d, idx) => (
                            <View key={String(idx)} style={{ flexDirection: 'row', marginBottom: 4 }}>
                              <Text style={{ color: colors.textLight, marginRight: 6 }}>{String(d.label || 'Dato')}:</Text>
                              <Text style={{ color: colors.text }}>{String(d.value || '')}</Text>
                            </View>
                          ))}
                        </View>
                      ) : null}
                    </View>
                  </View>
                );
              }}
              onEndReachedThreshold={0.5}
              onEndReached={() => {
                if (!animalFileId) return;
                if (loadingMore) return;
                if (!hasMore) return;
                setPage((p) => p + 1);
              }}
            />
          )}
          </Card>
        </View>
      </ScrollView>
      {hasRole(['cuidador']) ? (
        <View style={{ position: 'absolute', left: spacing.md, right: spacing.md, bottom: spacing.md }}>
          <PrimaryButton title="Registrar Cuidado" onPress={submitCare} disabled={submitting || !animalFileId || !careTypeId || hasRelease} />
        </View>
      ) : null}
    </SafeAreaView>
  );
}
const formatDate = (s) => {
  if (!s) return 'N/D';
  const d = new Date(s);
  if (isNaN(d.getTime())) return String(s);
  const dd = String(d.getDate()).padStart(2, '0');
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const yy = d.getFullYear();
  return `${dd}/${mm}/${yy}`;
};

const formatTime = (s) => {
  if (!s) return null;
  const d = new Date(s);
  if (isNaN(d.getTime())) return null;
  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  return `${hh}:${mm}`;
};
