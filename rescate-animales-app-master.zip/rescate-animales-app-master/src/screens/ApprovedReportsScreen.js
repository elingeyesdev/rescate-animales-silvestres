import { useEffect, useState } from 'react';
import { View, Text, FlatList, Pressable, Alert, Image, Modal, ScrollView, useWindowDimensions } from 'react-native';
import Card from '../components/Card';

import { colors } from '../theme/colors';
import { listReports, resolveImageUrl } from '../api/reports';
import { listTransfers } from '../api/transfers';
import apiClient from '../api/client';
import { listReleases } from '../api/releases';
import { listAnimalFiles } from '../api/animalFiles';
import { SafeAreaView } from 'react-native-safe-area-context';
import MapPreview from '../components/MapPreview';
import { Linking } from 'react-native';
import { useAuth } from '../context/AuthContext';
import { useNavigation } from '@react-navigation/native';
import { spacing, typography } from '../theme/layout';
import { PrimaryButton } from '../components/Buttons';
import useIsMounted from '../hooks/useIsMounted';

const isValidHttp = (u) => typeof u === 'string' && (u.startsWith('http://') || u.startsWith('https://'));

export default function ApprovedReportsScreen() {
  const [items, setItems] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const { isAuthenticated, offlineMode } = useAuth();
  const [selected, setSelected] = useState(null);
  const navigation = useNavigation();
  const [transfersMap, setTransfersMap] = useState({}); // Mapa de report_id -> tiene primer traslado
  const [releasesMap, setReleasesMap] = useState({}); // Mapa de report_id -> tiene liberación
  const isMounted = useIsMounted();
  const { width } = useWindowDimensions();
  const isWide = width > 600;
  const isTablet = width > 900;
  const containerStyle = isWide ? { maxWidth: isTablet ? 900 : 600, alignSelf: 'center', width: '100%' } : {};

  const load = async () => {
    try {
      if (offlineMode) { if (isMounted.current) setItems([]); return; }
      const all = await listReports({ aprobado: 1 });
      const approved = Array.isArray(all) ? all : [];
      if (isMounted.current) setItems(approved);

      // Cargar todos los transfers para verificar primer_traslado
      try {
        // Obtener todos los transfers directamente desde la API
        const transfersRes = await apiClient.get('/transfers').catch(() => ({ data: [] }));
        const transfers = Array.isArray(transfersRes?.data?.data)
          ? transfersRes.data.data
          : (Array.isArray(transfersRes?.data) ? transfersRes.data : []);

        // Crear un mapa: report_id -> tiene primer traslado
        const map = {};
        transfers.forEach((t) => {
          const reportId = t?.report_id || t?.reporte_id || t?.reportId;
          if (reportId) {
            const hasFirst = t?.primer_traslado === true ||
              t?.primer_traslado === 1 ||
              String(t?.primer_traslado).toLowerCase() === 'true';
            if (hasFirst) {
              map[String(reportId)] = true;
            }
          }
        });
        if (isMounted.current) setTransfersMap(map);
      } catch (e) {
        console.log('Error cargando transfers', e?.response || e);
        if (isMounted.current) setTransfersMap({});
      }

      // Verificar releases para cada report aprobado
      const releasesMapLocal = {};
      for (const report of approved) {
        const animalId = report?.animal?.id || report?.animal_id;
        if (animalId) {
          try {
            // Buscar animalFile con ese animal_id
            const files = await listAnimalFiles({ animal_id: animalId }).catch(() => []);
            if (Array.isArray(files) && files.length > 0) {
              const animalFileId = files[0]?.id;
              if (animalFileId) {
                const releases = await listReleases(animalFileId).catch(() => []);
                if (Array.isArray(releases) && releases.length > 0) {
                  releasesMapLocal[String(report.id)] = true;
                }
              }
            }
          } catch (e) {
            console.log('Error verificando releases para report', report.id, e);
          }
        }
      }
      if (isMounted.current) setReleasesMap(releasesMapLocal);
    } catch (e) {
      console.log('Error cargando reports', e?.response || e);
    }
  };

  // Verificar si un report tiene primer traslado
  const hasFirstTransfer = (reportId) => {
    if (!reportId) return false;
    return !!transfersMap[String(reportId)];
  };

  // Verificar si un report tiene liberación
  const hasRelease = (reportId) => {
    if (!reportId) return false;
    return !!releasesMap[String(reportId)];
  };

  const formatDate = (s) => {
    if (!s) return 'N/D';
    const d = new Date(s);
    if (isNaN(d.getTime())) return String(s);
    const dd = String(d.getDate()).padStart(2, '0');
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const yy = d.getFullYear();
    return `${dd}/${mm}/${yy}`;
  };

  useEffect(() => {
    if (isAuthenticated) {
      load();
    } else {
      setItems([]);
    }
  }, [isAuthenticated]);

  const promptFirstTransfer = (report) => {
    // Verificar si el animal tiene liberación antes de navegar
    if (hasRelease(report.id)) {
      Alert.alert('No disponible', 'Este animal tiene una liberación registrada. No se pueden realizar traslados.');
      return;
    }
    navigation.getParent()?.navigate('Transfers', { reportId: report.id, reporte_id: report.id, primer_traslado: true });
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <ScrollView contentContainerStyle={{ paddingBottom: spacing.md + 20 }} keyboardShouldPersistTaps="handled">
        <View style={containerStyle}>
          <Card>
            <Text style={{ textAlign: 'center', color: colors.textDark, marginBottom: 12 }}>Hallazgos aprobados</Text>
            <View style={{ marginBottom: spacing.sm }}>
              <PrimaryButton
                title={refreshing ? 'Actualizando...' : 'Actualizar'}
                accessibilityLabel="Actualizar lista de hallazgos aprobados"
                disabled={refreshing}
                onPress={async () => { setRefreshing(true); await load(); setRefreshing(false); }}
              />
            </View>
            {isAuthenticated ? (
              items.length === 0 ? (
                <View style={{ paddingVertical: 20, alignItems: 'center' }}>
                  <Text style={{ color: colors.textLight, textAlign: 'center' }}>No hay hallazgos aprobados</Text>
                  <Text style={{ color: colors.text, textAlign: 'center', marginTop: 6 }}>Cuando se aprueben, aparecerán aquí</Text>
                </View>
              ) : (
                <View>
                  {Array.isArray(items) && items.map((item) => item && item.id ? (
                    <View key={String(item.id)} style={{ marginBottom: spacing.md, borderWidth: 1, borderColor: colors.border, borderRadius: 6, padding: spacing.sm, backgroundColor: colors.cardBg }}>
                      {!!(item?.imagen_url || item?.imagen) && (
                        <View style={{ marginBottom: spacing.sm }}>
                          <Text style={{ color: colors.textDark, fontWeight: '600', marginBottom: spacing.xs }}>Imagen</Text>
                          {(() => {
                            const u = resolveImageUrl(item.imagen_url || item.imagen); return isValidHttp(u) ? (
                              <Image source={{ uri: u }} style={{ width: '100%', height: 160, borderRadius: 6 }} />
                            ) : (
                              <View style={{ width: '100%', height: 160, borderRadius: 6, borderWidth: 1, borderColor: colors.border, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.cardFooterBg }}>
                                <Text style={{ color: colors.textLight }}>Sin imagen válida</Text>
                              </View>
                            );
                          })()}
                        </View>
                      )}
                      <View style={{ marginTop: spacing.xs }}>
                        <Text style={{ color: colors.textDark, fontWeight: '600', marginBottom: spacing.xs }}>Datos del reporte</Text>
                        <Text style={{ color: colors.text }}>Aprobado: Sí</Text>
                        {!!item?.created_at && (
                          <Text style={{ color: colors.text }}>Fecha: {formatDate(item.created_at)}</Text>
                        )}
                        {!!item?.direccion && (
                          <Text style={{ color: colors.text }}>Dirección: {item.direccion}</Text>
                        )}
                        {!!(item?.condicion_inicial?.nombre || item?.condicion_inicial_nombre) && (
                          <Text style={{ color: colors.text }}>Condición: {item?.condicion_inicial?.nombre || item?.condicion_inicial_nombre}</Text>
                        )}
                        {!!(item?.tipo_incidente?.nombre || item?.tipo_incidente_nombre) && (
                          <Text style={{ color: colors.text }}>Incidente: {item?.tipo_incidente?.nombre || item?.tipo_incidente_nombre}</Text>
                        )}
                        {!!item?.tamano && (
                          <Text style={{ color: colors.text }}>Tamaño: {item.tamano}</Text>
                        )}
                        <Text style={{ color: colors.text }}>Se mueve: {Number(item.puede_moverse) === 1 ? 'Sí' : 'No'}</Text>
                        {!!item?.urgencia && (
                          <Text style={{ color: colors.text }}>Urgencia: {item.urgencia}</Text>
                        )}
                        {!!item?.observaciones && (
                          <Text style={{ color: colors.text }}>Observaciones: {item.observaciones}</Text>
                        )}
                      </View>
                      {hasRelease(item.id) ? (
                        <View style={{ marginTop: spacing.sm, padding: spacing.sm, backgroundColor: colors.warning + '20', borderRadius: 6, borderWidth: 1, borderColor: colors.warning }}>
                          <Text style={{ color: colors.textDark, textAlign: 'center', fontSize: typography.sm }}>Este animal tiene una liberación registrada. No se pueden realizar traslados.</Text>
                        </View>
                      ) : (
                        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: spacing.sm, flexWrap: 'wrap' }}>
                          <Pressable accessibilityLabel="Ver detalles del hallazgo" onPress={() => setSelected(item)} style={{ backgroundColor: colors.neutral, padding: spacing.sm, borderRadius: 6, flex: 1, marginRight: spacing.xs, marginBottom: spacing.xs, alignItems: 'center', minWidth: '48%' }}>
                            <Text style={{ color: colors.text, fontWeight: '600' }}>Ver más</Text>
                          </Pressable>
                          {!hasFirstTransfer(item.id) ? (
                            <Pressable accessibilityLabel="Primer traslado" onPress={() => promptFirstTransfer(item)} style={{ backgroundColor: colors.success, padding: spacing.sm, borderRadius: 6, flex: 1, marginBottom: spacing.xs, alignItems: 'center', minWidth: '48%' }}>
                              <Text style={{ color: '#fff', fontWeight: '600' }}>Primer traslado</Text>
                            </Pressable>
                          ) : null}
                        </View>
                      )}
                    </View>
                  ) : null)}
                </View>
              )
            ) : (
              <Text style={{ color: colors.textDark, textAlign: 'center' }}>Inicia sesión para ver aprobados</Text>
            )}
            <Modal visible={!!selected} animationType="slide" transparent={false} onRequestClose={() => setSelected(null)}>
              <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
                <Card>
                  <Text style={{ textAlign: 'center', color: colors.textDark, marginBottom: spacing.sm, fontWeight: '600', fontSize: typography.lg }}>Detalle del hallazgo</Text>
                  {(selected?.latitud && selected?.longitud) ? (
                    <View style={{ marginBottom: spacing.sm }}>
                      <Text style={{ color: colors.textDark, fontWeight: '600', marginBottom: spacing.xs }}>Ubicación</Text>
                      <MapPreview lat={Number(selected.latitud)} lng={Number(selected.longitud)} height={220} title="Ubicación del hallazgo" />
                    </View>
                  ) : null}
                  {(selected?.imagen_url || selected?.imagen) ? (
                    <View style={{ marginBottom: spacing.sm }}>
                      <Text style={{ color: colors.textDark, fontWeight: '600', marginBottom: spacing.xs }}>Imagen</Text>
                      {(() => {
                        const u = resolveImageUrl(selected.imagen_url || selected.imagen); return isValidHttp(u) ? (
                          <Image source={{ uri: u }} style={{ width: '100%', height: 200, borderRadius: 6 }} />
                        ) : (
                          <View style={{ width: '100%', height: 200, borderRadius: 6, borderWidth: 1, borderColor: colors.border, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.cardFooterBg }}>
                            <Text style={{ color: colors.textLight }}>Sin imagen válida</Text>
                          </View>
                        );
                      })()}
                    </View>
                  ) : null}
                  <View style={{ marginTop: spacing.xs }}>
                    <Text style={{ color: colors.textDark, fontWeight: '600', marginBottom: spacing.xs }}>Datos del reporte</Text>
                    {!!selected?.direccion && (
                      <Text style={{ color: colors.text }}>Dirección: {selected.direccion}</Text>
                    )}
                    {!!selected?.tamano && (
                      <Text style={{ color: colors.text }}>Tamaño: {selected.tamano}</Text>
                    )}
                    <Text style={{ color: colors.text }}>Se mueve: {Number(selected?.puede_moverse) === 1 ? 'Sí' : 'No'}</Text>
                    {!!selected?.urgencia && (
                      <Text style={{ color: colors.text }}>Urgencia: {selected.urgencia}</Text>
                    )}
                    {!!selected?.observaciones && (
                      <Text style={{ color: colors.text }}>Observaciones: {selected.observaciones}</Text>
                    )}
                  </View>
                  <Pressable accessibilityLabel="Cerrar detalle" onPress={() => setSelected(null)} style={{ marginTop: spacing.sm, backgroundColor: colors.neutral, padding: spacing.sm, borderRadius: 6, alignItems: 'center' }}>
                    <Text style={{ color: colors.text, fontWeight: '600' }}>Cerrar</Text>
                  </Pressable>
                </Card>
              </SafeAreaView>
            </Modal>
          </Card>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

