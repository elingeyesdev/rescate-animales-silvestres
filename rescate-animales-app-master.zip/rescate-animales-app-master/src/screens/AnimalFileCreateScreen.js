import { useEffect, useState } from 'react';
import { View, Text, TextInput, Pressable, ScrollView, Alert, Image, ActivityIndicator, FlatList, useWindowDimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Card from '../components/Card';
import { PrimaryButton, SecondaryButton } from '../components/Buttons';
import { colors } from '../theme/colors';
import { spacing, typography } from '../theme/layout';
import * as ImagePicker from 'expo-image-picker';
import CustomDropdown from '../components/CustomDropdown';
import { useNavigation } from '@react-navigation/native';
import apiClient from '../api/client';
import { listReports, resolveImageUrl } from '../api/reports';
import { listTransfers } from '../api/transfers';
import { createAnimalFile, listAnimalFiles } from '../api/animalFiles';
import useIsMounted from '../hooks/useIsMounted';

export default function AnimalFileCreateScreen() {
  const nav = useNavigation();
  const { width } = useWindowDimensions();
  const isWide = width > 600;
  const isTablet = width > 900;
  const containerStyle = isWide ? { maxWidth: isTablet ? 960 : 640, alignSelf: 'center', width: '100%' } : {};

  const [nombre, setNombre] = useState('');
  const [sexo, setSexo] = useState('Desconocido');
  const [descripcion, setDescripcion] = useState('');
  const [reporteId, setReporteId] = useState('');
  const [especieId, setEspecieId] = useState('');
  const [estadoId, setEstadoId] = useState('');
  const [image, setImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [loadingOptions, setLoadingOptions] = useState(false);
  const [speciesOptions, setSpeciesOptions] = useState([]);
  const [statusOptions, setStatusOptions] = useState([]);
  const [reportOptions, setReportOptions] = useState([]);
  const [reportLoading, setReportLoading] = useState(false);
  const [hasFirstTransfer, setHasFirstTransfer] = useState(null);
  const isMounted = useIsMounted();

  const normalize = (s) => String(s || '')
    .toLowerCase()
    .replace(/á/g, 'a')
    .replace(/é/g, 'e')
    .replace(/í/g, 'i')
    .replace(/ó/g, 'o')
    .replace(/ú/g, 'u')
    .replace(/ñ/g, 'n');

  useEffect(() => {
    (async () => {
      setLoadingOptions(true);
      try {
        const [speciesRes, statusRes] = await Promise.all([
          apiClient.get('/species').catch(() => ({ data: [] })),
          apiClient.get('/animal-statuses').catch(() => ({ data: [] })),
        ]);
        const speciesRaw = Array.isArray(speciesRes?.data?.data) ? speciesRes.data.data : (Array.isArray(speciesRes?.data) ? speciesRes.data : []);
        const statusesRaw = Array.isArray(statusRes?.data?.data) ? statusRes.data.data : (Array.isArray(statusRes?.data) ? statusRes.data : []);

        const speciesSyn = {
          ave: ['ave', 'aves'],
          mamifero: ['mamifero', 'mamífero', 'mamiferos', 'mamíferos'],
          reptil: ['reptil', 'reptiles'],
          desconocido: ['desconocido', 'sin clasificar', 'no identificado'],
        };
        const desiredSpecies = [
          { key: 'ave', label: 'Ave' },
          { key: 'mamifero', label: 'Mamífero' },
          { key: 'reptil', label: 'Reptil' },
          { key: 'desconocido', label: 'Desconocido' },
        ];
        const matchedSpecies = [];
        const usedSpeciesIds = new Set();
        desiredSpecies.forEach((d) => {
          const found = speciesRaw.find((s) => {
            const n = normalize(s?.nombre || s?.name || '');
            return (speciesSyn[d.key] || [d.key]).some((kw) => n.includes(kw));
          });
          if (found && !usedSpeciesIds.has(found.id)) {
            matchedSpecies.push({ id: String(found.id), label: d.label, nombre: found.nombre || found.name });
            usedSpeciesIds.add(found.id);
          }
        });
        const otherSpecies = speciesRaw.filter((s) => !usedSpeciesIds.has(s.id)).map((s) => ({ id: String(s.id), nombre: s.nombre || s.name }));
        const speciesCombined = [...matchedSpecies, ...otherSpecies];
        const speciesFallback = [
          { id: 'fallback:ave', label: 'Ave' },
          { id: 'fallback:mamifero', label: 'Mamífero' },
          { id: 'fallback:reptil', label: 'Reptil' },
          { id: 'fallback:desconocido', label: 'Desconocido' },
        ];
        if (isMounted.current) setSpeciesOptions(speciesCombined.length > 0 ? speciesCombined : speciesFallback);

        const statusSyn = {
          critico: ['critico', 'crítico', 'grave', 'critica', 'crítica'],
          atencion: ['en atencion', 'en atención', 'atencion', 'atención'],
          recuperacion: ['recuperacion', 'recuperación', 'en recuperacion', 'en recuperación', 'recuperand'],
          estable: ['estable', 'estabilidad'],
        };
        const desiredStatuses = [
          { key: 'critico', label: 'Crítico' },
          { key: 'atencion', label: 'En atención' },
          { key: 'recuperacion', label: 'En recuperación' },
          { key: 'estable', label: 'Estable' },
        ];
        const matchedStatuses = [];
        const usedStatusIds = new Set();
        desiredStatuses.forEach((d) => {
          const found = statusesRaw.find((s) => {
            const n = normalize(s?.nombre || s?.name || '');
            return (statusSyn[d.key] || [d.key]).some((kw) => n.includes(kw));
          });
          if (found && !usedStatusIds.has(found.id)) {
            matchedStatuses.push({ id: String(found.id), label: d.label, nombre: found.nombre || found.name });
            usedStatusIds.add(found.id);
          }
        });
        const otherStatuses = statusesRaw.filter((s) => !usedStatusIds.has(s.id)).map((s) => ({ id: String(s.id), nombre: s.nombre || s.name }));
        const statusCombined = [...matchedStatuses, ...otherStatuses];
        const statusFallback = [
          { id: 'fallback:critico', label: 'Crítico' },
          { id: 'fallback:atencion', label: 'En atención' },
          { id: 'fallback:recuperacion', label: 'En recuperación' },
          { id: 'fallback:estable', label: 'Estable' },
        ];
        if (isMounted.current) setStatusOptions(statusCombined.length > 0 ? statusCombined : statusFallback);
      } finally {
        if (isMounted.current) setLoadingOptions(false);
      }
    })();
  }, []);

  useEffect(() => {
    (async () => {
      setReportLoading(true);
      try {
        // Intentar obtener reportes aprobados; si falla o viene vacío, traer todos y filtrar localmente
        let approvedList = [];
        try {
          const approved = await listReports({ aprobado: 1, per_page: 1000 });
          approvedList = Array.isArray(approved) ? approved : [];
        } catch {}
        if (!(approvedList && approvedList.length > 0)) {
          const allRes = await listReports({ per_page: 1000 }).catch(() => []);
          const allList = Array.isArray(allRes) ? allRes : [];
          approvedList = allList.filter(r => (r?.aprobado === 1 || r?.aprobado === true || String(r?.aprobado).toLowerCase() === 'true'));
          if (approvedList.length === 0) {
            approvedList = allList; // fallback: mostrar todos si no hay marca de aprobado
          }
        }

        // Obtener todos los animals para ver qué report_ids ya tienen hoja de vida
        // Si un report_id está en la tabla animals, significa que ya hay una hoja de vida creada
        let reportsWithAnimalFile = new Set();
        try {
          // Intentar consultar /animals directamente
          const animalsRes = await apiClient.get('/animals').catch(() => ({ data: [] }));
          const animals = Array.isArray(animalsRes?.data?.data)
            ? animalsRes.data.data
            : (Array.isArray(animalsRes?.data) ? animalsRes.data : []);

          // Extraer los report_ids de los animals
          animals.forEach((animal) => {
            const reportId = animal?.reporte_id || animal?.report_id || animal?.report?.id;
            if (reportId) {
              reportsWithAnimalFile.add(String(reportId));
            }
          });

          // Si no hay resultados de /animals, intentar con animal-files como fallback
          if (animals.length === 0) {
            const animalFiles = await listAnimalFiles({ perPage: 1000, page: 1 }).catch(() => []);
            const allAnimalFiles = Array.isArray(animalFiles) ? animalFiles : [];
            allAnimalFiles.forEach((af) => {
              const reportId = af?.reporte_id || af?.report_id || af?.animal?.reporte_id || af?.animal?.report_id;
              if (reportId) {
                reportsWithAnimalFile.add(String(reportId));
              }
            });
          }
        } catch (e) {
          console.log('Error obteniendo animals para filtrar reportes', e);
        }

        // Filtrar reportes: solo mostrar los que NO tienen hoja de vida
        const availableReports = approvedList.filter((report) => {
          const reportId = String(report.id);
          return !reportsWithAnimalFile.has(reportId);
        });

        if (isMounted.current) setReportOptions(availableReports);
      } finally {
        if (isMounted.current) setReportLoading(false);
      }
    })();
  }, []);

  useEffect(() => {
    (async () => {
      const rid = reporteId ? Number(reporteId) : null;
      if (!rid) { if (isMounted.current) setHasFirstTransfer(null); return; }
      try {
        const trs = await listTransfers({ reportId: rid });
        const hasFirst = Array.isArray(trs) && trs.some((t) => (t?.primer_traslado === true || t?.primer_traslado === 1 || String(t?.primer_traslado).toLowerCase() === 'true'));
        if (isMounted.current) setHasFirstTransfer(!!hasFirst);
      } catch {
        if (isMounted.current) setHasFirstTransfer(null);
      }
    })();
  }, [reporteId]);

  const pickImageFromGallery = async () => {
    try {
      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        Alert.alert('Permiso', 'Se requiere permiso de galería');
        return;
      }
      const res = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.85 });
      if (!res.canceled && res.assets?.[0]) {
        const asset = res.assets[0];
        const mime = asset.mimeType || asset.type || '';
        const name = asset.fileName || asset.uri || '';
        const hasValidMime = String(mime).toLowerCase().startsWith('image/');
        const hasValidExt = /(\.jpe?g|\.png)$/i.test(String(name));
        if (!hasValidMime && !hasValidExt) {
          Alert.alert('Formato de imagen inválido', 'Formatos permitidos: JPG, PNG');
          return;
        }
        if (isMounted.current) setImage(asset);
      }
    } catch (e) {
      console.log('Error pickImageFromGallery:', e);
      Alert.alert('Error', 'No se pudo abrir la galería');
    }
  };

  const pickImageFromCamera = async () => {
    try {
      const perm = await ImagePicker.requestCameraPermissionsAsync();
      if (!perm.granted) {
        Alert.alert('Permiso', 'Se requiere permiso de cámara');
        return;
      }
      const res = await ImagePicker.launchCameraAsync({ quality: 0.8 });
      if (!res.canceled && res.assets?.[0]) {
        const asset = res.assets[0];
        const mime = asset.mimeType || asset.type || '';
        const name = asset.fileName || asset.uri || '';
        const hasValidMime = String(mime).toLowerCase().startsWith('image/');
        const hasValidExt = /(\.jpe?g|\.png)$/i.test(String(name));
        if (!hasValidMime && !hasValidExt) {
          Alert.alert('Formato de imagen inválido', 'Formatos permitidos: JPG, PNG');
          return;
        }
        if (isMounted.current) setImage(asset);
      }
    } catch (e) {
      console.log('Error pickImageFromCamera:', e);
      Alert.alert('Error', 'No se pudo abrir la cámara');
    }
  };

  const onSubmit = async () => {
    if (isMounted.current) setLoading(true);
    if (isMounted.current) setError('');
    try {
      const payload = {
        nombre: nombre || undefined,
        sexo,
        descripcion: descripcion || undefined,
        reporte_id: Number(reporteId),
        especie_id: Number(especieId),
        estado_id: Number(estadoId),
      };
      if (image?.uri) {
        payload.imagen = {
          uri: image.uri,
          name: image.fileName || 'foto.jpg',
          type: image.mimeType || image.type || 'image/jpeg',
        };
      }
      if (!payload.reporte_id || !payload.especie_id || !payload.estado_id || !payload.sexo) {
        Alert.alert('Campos requeridos', 'Completa sexo, reporte, especie y estado.');
        if (isMounted.current) setLoading(false);
        return;
      }
      const data = await createAnimalFile(payload);
      const afId = data?.animalFile?.id || data?.animal_file?.id;
      Alert.alert('OK', data?.message || 'Hoja de Vida creada');
      if (afId) {
        nav.navigate('History', { animalFileId: afId });
      }
    } catch (e) {
      const msg = e?.response?.data?.message || e?.message || 'No se pudo crear la Hoja de Vida';
      const errorsObj = e?.response?.data?.errors || {};
      const errors = Array.isArray(errorsObj) ? errorsObj : Object.values(errorsObj).flat().filter(Boolean);
      const first = errors && errors.length > 0 ? `\n${errors[0]}` : '';
      if (isMounted.current) setError(`${msg}${first}`);
      Alert.alert('Error', `${msg}${first}`);
    } finally {
      if (isMounted.current) setLoading(false);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md }}>
        <View style={containerStyle}>
          <Card>
            <Text style={{ textAlign: 'center', color: colors.textDark, marginBottom: spacing.sm, fontWeight: '700', fontSize: typography.lg }}>Crear Hoja de Vida</Text>

          {/* Info notice */}
          <View style={{ backgroundColor: colors.blue + '15', borderLeftWidth: 4, borderLeftColor: colors.blue, padding: 12, borderRadius: 6, marginBottom: spacing.md }}>
            <Text style={{ color: colors.blue, fontWeight: '600', marginBottom: 4 }}>ℹ️ Recuerda</Text>
            <Text style={{ color: colors.textDark, fontSize: 13 }}>Solo puedes crear la hoja de vida de un animal cuyo hallazgo fue aprobado.</Text>
          </View>

          {loadingOptions ? (
            <View style={{ alignItems: 'center', paddingVertical: spacing.sm }}>
              <ActivityIndicator />
            </View>
          ) : null}
          <View style={{ flexDirection: isWide ? 'row' : 'column', gap: spacing.sm }}>
            <View style={{ flex: 1, marginBottom: spacing.sm }}>
              <Text style={{ color: colors.textLight, marginBottom: 6 }}>Nombre</Text>
              <TextInput value={nombre} onChangeText={setNombre} placeholder="Nombre" style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 6, paddingHorizontal: 10, paddingVertical: 8, color: colors.text }} />
            </View>
            <View style={{ flex: 1, marginBottom: spacing.sm }}>
              <CustomDropdown
                label="Sexo"
                value={sexo}
                onValueChange={setSexo}
                options={[
                  { label: "Hembra", value: "Hembra" },
                  { label: "Macho", value: "Macho" },
                  { label: "Desconocido", value: "Desconocido" }
                ]}
              />
            </View>
          </View>
          <View style={{ marginBottom: spacing.sm }}>
            <Text style={{ color: colors.textLight, marginBottom: 6 }}>Descripción</Text>
            <TextInput value={descripcion} onChangeText={setDescripcion} placeholder="Descripción" multiline style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 6, paddingHorizontal: 10, paddingVertical: 8, minHeight: 80, color: colors.text }} />
          </View>
          <View style={{ marginBottom: spacing.sm }}>
            <Text style={{ color: colors.textDark, fontWeight: '600', marginBottom: 6 }}>Paso 1: Seleccione el hallazgo</Text>
            {!!reporteId && (() => {
              const r = reportOptions.find((x) => String(x.id) === String(reporteId));
              const img = r?.imagen_url || r?.imagen;
              const uri = img ? resolveImageUrl(img) : null;
              return (
                <View style={{ marginBottom: 8 }}>
                  <View style={{ width: '100%', height: 200, borderWidth: 1, borderColor: colors.border, borderRadius: 8, overflow: 'hidden', alignItems: 'center', justifyContent: 'center', backgroundColor: colors.cardFooterBg }}>
                    {uri ? (
                      <Image source={{ uri }} style={{ width: '100%', height: '100%' }} resizeMode="cover" />
                    ) : (
                      <Text style={{ color: colors.textLight }}>Sin imagen</Text>
                    )}
                  </View>
                </View>
              );
            })()}
            {reportLoading ? (
              <View style={{ alignItems: 'center', paddingVertical: spacing.sm }}>
                <ActivityIndicator />
              </View>
            ) : (
              <FlatList
                data={reportOptions}
                keyExtractor={(r) => String(r.id)}
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={{ paddingVertical: 6 }}
                renderItem={({ item: r }) => {
                  const selected = String(reporteId) === String(r.id);
                  const img = r?.imagen_url || r?.imagen;
                  const uri = img ? resolveImageUrl(img) : null;
                  return (
                    <Pressable
                      onPress={() => setReporteId(String(r.id))}
                      style={{
                        width: 220,
                        height: 180,
                        borderWidth: 2,
                        borderColor: selected ? colors.success : colors.border,
                        borderRadius: 8,
                        backgroundColor: colors.cardBg,
                        marginRight: 10,
                        padding: 8,
                      }}
                    >
                      <View style={{ flex: 1, borderRadius: 6, overflow: 'hidden', borderWidth: 1, borderColor: colors.border, marginBottom: 8, alignItems: 'center', justifyContent: 'center' }}>
                        {uri ? (
                          <Image source={{ uri }} style={{ width: '100%', height: '100%' }} resizeMode="cover" />
                        ) : (
                          <Text style={{ color: colors.textLight }}>Sin imagen</Text>
                        )}
                      </View>
                      <Text style={{ color: colors.textDark, fontWeight: '700' }}>{`Hallazgo N°${r.id}`}</Text>
                    </Pressable>
                  );
                }}
              />
            )}
          </View>
          <View style={{ flexDirection: isWide ? 'row' : 'column', gap: spacing.sm }}>
            <View style={{ flex: 1, marginBottom: spacing.sm }}>
              <CustomDropdown
                label="Especie"
                placeholder="Seleccione"
                value={especieId}
                onValueChange={setEspecieId}
                options={speciesOptions.map(s => ({
                  label: String(s.label || s?.nombre || s?.name || s.id),
                  value: String(s.id)
                }))}
              />
            </View>
            <View style={{ flex: 1, marginBottom: spacing.sm }}>
              <CustomDropdown
                label="Estado"
                placeholder="Seleccione"
                value={estadoId}
                onValueChange={setEstadoId}
                options={statusOptions.map(s => ({
                  label: String(s.label || s?.nombre || s?.name || s.id),
                  value: String(s.id)
                }))}
              />
            </View>
          </View>
          <View style={{ marginBottom: spacing.sm }}>
            <Text style={{ color: colors.textLight, marginBottom: 6 }}>Imagen (opcional)</Text>
            {image && (
              <Image source={{ uri: image.uri }} style={{ width: '100%', height: 200, borderRadius: 8, borderWidth: 1, borderColor: colors.border, marginBottom: spacing.sm }} resizeMode="cover" />
            )}
            <View style={{ gap: spacing.sm }}>
              <PrimaryButton title={image ? 'Tomar Otra Foto' : 'Tomar Foto'} icon="photo-camera" onPress={pickImageFromCamera} />
              <SecondaryButton title={image ? 'Cambiar Imagen' : 'Elegir Imagen'} onPress={pickImageFromGallery} />
            </View>
          </View>
          <PrimaryButton title={loading ? 'Guardando...' : 'Crear Hoja de Vida'} icon="check-circle" onPress={onSubmit} disabled={loading} style={{ marginTop: spacing.md }} />
          {error ? (
            <Text style={{ color: colors.danger, marginTop: spacing.xs }}>{error}</Text>
          ) : null}
        </Card>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
