import { useEffect, useState } from 'react';
import { View, Text, ActivityIndicator, FlatList, Pressable, Image, Alert, ScrollView, useWindowDimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Card from '../components/Card';
import { colors } from '../theme/colors';
import { spacing, typography } from '../theme/layout';
import { listTransfers, createTransfer, createInternalTransfer } from '../api/transfers';
import { MaterialIcons } from '@expo/vector-icons';
import CentersMap from '../components/CentersMap';
import { listCenters } from '../api/centers';
import CustomDropdown from '../components/CustomDropdown';
import InputWithIcon from '../components/InputWithIcon';
import { PrimaryButton, SecondaryButton } from '../components/Buttons';
import { listReleases } from '../api/releases';
import { listReports, resolveImageUrl } from '../api/reports';
import { listAnimalFiles } from '../api/animalFiles';
import apiClient from '../api/client';
import useIsMounted from '../hooks/useIsMounted';
import { useNavigation } from '@react-navigation/native';
import { useAuth } from '../context/AuthContext';

export default function TransfersScreen({ route, animalId: propAnimalId }) {
  const animalId = propAnimalId ?? route?.params?.animalId;
  const reportId = route?.params?.reportId ?? route?.params?.reporte_id ?? null;
  const navigation = useNavigation();
  const { offlineMode } = useAuth();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('first');
  const [centers, setCenters] = useState([]);
  const [selectedFirstCenterId, setSelectedFirstCenterId] = useState(null);
  const [selectedInternalFromId, setSelectedInternalFromId] = useState(null);
  const [selectedInternalToId, setSelectedInternalToId] = useState(null);
  const [persons, setPersons] = useState([]);
  const [firstPersonaId, setFirstPersonaId] = useState('');
  const [internalPersonaId, setInternalPersonaId] = useState('');
  const [firstObservaciones, setFirstObservaciones] = useState('');
  const [internalObservaciones, setInternalObservaciones] = useState('');
  const [hasRelease, setHasRelease] = useState(false);
  const [hasFirstTransfer, setHasFirstTransfer] = useState(false);
  const [currentCenterId, setCurrentCenterId] = useState(null);
  const [hasAnimalFile, setHasAnimalFile] = useState(false);
  const [finalAnimalIdForTransfer, setFinalAnimalIdForTransfer] = useState(null);
  const [reportOptions, setReportOptions] = useState([]);
  const [loadingReports, setLoadingReports] = useState(false);
  const isMounted = useIsMounted();
  const { width } = useWindowDimensions();
  const isWide = width > 600;
  const isTablet = width > 900;
  const containerStyle = isWide ? { maxWidth: isTablet ? 900 : 600, alignSelf: 'center', width: '100%' } : {};

  const color = colors.warning;
  const iconName = 'local-shipping';

  const formatDate = (s) => {
    if (!s) return 'N/D';
    const d = new Date(s);
    if (isNaN(d.getTime())) return String(s);
    const dd = String(d.getDate()).padStart(2, '0');
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const yy = d.getFullYear();
    return `${dd}/${mm}/${yy}`;
  };

  useEffect(() => {
    (async () => {
      if (!animalId && !reportId) {
        if (isMounted.current) {
          setItems([]);
          setLoading(false);
          setHasRelease(false);
          setHasFirstTransfer(false);
        }
        // Load approved reports as options to pick a hallazgo
        try {
          setLoadingReports(true);
          const res = await listReports({ aprobado: 1, per_page: 1000 }).catch(() => []);
          const arr = Array.isArray(res) ? res : [];
          if (isMounted.current) setReportOptions(arr);
        } catch {}
        finally { if (isMounted.current) setLoadingReports(false); }
        return;
      }
      if (offlineMode) {
        if (isMounted.current) {
          setItems([]);
          setLoading(false);
          setHasRelease(false);
          setHasFirstTransfer(false);
        }
        return;
      }
      try {
        // Get animalId if we only have reportId
        let finalAnimalId = animalId;
        let animalFileIdForTransfer = null;

        // Check if there's an animal with this report_id (to determine if we can show "Traslado interno")
        if (reportId && !finalAnimalId) {
          try {
            // Check if there's an animal with this report_id
            const animalsRes = await apiClient.get('/animals').catch(() => ({ data: [] }));
            const animals = Array.isArray(animalsRes?.data?.data)
              ? animalsRes.data.data
              : (Array.isArray(animalsRes?.data) ? animalsRes.data : []);

            const animalWithReport = animals.find((a) => {
              const aReportId = a?.reporte_id || a?.report_id || a?.report?.id;
              return String(aReportId) === String(reportId);
            });

            if (animalWithReport) {
              finalAnimalId = animalWithReport?.id || animalWithReport?.animal_id || null;
              if (isMounted.current) {
                setHasAnimalFile(true);
                setFinalAnimalIdForTransfer(finalAnimalId);
              }

              // Get animal_file_id if available
              if (finalAnimalId) {
                const files = await listAnimalFiles({ animal_id: finalAnimalId }).catch(() => []);
                if (Array.isArray(files) && files.length > 0) {
                  animalFileIdForTransfer = files[0]?.id;
                }
              }
            } else {
              if (isMounted.current) {
                setHasAnimalFile(false);
                setFinalAnimalIdForTransfer(null);
              }
            }
          } catch (e) {
            console.log('Error checking for animal with report_id', e);
            if (isMounted.current) setHasAnimalFile(false);
          }
        } else if (finalAnimalId) {
          // If we already have animalId, check if there's an animal file
          if (isMounted.current) {
            setHasAnimalFile(true);
            setFinalAnimalIdForTransfer(finalAnimalId);
          }
          const files = await listAnimalFiles({ animal_id: finalAnimalId }).catch(() => []);
          if (Array.isArray(files) && files.length > 0) {
            animalFileIdForTransfer = files[0]?.id;
          }
        }

        // Also try to get animalId from report if not found yet
        if (!finalAnimalId && reportId) {
          try {
            const reports = await listReports({ id: reportId }).catch(() => []);
            const report = Array.isArray(reports) && reports.length > 0 ? reports[0] : null;
            const reportAnimalId = report?.animal?.id || report?.animal_id || null;
            if (reportAnimalId) {
              finalAnimalId = reportAnimalId;
              if (isMounted.current) {
                setHasAnimalFile(true);
                setFinalAnimalIdForTransfer(finalAnimalId);
              }
            }
          } catch (e) {
            console.log('Error getting animalId from reportId', e);
          }
        }

        // Get transfers - use finalAnimalIdForTransfer if available, otherwise try both animalId and reportId
        let data = [];
        const animalIdForTransfers = finalAnimalIdForTransfer || finalAnimalId;
        if (animalIdForTransfers) {
          data = await listTransfers(animalIdForTransfers);
        } else if (reportId && !hasAnimalFile) {
          // Only use reportId if there's no animal file yet
          data = await listTransfers({ reportId });
        }
        if (isMounted.current) setItems(Array.isArray(data) ? data : []);

        // Get the last transfer to determine current center for internal transfers
        // Check both animalId transfers and reportId transfers
        if (Array.isArray(data) && data.length > 0) {
          // Sort by date (most recent first) and get the last transfer
          const sorted = [...data].sort((a, b) => {
            const dateA = new Date(a.created_at || a.fecha || 0);
            const dateB = new Date(b.created_at || b.fecha || 0);
            return dateB - dateA;
          });
          const lastTransfer = sorted[0];
          // Check multiple possible locations for centro_id
          const centroId = lastTransfer?.centro_id ||
            lastTransfer?.center_id ||
            lastTransfer?.centro?.id ||
            lastTransfer?.center?.id ||
            null;
          if (centroId && isMounted.current) {
            setCurrentCenterId(centroId);
            setSelectedInternalFromId(centroId);
          }
        }

        // Check if there's already a first transfer
        if (reportId) {
          const hasFirst = Array.isArray(data) && data.some((t) =>
          (t?.primer_traslado === true ||
            t?.primer_traslado === 1 ||
            String(t?.primer_traslado).toLowerCase() === 'true')
          );
          if (isMounted.current) setHasFirstTransfer(hasFirst);
        } else {
          if (isMounted.current) setHasFirstTransfer(false);
        }

        // Check for releases: need to get animalFileId from animalId or reportId
        let animalFileId = null;
        if (animalId) {
          // If we have animalId, find animalFile with that animal_id
          const files = await listAnimalFiles({ animal_id: animalId }).catch(() => []);
          if (Array.isArray(files) && files.length > 0) {
            animalFileId = files[0]?.id;
          }
        } else if (reportId) {
          // If we have reportId, get the report to find animal_id, then find animalFile
          try {
            const reports = await listReports({ id: reportId }).catch(() => []);
            const report = Array.isArray(reports) && reports.length > 0 ? reports[0] : null;
            const reportAnimalId = report?.animal?.id || report?.animal_id;
            if (reportAnimalId) {
              const files = await listAnimalFiles({ animal_id: reportAnimalId }).catch(() => []);
              if (Array.isArray(files) && files.length > 0) {
                animalFileId = files[0]?.id;
              }
            }
          } catch (e) {
            console.log('Error getting animalFileId from reportId', e);
          }
        }

        // Check releases if we have animalFileId
        if (animalFileId) {
          const releases = await listReleases(animalFileId).catch(() => []);
          if (isMounted.current) setHasRelease(Array.isArray(releases) && releases.length > 0);
        } else {
          if (isMounted.current) setHasRelease(false);
        }
      } finally {
        if (isMounted.current) setLoading(false);
      }
    })();
  }, [animalId, reportId]);

  // Set initial tab based on whether we came from HojaDeVida or Approved Reports
  useEffect(() => {
    if (animalId && !reportId) {
      // If we have animalId but no reportId, we came from HojaDeVida - show internal transfer only
      setTab('internal');
    }
  }, [animalId, reportId]);

  // Switch to internal tab if first transfer already exists or if animal file exists (for Approved Reports)
  useEffect(() => {
    if (reportId && tab === 'first' && (hasFirstTransfer || hasAnimalFile)) {
      setTab('internal');
    }
  }, [hasFirstTransfer, hasAnimalFile, reportId, tab]);

  useEffect(() => {
    const loadCenters = async () => {
      try {
        const data = await listCenters();
        if (isMounted.current) {
          setCenters(Array.isArray(data) ? data : []);
          // After loading centers, if we have currentCenterId but selectedInternalFromId is not set, set it
          if (currentCenterId && !selectedInternalFromId) {
            setSelectedInternalFromId(currentCenterId);
          }
        }
      } catch { }
    };
    loadCenters();
  }, [tab, currentCenterId]);

  useEffect(() => {
    const loadPersons = async () => {
      try {
        // Try different possible endpoints
        let personsData = [];
        try {
          const { data } = await apiClient.get('/persons');
          personsData = Array.isArray(data?.data) ? data.data : (Array.isArray(data) ? data : []);
        } catch {
          try {
            const { data } = await apiClient.get('/people');
            personsData = Array.isArray(data?.data) ? data.data : (Array.isArray(data) ? data : []);
          } catch {
            console.log('Could not load persons');
          }
        }

        // Filter out persons with "ciudadano" or "citizen" role
        // Spatie roles are typically in a roles array or as a role object
        const filtered = personsData.filter((p) => {
          const roles = p?.roles || [];
          const roleNames = Array.isArray(roles)
            ? roles.map(r => (typeof r === 'string' ? r : r?.name || r?.nombre || '')).map(r => r.toLowerCase())
            : [];
          // Check if person has "ciudadano" or "citizen" role
          const hasCitizenRole = roleNames.some(r => r.includes('ciudadano') || r.includes('citizen'));
          return !hasCitizenRole;
        });

        if (isMounted.current) setPersons(filtered);
      } catch (e) {
        console.log('Error loading persons', e);
      }
    };
    loadPersons();
  }, []);

  const submitFirst = async () => {
    if (!reportId) {
      Alert.alert('Acción no disponible', 'Abre esta pantalla con un hallazgo aprobado.');
      return;
    }
    if (!selectedFirstCenterId) {
      Alert.alert('Centro requerido', 'Selecciona un centro destino.');
      return;
    }
    try {
      const r = await createTransfer({ report_id: reportId, centro_id: selectedFirstCenterId, observaciones: firstObservaciones, persona_id: firstPersonaId || undefined });
      Alert.alert('OK', r?.message || 'Traslado creado');
      const data = await listTransfers({ reportId });
      if (isMounted.current) setItems(Array.isArray(data) ? data : []);
    } catch (e) {
      const msg = e?.response?.data?.message || 'No se pudo registrar el traslado';
      const errorsObj = e?.response?.data?.errors || {};
      const errors = Array.isArray(errorsObj) ? errorsObj : Object.values(errorsObj).flat().filter(Boolean);
      const first = errors && errors.length > 0 ? `\n${errors[0]}` : '';
      Alert.alert('Error', `${msg}${first}`);
    }
  };

  const submitInternal = async () => {
    // Use finalAnimalIdForTransfer if available, otherwise use animalId
    const animalIdToUse = finalAnimalIdForTransfer || animalId;

    if (!animalIdToUse) {
      Alert.alert('Acción no disponible', 'Abre esta pantalla con un animal asociado.');
      return;
    }
    if (!selectedInternalToId) {
      Alert.alert('Centro requerido', 'Selecciona un centro destino.');
      return;
    }
    if (!internalPersonaId) {
      Alert.alert('Persona requerida', 'Selecciona la persona que realiza el traslado.');
      return;
    }
    try {
      // For internal transfer, send animal_id (or animal_file_id) + centro_id, NOT report_id
      const r = await createInternalTransfer({ animal_id: animalIdToUse, centro_id: selectedInternalToId, observaciones: internalObservaciones, persona_id: internalPersonaId });
      Alert.alert('OK', r?.message || 'Traslado interno creado');
      // Reload transfers to get the updated list - use animalIdToUse
      const data = await listTransfers(animalIdToUse);
      if (isMounted.current) setItems(Array.isArray(data) ? data : []);

      // Update current center to the destination center after successful transfer
      // This ensures the next transfer shows the correct current center
      if (isMounted.current) {
        setCurrentCenterId(selectedInternalToId);
        setSelectedInternalFromId(selectedInternalToId);
        setSelectedInternalToId(null);
      }

      // Also update from the latest transfer in case the API returns it
      if (Array.isArray(data) && data.length > 0) {
        const sorted = [...data].sort((a, b) => {
          const dateA = new Date(a.created_at || a.fecha || 0);
          const dateB = new Date(b.created_at || b.fecha || 0);
          return dateB - dateA;
        });
        const lastTransfer = sorted[0];
        const centroId = lastTransfer?.centro_id ||
          lastTransfer?.center_id ||
          lastTransfer?.centro?.id ||
          lastTransfer?.center?.id ||
          selectedInternalToId;
        if (centroId && isMounted.current) {
          setCurrentCenterId(centroId);
          setSelectedInternalFromId(centroId);
        }
      }
    } catch (e) {
      const msg = e?.response?.data?.message || 'No se pudo registrar el traslado interno';
      const errorsObj = e?.response?.data?.errors || {};
      const errors = Array.isArray(errorsObj) ? errorsObj : Object.values(errorsObj).flat().filter(Boolean);
      const first = errors && errors.length > 0 ? `\n${errors[0]}` : '';
      Alert.alert('Error', `${msg}${first}`);
    }
  };

  if (loading) return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg, justifyContent: 'center', alignItems: 'center' }}>
      <ActivityIndicator />
    </SafeAreaView>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.md + 20 }} keyboardShouldPersistTaps="handled">
        <View style={containerStyle}>
          <Card>
            <Text style={{ textAlign: 'center', color: colors.textDark, marginBottom: spacing.sm, fontWeight: '600', fontSize: typography.lg }}>Traslados</Text>
          {!animalId && !reportId ? (
            <View style={{ marginBottom: spacing.md }}>
              <Text style={{ color: colors.textDark, fontWeight: '600', marginBottom: spacing.xs }}>Paso 1: Seleccione el hallazgo</Text>
              {!!reportId && (() => {
                const r = (Array.isArray(reportOptions) ? reportOptions : []).find((x) => String(x.id) === String(reportId));
                const img = r?.imagen_url || r?.imagen;
                const uri = img ? resolveImageUrl(img) : null;
                return (
                  <View style={{ marginBottom: 8 }}>
                    <View style={{ width: '100%', height: 200, borderWidth: 1, borderColor: colors.border, borderRadius: 8, overflow: 'hidden', alignItems: 'center', justifyContent: 'center', backgroundColor: colors.cardFooterBg }}>
                      {uri ? (
                        <Image source={{ uri }} style={{ width: '100%', height: '100%' }} resizeMode="cover" />
                      ) : (
                        <Text style={{ color: colors.textLight }}>Sin imagen</Text>
                      )}
                    </View>
                  </View>
                );
              })()}

              {loadingReports ? (
                <View style={{ alignItems: 'center', paddingVertical: spacing.sm }}>
                  <ActivityIndicator />
                </View>
              ) : (
                <FlatList
                  data={Array.isArray(reportOptions) ? reportOptions : []}
                  keyExtractor={(r) => String(r.id)}
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={{ paddingVertical: 6 }}
                  renderItem={({ item: r }) => {
                    const selected = String(reportId) === String(r.id);
                    const img = r?.imagen_url || r?.imagen;
                    const uri = img ? resolveImageUrl(img) : null;
                    return (
                      <Pressable
                        onPress={() => { try { navigation.replace('Transfers', { reportId: String(r.id), reporte_id: String(r.id) }); } catch { navigation.navigate('Transfers', { reportId: String(r.id) }); } setTab('first'); }}
                        style={{
                          width: 220,
                          height: 180,
                          borderWidth: 2,
                          borderColor: selected ? colors.success : colors.border,
                          borderRadius: 8,
                          backgroundColor: colors.cardBg,
                          marginRight: 10,
                          padding: 8,
                        }}
                      >
                        <View style={{ flex: 1, borderRadius: 6, overflow: 'hidden', borderWidth: 1, borderColor: colors.border, marginBottom: 8, alignItems: 'center', justifyContent: 'center' }}>
                          {uri ? (
                            <Image source={{ uri }} style={{ width: '100%', height: '100%' }} resizeMode="cover" />
                          ) : (
                            <Text style={{ color: colors.textLight }}>Sin imagen</Text>
                          )}
                        </View>
                        <Text style={{ color: colors.textDark, fontWeight: '700' }}>{`Hallazgo N°${r.id}`}</Text>
                      </Pressable>
                    );
                  }}
                />
              )}
            </View>
          ) : null}
          {hasRelease ? (
            <View style={{ padding: spacing.md, backgroundColor: colors.warning + '20', borderRadius: 6, borderWidth: 1, borderColor: colors.warning, marginBottom: spacing.md }}>
              <Text style={{ color: colors.textDark, textAlign: 'center', fontSize: typography.sm }}>Este animal tiene una liberación registrada. No se pueden realizar traslados.</Text>
            </View>
          ) : (
            <>
              {/* Only show tabs if we have reportId (from Approved Reports) */}
              {reportId ? (
                <View style={{ flexDirection: 'row', marginBottom: spacing.sm }}>
                  {!hasFirstTransfer && !hasAnimalFile ? (
                    <Pressable onPress={() => setTab('first')} style={{ flex: 1, paddingVertical: spacing.sm, borderRadius: 6, borderWidth: 1, borderColor: tab === 'first' ? colors.blue : colors.border, backgroundColor: tab === 'first' ? colors.inputBg : colors.cardBg, alignItems: 'center', marginRight: 6 }}>
                      <Text style={{ color: tab === 'first' ? colors.textDark : colors.text }}>Primer traslado</Text>
                    </Pressable>
                  ) : null}
                  {(hasAnimalFile || finalAnimalIdForTransfer) ? (
                    <Pressable onPress={() => setTab('internal')} style={{ flex: 1, paddingVertical: spacing.sm, borderRadius: 6, borderWidth: 1, borderColor: tab === 'internal' ? colors.blue : colors.border, backgroundColor: tab === 'internal' ? colors.inputBg : colors.cardBg, alignItems: 'center', marginLeft: (hasFirstTransfer || hasAnimalFile) ? 0 : 6 }}>
                      <Text style={{ color: tab === 'internal' ? colors.textDark : colors.text }}>Traslado interno</Text>
                    </Pressable>
                  ) : null}
                </View>
              ) : null}
              {/* If we came from HojaDeVida (animalId without reportId), show internal transfer directly */}
              {animalId && !reportId ? (
                <View style={{ marginBottom: spacing.sm }}>
                  <Text style={{ textAlign: 'center', color: colors.textDark, fontWeight: '600', fontSize: typography.md }}>Traslado entre centros</Text>
                </View>
              ) : null}
              {tab === 'first' ? (
                <View style={{ marginBottom: spacing.md, opacity: hasRelease ? 0.6 : 1 }}>
                  <CentersMap centers={centers} selectedId={selectedFirstCenterId} onSelect={(c) => !hasRelease && setSelectedFirstCenterId(c?.id)} height={220} />
                  <View style={{ marginTop: spacing.sm, borderWidth: 1, borderColor: colors.border, borderRadius: 8 }}>
                    <View style={{ padding: spacing.sm, backgroundColor: colors.cardFooterBg }}>
                      <Text style={{ color: colors.textDark, fontWeight: '600' }}>Destino</Text>
                    </View>
                    <View style={{ padding: spacing.sm }}>
                      <Text style={{ color: colors.text }}>Centro destino: {centers.find((c) => String(c.id) === String(selectedFirstCenterId))?.nombre || '—'}</Text>
                    </View>
                  </View>
                  <View style={{ marginTop: spacing.sm }}>
                    <Text style={{ color: colors.textDark, fontWeight: '600', marginBottom: spacing.xs }}>Persona que traslada</Text>
                    <View style={{ marginBottom: spacing.sm }}>
                      <CustomDropdown
                        label="Persona"
                        placeholder="Seleccione"
                        value={firstPersonaId}
                        onValueChange={setFirstPersonaId}
                        options={(Array.isArray(persons) ? persons : []).map(p => ({
                          label: String(p.nombre),
                          value: p.id
                        }))}
                      />
                    </View>
                    <View style={{ marginTop: spacing.sm }}>
                      <InputWithIcon icon="notes" value={firstObservaciones} onChangeText={setFirstObservaciones} placeholder="Observaciones" multiline accessibilityLabel="Observaciones de traslado" />
                    </View>
                    <PrimaryButton title="Guardar traslado" onPress={submitFirst} disabled={hasRelease} style={{ marginTop: spacing.sm, opacity: hasRelease ? 0.6 : 1 }} accessibilityLabel="Guardar primer traslado" />
                  </View>
                </View>
              ) : (
                <View style={{ marginBottom: spacing.md, opacity: hasRelease ? 0.6 : 1 }}>
                  {/* Double crossing: filter out current center from map */}
                  <CentersMap
                    centers={centers.filter((c) => {
                      // Double check: exclude if it matches currentCenterId OR selectedInternalFromId
                      const cId = String(c.id);
                      const currentId = currentCenterId != null ? String(currentCenterId) : null;
                      const fromId = selectedInternalFromId != null ? String(selectedInternalFromId) : null;
                      return cId !== currentId && cId !== fromId;
                    })}
                    selectedId={selectedInternalToId}
                    onSelect={(c) => {
                      // Double check: prevent selecting current center
                      const cId = String(c?.id);
                      const currentId = currentCenterId != null ? String(currentCenterId) : null;
                      const fromId = selectedInternalFromId != null ? String(selectedInternalFromId) : null;
                      if (!hasRelease && cId !== currentId && cId !== fromId) {
                        setSelectedInternalToId(c?.id);
                      }
                    }}
                    height={220}
                  />
                  <View style={{ marginTop: spacing.sm, borderWidth: 1, borderColor: colors.border, borderRadius: 8 }}>
                    <View style={{ padding: spacing.sm, backgroundColor: colors.cardFooterBg }}>
                      <Text style={{ color: colors.textDark, fontWeight: '600' }}>Traslado entre centros</Text>
                    </View>
                    <View style={{ padding: spacing.sm }}>
                      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: spacing.xs }}>
                        <MaterialIcons name="place" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                        <Text style={{ color: colors.text }}>
                          Centro actual: {
                            (currentCenterId != null && centers.find((c) => String(c.id) === String(currentCenterId))?.nombre) ||
                            (selectedInternalFromId != null && centers.find((c) => String(c.id) === String(selectedInternalFromId))?.nombre) ||
                            'Refugio Central'
                          }
                        </Text>
                      </View>
                      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <MaterialIcons name="place" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                        <Text style={{ color: colors.text }}>Centro destino: {centers.find((c) => String(c.id) === String(selectedInternalToId))?.nombre || '—'}</Text>
                      </View>
                    </View>
                  </View>
                  <View style={{ marginTop: spacing.sm }}>
                    <Text style={{ color: colors.textDark, fontWeight: '600', marginBottom: spacing.xs }}>Persona que traslada</Text>
                    <View style={{ marginBottom: spacing.sm }}>
                      <CustomDropdown
                        label="Persona"
                        placeholder="Seleccione"
                        value={internalPersonaId}
                        onValueChange={setInternalPersonaId}
                        options={(Array.isArray(persons) ? persons : []).map(p => ({
                          label: String(p.nombre),
                          value: p.id
                        }))}
                      />
                    </View>
                    <View style={{ marginTop: spacing.sm }}>
                      <InputWithIcon icon="notes" value={internalObservaciones} onChangeText={setInternalObservaciones} placeholder="Observaciones" multiline accessibilityLabel="Observaciones de traslado" />
                    </View>
                    <PrimaryButton title="Guardar traslado interno" onPress={submitInternal} disabled={hasRelease} style={{ marginTop: spacing.sm, opacity: hasRelease ? 0.6 : 1 }} accessibilityLabel="Guardar traslado interno" />
                  </View>
                </View>
              )}
            </>
          )}
          {items.length === 0 ? (
            <Text style={{ color: colors.text }}>Sin traslados</Text>
          ) : (
            <View>
              {(Array.isArray(items) ? items : []).map((item, idx) => {
                const centerName = item?.center?.nombre || item?.centro?.nombre || 'Centro';
                const dateTime = formatDate(item.created_at || item.fecha);
                const hasDetails = Array.isArray(item.details) && item.details.length > 0;
                return (
                  <View key={String(item.id || idx)} style={{ flexDirection: 'row', paddingVertical: spacing.sm }}>
                    <View style={{ width: 28, alignItems: 'center' }}>
                      <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: color, marginTop: spacing.xs }} />
                    </View>
                    <View style={{ flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: 8, padding: spacing.sm, backgroundColor: colors.cardBg }}>
                      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: spacing.xs }}>
                        <MaterialIcons name={iconName} size={18} color={color} style={{ marginRight: 8 }} />
                        <Text style={{ color: colors.textDark, fontWeight: '600', fontSize: typography.md }}>Traslado</Text>
                      </View>
                      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: spacing.xs }}>
                        <MaterialIcons name="event" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                        <Text style={{ color: colors.textLight }}>{dateTime}</Text>
                      </View>
                      <View style={{ flexDirection: 'row', marginBottom: spacing.xs }}>
                        <MaterialIcons name="place" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                        <Text style={{ color: colors.text }}>{centerName}</Text>
                      </View>
                      <View style={{ flexDirection: 'row', marginBottom: spacing.xs }}>
                        <MaterialIcons name="person" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                        <Text style={{ color: colors.text }}>{item?.person?.nombre || '—'}</Text>
                      </View>
                      {!!item.observaciones && (
                        <Text style={{ color: colors.text }}>{item.observaciones}</Text>
                      )}
                      {hasDetails ? (
                        <View style={{ marginTop: spacing.xs }}>
                          {(Array.isArray(item.details) ? item.details : []).map((d, idx) => (
                            <View key={String(idx)} style={{ flexDirection: 'row', marginBottom: 4 }}>
                              <Text style={{ color: colors.textLight, marginRight: 6 }}>{String(d.label || 'Dato')}:</Text>
                              <Text style={{ color: colors.text }}>{String(d.value || '')}</Text>
                            </View>
                          ))}
                        </View>
                      ) : null}
                    </View>
                  </View>
                );
              })}
            </View>
          )}
          </Card>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
