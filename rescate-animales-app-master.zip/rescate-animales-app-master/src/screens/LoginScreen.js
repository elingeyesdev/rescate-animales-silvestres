import { useState, useEffect } from 'react';
import { View, Text, Pressable, ScrollView, Alert, useWindowDimensions } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import Card from '../components/Card';
import InputWithIcon from '../components/InputWithIcon';
import BrandHeader from '../components/BrandHeader';
import { colors } from '../theme/colors';
import { SafeAreaView } from 'react-native-safe-area-context';
import { KeyboardAvoidingView, Platform } from 'react-native';
import { useAuth } from '../context/AuthContext';
import { pingServer, API_BASE_URL } from '../api/client';
import { PrimaryButton, SecondaryButton } from '../components/Buttons';
import { getRememberedCredentials, storeRememberedCredentials } from '../api/tokenStore';
import useIsMounted from '../hooks/useIsMounted';

export default function LoginScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(false);
  const [loading, setLoading] = useState(false);
  const [apiStatus, setApiStatus] = useState('unknown');
  const { login, loginOffline } = useAuth();
  const isMounted = useIsMounted();
  const { width } = useWindowDimensions();
  const isWide = width > 600;
  const isTablet = width > 900;
  const containerStyle = isWide 
    ? { maxWidth: isTablet ? 960 : 640, alignSelf: 'center', width: '100%' }
    : { width: '100%', alignSelf: 'stretch' };

  const handleLogin = async () => {
    console.log('[LoginScreen] handleLogin called', { email, hasPassword: !!password, remember });
    if (!email || !password) {
      console.log('[LoginScreen] Missing email or password');
      Alert.alert('Campos incompletos', 'Por favor ingresa tu correo y contraseña.');
      return;
    }

    try {
      if (isMounted.current) setLoading(true);
      console.log('[LoginScreen] Checking server connection...');
      const ok = await pingServer();
      console.log('[LoginScreen] Server ping result:', ok);
      if (!ok) {
        const { rememberMe } = await getRememberedCredentials();
        if (rememberMe) {
          await loginOffline({ email });
          await storeRememberedCredentials(email, password, true);
          navigation.replace('Main');
          return;
        }
        Alert.alert('Sin conexión', 'No se pudo conectar con el servidor. Activa "Recordarme" para entrar en modo offline.');
        if (isMounted.current) setLoading(false);
        return;
      }
      console.log('[LoginScreen] Attempting login...');
      await login({ email, password });
      console.log('[LoginScreen] Login successful');

      // Guardar credenciales si "Recordarme" está marcado
      console.log('[LoginScreen] Storing remembered credentials...', { remember });
      await storeRememberedCredentials(email, password, remember);
      console.log('[LoginScreen] Credentials stored, navigating to Main');

      navigation.replace('Main');
    } catch (error) {
      console.error('[LoginScreen] Error en login', error?.response || error);
      const message =
        error?.response?.data?.message ||
        'No se pudo iniciar sesión. Verifica tus datos o intenta más tarde.';
      Alert.alert('Error', message);
    } finally {
      if (isMounted.current) setLoading(false);
      console.log('[LoginScreen] handleLogin finished');
    }
  };

  useEffect(() => {
    console.log('[LoginScreen] Component mounted, checking API status');
    (async () => {
      const ok = await pingServer();
      console.log('[LoginScreen] Initial API status:', ok);
      if (isMounted.current) setApiStatus(ok ? 'ok' : 'fail');
    })();
  }, []);

  // Cargar credenciales recordadas al montar el componente
  useEffect(() => {
    const loadRememberedCredentials = async () => {
      try {
        console.log('[LoginScreen] Loading remembered credentials...');
        const { email: rememberedEmail, password: rememberedPassword, rememberMe } = await getRememberedCredentials();
        console.log('[LoginScreen] Remembered credentials loaded:', {
          hasEmail: !!rememberedEmail,
          hasPassword: !!rememberedPassword,
          rememberMe
        });

        if (isMounted.current && rememberedEmail && rememberMe) {
          setEmail(rememberedEmail);
          setRemember(true);
          if (rememberedPassword) {
            setPassword(rememberedPassword);
            console.log('[LoginScreen] Email and password restored');
          } else {
            console.log('[LoginScreen] Email restored, no password');
          }
        }
      } catch (error) {
        console.error('[LoginScreen] Error cargando credenciales recordadas', error);
      }
    };
    loadRememberedCredentials();
  }, []);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <View style={{ position: 'absolute', top: 8, left: 8, width: 10, height: 10, borderRadius: 5, backgroundColor: apiStatus === 'ok' ? colors.success : apiStatus === 'fail' ? colors.danger : colors.neutral }} />
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 16 }}>
          <BrandHeader />
          <View style={containerStyle}>
            <Card>
              <Text style={{ textAlign: 'center', color: colors.textDark, marginBottom: 12 }}>
                Inicia sesión para comenzar tu sesión
              </Text>
              <InputWithIcon
                icon="email"
                value={email}
                onChangeText={setEmail}
                placeholder="Correo electrónico o usuario"
                size="lg"
              />
              <InputWithIcon
                icon="lock"
                value={password}
                onChangeText={setPassword}
                placeholder="Contraseña"
                secureTextEntry
                size="lg"
              />
              <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 16 }}>
                <Pressable
                  onPress={() => setRemember((v) => !v)}
                  style={{
                    width: 16,
                    height: 16,
                    borderWidth: 1,
                    borderColor: colors.border,
                    marginRight: 8,
                    backgroundColor: remember ? colors.blue : 'transparent',
                  }}
                />
                <Text style={{ color: colors.text }}>Recordarme</Text>
              </View>
              <View style={{ height: 12 }} />

              <PrimaryButton title={loading ? 'Iniciando...' : 'Iniciar sesión'} onPress={handleLogin} disabled={loading} style={{ width: '100%' }} />

              <SecondaryButton title="Crear cuenta nueva" onPress={() => navigation.navigate('Register')} style={{ marginTop: 12, width: '100%' }} />
  
              </Card>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
