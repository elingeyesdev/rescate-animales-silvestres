import { useState } from 'react';
import { View, Text, Pressable, ScrollView, Alert, useWindowDimensions } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import Card from '../components/Card';
import InputWithIcon from '../components/InputWithIcon';
import BrandHeader from '../components/BrandHeader';
import { colors } from '../theme/colors';
import { SafeAreaView } from 'react-native-safe-area-context';
import { KeyboardAvoidingView, Platform } from 'react-native';
import { useAuth } from '../context/AuthContext';
import { PrimaryButton } from '../components/Buttons';
import useIsMounted from '../hooks/useIsMounted';

export default function RegisterScreen({ navigation }) {
  const [name, setName] = useState('');
  const [ci, setCi] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [loading, setLoading] = useState(false);
  const { register } = useAuth();
  const isMounted = useIsMounted();
  const { width } = useWindowDimensions();
  const isWide = width > 600;
  const isTablet = width > 900;
  const containerStyle = isWide 
    ? { maxWidth: isTablet ? 960 : 640, alignSelf: 'center', width: '100%' }
    : { width: '100%', alignSelf: 'stretch' };

  const handleRegister = async () => {
    if (!name || !ci || !email || !password || !confirm) {
      Alert.alert('Campos incompletos', 'Por favor llena todos los campos obligatorios.');
      return;
    }

    if (password !== confirm) {
      Alert.alert('Contraseñas no coinciden', 'La contraseña y su confirmación deben ser iguales.');
      return;
    }

    try {
      if (isMounted.current) setLoading(true);
      await register({
        email,
        password,
        nombre: name,
        ci,
        telefono: phone || null,
        es_cuidador: false,
      });
      Alert.alert('Registro exitoso', 'Tu cuenta ha sido creada. Ahora puedes iniciar sesión.', [
        {
          text: 'Ir al login',
          onPress: () => navigation.navigate('Login'),
        },
      ]);
    } catch (error) {
      console.error('Error en registro', error?.response || error);
      const message =
        error?.response?.data?.message ||
        'No se pudo registrar el usuario. Verifica los datos o intenta más tarde.';
      Alert.alert('Error', message);
    } finally {
      if (isMounted.current) setLoading(false);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 16 }}>
        <BrandHeader />
        <View style={containerStyle}>
          <Card
            footer={
              <Pressable onPress={() => navigation.navigate('Login')}>
                <Text style={{ color: colors.blue }}>Ya tengo una cuenta</Text>
              </Pressable>
            }
          >
          <Text style={{ textAlign: 'center', color: colors.textDark, marginBottom: 12 }}>
            Registrar una nueva cuenta
          </Text>
          <InputWithIcon icon="person" value={name} onChangeText={setName} placeholder="Nombre completo" size="lg" />
          <InputWithIcon icon="credit-card" value={ci} onChangeText={setCi} placeholder="CI" size="lg" />
          <InputWithIcon icon="phone" value={phone} onChangeText={setPhone} placeholder="Teléfono (opcional)" size="lg" />
          <InputWithIcon icon="email" value={email} onChangeText={setEmail} placeholder="Email" size="lg" />
          <InputWithIcon icon="lock" value={password} onChangeText={setPassword} placeholder="Contraseña" secureTextEntry size="lg" />
          <InputWithIcon icon="lock" value={confirm} onChangeText={setConfirm} placeholder="Confirmar contraseña" secureTextEntry size="lg" />
          <PrimaryButton title={loading ? 'Enviando...' : 'Registrarme'} onPress={handleRegister} disabled={loading} style={{ width: '100%' }} />
          </Card>
        </View>
      </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
