import { useEffect, useState } from 'react';
import { View, Text, ScrollView, useWindowDimensions, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import BrandHeader from '../components/BrandHeader';
import Card from '../components/Card';
import { colors } from '../theme/colors';
import { spacing, typography } from '../theme/layout';
import { useAuth } from '../context/AuthContext';
import { listReports } from '../api/reports';
import apiClient from '../api/client';
import { listAnimalFiles } from '../api/animalFiles';
import { listMedicalEvaluations } from '../api/medicalEvaluations';

export default function ReportsScreen() {
  const { width } = useWindowDimensions();
  const isWide = width > 600;
  const isTablet = width > 900;
  const containerStyle = isWide ? { maxWidth: isTablet ? 960 : 640, alignSelf: 'center', width: '100%' } : { width: '100%', alignSelf: 'stretch', paddingHorizontal: 16 };
  const { offlineMode } = useAuth();

  const [loading, setLoading] = useState(false);
  const [activity, setActivity] = useState({ peligro: 0, traslado: 0, tratamiento: 0, liberado: 0, total: 0 });
  const [health, setHealth] = useState({ totalEnCentro: 0, porEstado: {} });
  const [efficacy, setEfficacy] = useState({ rescate: 0, tratamiento: 0, liberacion: 0, bases: {} });
  const [dateFrom, setDateFrom] = useState(() => {
    const d = new Date(); d.setDate(d.getDate() - 14); return d.toISOString().slice(0,10);
  });
  const [dateTo, setDateTo] = useState(() => new Date().toISOString().slice(0,10));
  const [healthRows, setHealthRows] = useState([]);
  const [loadingHealth, setLoadingHealth] = useState(false);
  const [quickRange, setQuickRange] = useState(null);

  useEffect(() => {
    (async () => {
      if (offlineMode) {
        setActivity({ peligro: 0, traslado: 0, tratamiento: 0, liberado: 0, total: 0 });
        setHealth({ totalEnCentro: 0, porEstado: {} });
        setEfficacy({ rescate: 0, tratamiento: 0, liberacion: 0, bases: {} });
        setHealthRows([]);
        return;
      }
      setLoading(true);
      try {
        const [reportsRes, transfersRes, filesRes, releasesRes] = await Promise.all([
          listReports({ per_page: 1000 }),
          apiClient.get('/transfers', { params: { per_page: 1000 } }).catch(() => ({ data: [] })),
          apiClient.get('/animal-files', { params: { per_page: 1000 } }).catch(() => ({ data: [] })),
          apiClient.get('/releases', { params: { per_page: 1000 } }).catch(() => ({ data: [] })),
        ]);

        const reports = Array.isArray(reportsRes) ? reportsRes : [];
        const transfers = Array.isArray(transfersRes?.data?.data) ? transfersRes.data.data : (Array.isArray(transfersRes?.data) ? transfersRes.data : []);
        const files = Array.isArray(filesRes?.data?.data) ? filesRes.data.data : (Array.isArray(filesRes?.data) ? filesRes.data : []);
        const releases = Array.isArray(releasesRes?.data?.data) ? releasesRes.data.data : (Array.isArray(releasesRes?.data) ? releasesRes.data : []);

        const transfersMap = {};
        transfers.forEach(t => {
          const rid = t?.report_id || t?.reporte_id || t?.report?.id;
          if (rid != null) transfersMap[String(rid)] = transfersMap[String(rid)] || (t?.primer_traslado === true || t?.primer_traslado === 1 || String(t?.primer_traslado).toLowerCase() === 'true');
        });

        const fileByReport = {};
        const fileById = {};
        files.forEach(f => {
          const rid = f?.reporte_id || f?.report_id || f?.report?.id;
          if (rid != null) fileByReport[String(rid)] = f;
          if (f?.id != null) fileById[String(f.id)] = f;
        });

        const releaseByFile = {};
        releases.forEach(r => {
          const afid = r?.animal_file_id || r?.animalFileId || r?.animal_file?.id;
          if (afid != null) releaseByFile[String(afid)] = true;
        });

        let peligro = 0, traslado = 0, tratamiento = 0, liberado = 0;
        reports.forEach(r => {
          const rid = String(r?.id);
          const f = fileByReport[rid];
          const hasRelease = f && releaseByFile[String(f?.id)];
          const hasFile = !!f;
          const hasTransfer = !!transfersMap[rid];
          if (hasRelease) liberado++;
          else if (hasFile) tratamiento++;
          else if (hasTransfer) traslado++;
          else peligro++;
        });
        setActivity({ peligro, traslado, tratamiento, liberado, total: reports.length });

        const currentFiles = files.filter(f => !releaseByFile[String(f?.id)]);
        const byStatus = {};
        currentFiles.forEach(f => {
          const name = (f?.estado?.nombre || f?.estado_nombre || f?.estado || '').toString().trim() || 'N/D';
          byStatus[name] = (byStatus[name] || 0) + 1;
        });
        setHealth({ totalEnCentro: currentFiles.length, porEstado: byStatus });

        const firstTransfersCount = transfers.filter(t => (t?.primer_traslado === true || t?.primer_traslado === 1 || String(t?.primer_traslado).toLowerCase() === 'true')).length;
        const approvedReportsCount = (Array.isArray(reports) ? reports : []).filter(r => (r?.aprobado === 1 || r?.aprobado === true || String(r?.aprobado).toLowerCase() === 'true')).length;
        const stableCount = currentFiles.filter(f => {
          const n = (f?.estado?.nombre || f?.estado_nombre || f?.estado || '').toString().toLowerCase();
          return n.includes('estable');
        }).length;
        const totalFiles = files.length;
        const releasesCount = releases.length;
        const rescatePct = approvedReportsCount > 0 ? (firstTransfersCount * 100) / approvedReportsCount : 0;
        const tratamientoPct = totalFiles > 0 ? (stableCount * 100) / totalFiles : 0;
        const liberacionPct = stableCount > 0 ? (releasesCount * 100) / stableCount : 0;
        setEfficacy({ rescate: rescatePct, tratamiento: tratamientoPct, liberacion: liberacionPct, bases: { firstTransfersCount, approvedReportsCount, stableCount, totalFiles, releasesCount } });
      } finally {
        setLoading(false);
      }
    })();
  }, [offlineMode]);

  const applyHealthFilter = async () => {
    if (offlineMode) { setHealthRows([]); return; }
    setLoadingHealth(true);
    try {
      const filesRes = await apiClient.get('/animal-files', { params: { per_page: 200 } }).catch(() => ({ data: [] }));
      const files = Array.isArray(filesRes?.data?.data) ? filesRes.data.data : (Array.isArray(filesRes?.data) ? filesRes.data : []);
      // Load statuses for mapping estado_id -> nombre
      let statusesMap = {};
      try {
        const statusRes = await apiClient.get('/animal-statuses').catch(() => ({ data: [] }));
        const statusesRaw = Array.isArray(statusRes?.data?.data) ? statusRes.data.data : (Array.isArray(statusRes?.data) ? statusRes.data : []);
        (Array.isArray(statusesRaw) ? statusesRaw : []).forEach((s) => {
          if (s && s.id != null) statusesMap[String(s.id)] = s.nombre || s.name || String(s.id);
        });
      } catch {}
      // Filter by created_at range
      const fromD = new Date(dateFrom + 'T00:00:00Z');
      const toD = new Date(dateTo + 'T23:59:59Z');
      const inRange = (s) => {
        const d = new Date(s || 0); if (isNaN(d)) return false; return d >= fromD && d <= toD;
      };
      const base = files.filter(f => inRange(f?.created_at || f?.fecha || f?.inicio || f?.fecha_inicio));
      // For each file, get latest evaluation
      const rows = [];
      for (let i = 0; i < base.length; i++) {
        const f = base[i];
        const afId = f?.id || f?.animal_file_id;
        let lastEvalDate = null; let lastInterv = null;
        let estadoActualName = null;
        try {
          const evals = await listMedicalEvaluations(afId).catch(() => []);
          if (Array.isArray(evals) && evals.length > 0) {
            const sorted = [...evals].sort((a,b)=> new Date(b.created_at||b.fecha||0) - new Date(a.created_at||a.fecha||0));
            const last = sorted[0];
            lastEvalDate = last?.created_at || last?.fecha || null;
            lastInterv = last?.tratamiento_texto || last?.descripcion || last?.diagnostico || null;
            estadoActualName = (last?.estado?.nombre || statusesMap[String(last?.estado_id)] || null);
          }
        } catch {}
        const centerName = f?.centro?.nombre || f?.center?.nombre || f?.center_nombre || f?.centro_nombre || 'Sin centro asignado';
        const animalName = f?.nombre || f?.animal?.nombre || '—';
        const diagInicial = f?.diagnostico_inicial || f?.descripcion || 'Sin diagnóstico inicial';
        const estadoFallback = f?.estado?.nombre || statusesMap[String(f?.estado_id)] || f?.estado_nombre || null;
        const estadoActual = estadoActualName || estadoFallback || '—';
        rows.push({
          id: String(afId || i),
          centerName,
          animalName,
          diagInicial,
          fechaInicial: f?.created_at || f?.fecha || null,
          lastEvalDate,
          lastInterv: lastInterv || 'Sin intervenciones registradas',
          estadoActual,
        });
      }
      setHealthRows(rows);
    } finally {
      setLoadingHealth(false);
    }
  };

  useEffect(() => { applyHealthFilter(); }, []);

  const setWeekRange = () => {
    const now = new Date();
    const from = new Date();
    from.setDate(now.getDate() - 7);
    setDateFrom(from.toISOString().slice(0,10));
    setDateTo(now.toISOString().slice(0,10));
    setQuickRange('week');
    applyHealthFilter();
  };

  const setMonthRange = () => {
    const now = new Date();
    const from = new Date(now.getFullYear(), now.getMonth(), 1);
    const to = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    setDateFrom(from.toISOString().slice(0,10));
    setDateTo(to.toISOString().slice(0,10));
    setQuickRange('month');
    applyHealthFilter();
  };

  const StatRow = ({ label, value, color }) => (
    <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 6 }}>
      <Text style={{ flex: 1, color: colors.textDark }}>{label}</Text>
      <Text style={{ color, fontWeight: '700' }}>{isFinite(value) ? String(Math.round(value)) : '—'}</Text>
    </View>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <ScrollView contentContainerStyle={{ paddingHorizontal: 16, paddingTop: 24, paddingBottom: 32 }}>
        <BrandHeader />
        <View style={containerStyle}>
          <Card>
            <Text style={{ color: colors.textDark, fontSize: typography.lg, fontWeight: '700', textAlign: 'center', marginBottom: spacing.sm }}>Reportes de Actividad (Operativos)</Text>
            {offlineMode ? (
              <View style={{ padding: spacing.sm, borderWidth: 1, borderColor: colors.border, borderRadius: 8, backgroundColor: colors.cardBg }}>
                <Text style={{ color: colors.textDark, textAlign: 'center' }}>Datos no disponibles en modo offline</Text>
              </View>
            ) : (
              <View>
                <View style={{ marginBottom: spacing.md }}>
                  <Text style={{ color: colors.textDark, fontWeight: '600', marginBottom: spacing.xs }}>A. Reporte de Actividad por Estados</Text>
                  <View style={{ flexDirection: isWide ? 'row' : 'column', gap: 8, marginBottom: spacing.sm }}>
                    <View style={{ flex: 1, minWidth: 140, padding: 10, borderRadius: 8, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.cardBg }}>
                      <Text style={{ color: colors.danger, fontWeight: '800', fontSize: 18 }}>{activity.peligro}</Text>
                      <Text style={{ color: colors.textDark }}>En Peligro</Text>
                    </View>
                    <View style={{ flex: 1, minWidth: 140, padding: 10, borderRadius: 8, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.cardBg }}>
                      <Text style={{ color: colors.warning, fontWeight: '800', fontSize: 18 }}>{activity.traslado}</Text>
                      <Text style={{ color: colors.textDark }}>En Traslado</Text>
                    </View>
                    <View style={{ flex: 1, minWidth: 140, padding: 10, borderRadius: 8, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.cardBg }}>
                      <Text style={{ color: colors.blue, fontWeight: '800', fontSize: 18 }}>{activity.tratamiento}</Text>
                      <Text style={{ color: colors.textDark }}>En Tratamiento</Text>
                    </View>
                    <View style={{ flex: 1, minWidth: 140, padding: 10, borderRadius: 8, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.cardBg }}>
                      <Text style={{ color: colors.success, fontWeight: '800', fontSize: 18 }}>{activity.liberado}</Text>
                      <Text style={{ color: colors.textDark }}>Liberado</Text>
                    </View>
                  </View>
                  <StatRow label="En Peligro (sin acción)" value={activity.peligro} color={colors.danger} />
                  <StatRow label="En Traslado (Rescatado)" value={activity.traslado} color={colors.warning} />
                  <StatRow label="En Tratamiento (En centro)" value={activity.tratamiento} color={colors.blue} />
                  <StatRow label="Liberado" value={activity.liberado} color={colors.success} />
                  <View style={{ marginTop: spacing.xs }}>
                    <Text style={{ color: colors.textLight }}>Lógica: if liberado → Liberado; elseif ficha clínica → Tratamiento; elseif traslado → Rescatado; else → Peligro.</Text>
                  </View>
                </View>

                <View style={{ marginBottom: spacing.md }}>
                  <Text style={{ color: colors.textDark, fontWeight: '600', marginBottom: spacing.xs }}>B. Reporte de Salud Animal Actual</Text>
                  <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: spacing.sm }}>
                    <Text style={{ color: colors.textDark, marginRight: 8 }}>Rango de Fechas - Inicio de Tratamiento</Text>
                  </View>
                  <View style={{ flexDirection: isWide ? 'row' : 'column', gap: spacing.sm, alignItems: isWide ? 'center' : undefined, marginBottom: spacing.sm }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                      <Text style={{ color: colors.textDark, marginRight: 8 }}>Desde</Text>
                      <Pressable onPress={() => { /* date entry simple */ }} style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 6, paddingHorizontal: 10, paddingVertical: 8, backgroundColor: colors.cardBg }}>
                        <Text style={{ color: colors.textDark }}>{dateFrom}</Text>
                      </Pressable>
                    </View>
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                      <Text style={{ color: colors.textDark, marginRight: 8 }}>Hasta</Text>
                      <Pressable onPress={() => { /* date entry simple */ }} style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 6, paddingHorizontal: 10, paddingVertical: 8, backgroundColor: colors.cardBg }}>
                        <Text style={{ color: colors.textDark }}>{dateTo}</Text>
                      </Pressable>
                    </View>
                    <Pressable onPress={setWeekRange} style={{ paddingHorizontal: 14, paddingVertical: 10, borderRadius: 6, backgroundColor: quickRange === 'week' ? colors.blue : colors.cardBg, borderWidth: 1, borderColor: quickRange === 'week' ? colors.blue : colors.border }}>
                      <Text style={{ color: quickRange === 'week' ? '#fff' : colors.textDark, fontWeight: '700' }}>Semana</Text>
                    </Pressable>
                    <Pressable onPress={setMonthRange} style={{ paddingHorizontal: 14, paddingVertical: 10, borderRadius: 6, backgroundColor: quickRange === 'month' ? colors.blue : colors.cardBg, borderWidth: 1, borderColor: quickRange === 'month' ? colors.blue : colors.border }}>
                      <Text style={{ color: quickRange === 'month' ? '#fff' : colors.textDark, fontWeight: '700' }}>Mes</Text>
                    </Pressable>
                    <Pressable onPress={applyHealthFilter} style={{ paddingHorizontal: 14, paddingVertical: 10, borderRadius: 6, backgroundColor: colors.blue, marginLeft: isWide ? 'auto' : 0 }}>
                      <Text style={{ color: '#fff', fontWeight: '700' }}>Filtrar</Text>
                    </Pressable>
                    <Pressable onPress={() => { setDateFrom(new Date(Date.now()-14*24*3600*1000).toISOString().slice(0,10)); setDateTo(new Date().toISOString().slice(0,10)); setQuickRange(null); applyHealthFilter(); }} style={{ paddingHorizontal: 14, paddingVertical: 10, borderRadius: 6, backgroundColor: colors.cardBg, borderWidth: 1, borderColor: colors.border }}>
                      <Text style={{ color: colors.textDark, fontWeight: '600' }}>Limpiar</Text>
                    </Pressable>
                  </View>
                  <View style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 8, overflow: 'hidden' }}>
                    <View style={{ flexDirection: 'row', backgroundColor: colors.success, paddingVertical: 10, paddingHorizontal: 8 }}>
                      <Text style={{ flex: 1, color: '#fff', fontWeight: '700' }}>Centro</Text>
                      <Text style={{ flex: 1, color: '#fff', fontWeight: '700' }}>Nombre del Animal</Text>
                      <Text style={{ flex: 1, color: '#fff', fontWeight: '700' }}>Diagnóstico Inicial</Text>
                      <Text style={{ flex: 1, color: '#fff', fontWeight: '700' }}>Fecha Inicial</Text>
                      <Text style={{ flex: 1, color: '#fff', fontWeight: '700' }}>Fecha Última Evaluación</Text>
                      <Text style={{ flex: 1, color: '#fff', fontWeight: '700' }}>Última Intervención Médica</Text>
                      <Text style={{ width: 110, color: '#fff', fontWeight: '700' }}>Estado Actual</Text>
                    </View>
                    {(loadingHealth ? [null] : healthRows).map((row, idx) => (
                      <View key={row ? row.id : `loading-${idx}`} style={{ flexDirection: 'row', paddingVertical: 10, paddingHorizontal: 8, borderTopWidth: 1, borderColor: colors.border, backgroundColor: colors.cardBg }}>
                        <View style={{ flex: 1 }}>
                          <Text style={{ color: colors.textDark }}>{row ? row.centerName : 'Cargando...'}</Text>
                        </View>
                        <View style={{ flex: 1 }}>
                          <Text style={{ color: colors.textDark }}>{row?.animalName || '—'}</Text>
                        </View>
                        <View style={{ flex: 1 }}>
                          <Text style={{ color: colors.text }}>{row?.diagInicial || '—'}</Text>
                        </View>
                        <View style={{ flex: 1 }}>
                          <Text style={{ color: colors.text }}>{row?.fechaInicial ? new Date(row.fechaInicial).toLocaleDateString('es-ES') : '—'}</Text>
                        </View>
                        <View style={{ flex: 1 }}>
                          <Text style={{ color: colors.text }}>{row?.lastEvalDate ? new Date(row.lastEvalDate).toLocaleDateString('es-ES') : '-'}</Text>
                        </View>
                        <View style={{ flex: 1 }}>
                          <Text style={{ color: colors.text }}>{row?.lastInterv || 'Sin intervenciones registradas'}</Text>
                        </View>
                        <View style={{ width: 110, alignItems: 'flex-start' }}>
                          <View style={{ paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12, backgroundColor: colors.cardFooterBg, borderWidth: 1, borderColor: colors.border }}>
                            <Text style={{ color: colors.textDark, fontWeight: '600', fontSize: 12 }}>{row?.estadoActual || '—'}</Text>
                          </View>
                        </View>
                      </View>
                    ))}
                  </View>
                </View>
              </View>
            )}
          </Card>

          <View style={{ height: spacing.md }} />

          <Card>
            <Text style={{ color: colors.textDark, fontSize: typography.lg, fontWeight: '700', textAlign: 'center', marginBottom: spacing.sm }}>Reportes de Gestión (Indicadores de Eficacia)</Text>
            {offlineMode ? (
              <View style={{ padding: spacing.sm, borderWidth: 1, borderColor: colors.border, borderRadius: 8, backgroundColor: colors.cardBg }}>
                <Text style={{ color: colors.textDark, textAlign: 'center' }}>Datos no disponibles en modo offline</Text>
              </View>
            ) : (
              <View>
                <View style={{ marginBottom: spacing.md }}>
                  <Text style={{ color: colors.textDark, fontWeight: '600', marginBottom: spacing.xs }}>C. Eficacia de Rescate</Text>
                  <StatRow label="Eficacia (%)" value={efficacy.rescate} color={colors.blue} />
                </View>

                <View style={{ marginBottom: spacing.md }}>
                  <Text style={{ color: colors.textDark, fontWeight: '600', marginBottom: spacing.xs }}>D. Eficacia de Tratamiento</Text>
                  <StatRow label="Eficacia (%)" value={efficacy.tratamiento} color={colors.blue} />
                </View>

                <View>
                  <Text style={{ color: colors.textDark, fontWeight: '600', marginBottom: spacing.xs }}>E. Eficacia de Liberación</Text>
                  <StatRow label="Eficacia (%)" value={efficacy.liberacion} color={colors.blue} />
                </View>
              </View>
            )}
          </Card>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
