import { useEffect, useState } from 'react';
import { View, Text, ActivityIndicator, FlatList, Image, Modal, Pressable, useWindowDimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Card from '../components/Card';
import { colors } from '../theme/colors';
import { spacing, typography } from '../theme/layout';
import { listReleases } from '../api/releases';
import { listAnimalFiles } from '../api/animalFiles';
import CustomDropdown from '../components/CustomDropdown';
import { MaterialIcons } from '@expo/vector-icons';
import { resolveImageUrl } from '../api/reports';
import useIsMounted from '../hooks/useIsMounted';

export default function ReleasesScreen({ route }) {
  const paramAnimalFileId = route?.params?.animalFileId;
  const [selectedAnimalFileId, setSelectedAnimalFileId] = useState(null);
  const animalFileId = paramAnimalFileId ?? selectedAnimalFileId;
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [previewImage, setPreviewImage] = useState(null);
  const [pickerLoading, setPickerLoading] = useState(false);
  const [pickerItems, setPickerItems] = useState([]);
  const isMounted = useIsMounted();
  const { width } = useWindowDimensions();
  const isWide = width > 600;
  const isTablet = width > 900;
  const containerStyle = isWide ? { maxWidth: isTablet ? 900 : 600, alignSelf: 'center', width: '100%' } : {};

  const getEventColor = (title) => {
    const t = String(title || '').toLowerCase();
    if (t.includes('liber')) return colors.blueDark;
    if (t.includes('reub')) return colors.success;
    return colors.neutral;
  };

  const getEventIcon = (title) => {
    const t = String(title || '').toLowerCase();
    if (t.includes('liber')) return 'flight-takeoff';
    if (t.includes('reub')) return 'place';
    return 'flag';
  };

  useEffect(() => {
    (async () => {
      if (!animalFileId) {
        if (isMounted.current) {
          setItems([]);
          setLoading(false);
        }
        return;
      }
      try {
        const data = await listReleases(animalFileId);
        if (isMounted.current) setItems(Array.isArray(data) ? data : []);
      } finally {
        if (isMounted.current) setLoading(false);
      }
    })();
  }, [animalFileId]);

  useEffect(() => {
    (async () => {
      if (animalFileId) return;
      if (isMounted.current) setPickerLoading(true);
      try {
        const data = await listAnimalFiles({});
        if (isMounted.current) setPickerItems(Array.isArray(data) ? data : []);
      } finally {
        if (isMounted.current) setPickerLoading(false);
      }
    })();
  }, [animalFileId]);

  if (loading) return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg, justifyContent: 'center', alignItems: 'center' }}>
      <ActivityIndicator />
    </SafeAreaView>
  );

  if (!animalFileId) return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <View style={{ padding: spacing.md }}>
        <View style={containerStyle}>
          <Card>
            <Text style={{ textAlign: 'center', color: colors.textDark, marginBottom: spacing.sm, fontWeight: '600', fontSize: typography.lg }}>Selecciona ficha</Text>
          {pickerLoading ? (
            <View style={{ alignItems: 'center', paddingVertical: spacing.sm }}>
              <ActivityIndicator />
            </View>
          ) : (
            <View>
              <CustomDropdown
                label="Ficha"
                placeholder="Seleccione"
                value={selectedAnimalFileId != null ? String(selectedAnimalFileId) : ''}
                onValueChange={(val) => setSelectedAnimalFileId(val ? Number(val) : null)}
                options={pickerItems.map((item) => ({
                  label: String(item?.animal?.nombre || item?.animal_nombre || `Ficha ${item.id}`),
                  value: String(item.id)
                }))}
              />
            </View>
          )}
          </Card>
        </View>
      </View>
    </SafeAreaView>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <View style={{ padding: spacing.md }}>
        <View style={containerStyle}>
          <Card>
            <Text style={{ textAlign: 'center', color: colors.textDark, marginBottom: spacing.sm, fontWeight: '600', fontSize: typography.lg }}>Liberaciones</Text>
          {items.length === 0 ? (
            <Text style={{ color: colors.text }}>Sin liberaciones</Text>
          ) : (
            <FlatList
              data={items}
              keyExtractor={(item, idx) => String(item.id || idx)}
              renderItem={({ item }) => {
                const title = item.titulo || item.title || 'Liberación';
                const date = formatDate(item.fecha || item.created_at);
                const time = item.hora || item.time || null;
                const color = getEventColor(title);
                const iconName = getEventIcon(title);
                const hasDetails = Array.isArray(item.details) && item.details.length > 0;
                // Obtener imagen desde imagen_url (campo que viene desde liberación)
                const raw = item.imagen_url || item.image_url || item.image || null;
                const imgUri = raw ? resolveImageUrl(raw) : null;
                return (
                  <View style={{ flexDirection: 'row', paddingVertical: spacing.sm }}>
                    <View style={{ width: 28, alignItems: 'center' }}>
                      <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: color, marginTop: spacing.xs }} />
                    </View>
                    <View style={{ flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: 8, padding: spacing.sm, backgroundColor: colors.cardBg }}>
                      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: spacing.xs }}>
                        <MaterialIcons name={iconName} size={18} color={color} style={{ marginRight: 8 }} />
                        <Text style={{ color: colors.textDark, fontWeight: '600', fontSize: typography.md }}>{title}</Text>
                      </View>
                      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: spacing.xs }}>
                        {/*<MaterialIcons name="access-time" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                        <Text style={{ color: colors.textLight, marginRight: 12 }}>{time || '—'}</Text>*/}
                        <MaterialIcons name="event" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                        <Text style={{ color: colors.textLight }}>{date}</Text>
                      </View>
                      {!!item.lugar && (
                        <View style={{ flexDirection: 'row', marginBottom: spacing.xs }}>
                          <MaterialIcons name="place" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                          <Text style={{ color: colors.text }}>{item.lugar}</Text>
                        </View>
                      )}
                      {hasDetails ? (
                        <View style={{ marginBottom: spacing.xs }}>
                          {item.details.map((d, idx) => (
                            <View key={String(idx)} style={{ flexDirection: 'row', marginBottom: 4 }}>
                              <Text style={{ color: colors.textLight, marginRight: 6 }}>{String(d.label || 'Dato')}:</Text>
                              <Text style={{ color: colors.text }}>{String(d.value || '')}</Text>
                            </View>
                          ))}
                        </View>
                      ) : null}
                      {!!item.descripcion && (
                        <Text style={{ color: colors.text }}>{item.descripcion}</Text>
                      )}
                      <View style={{ marginTop: spacing.sm, alignItems: 'flex-end' }}>
                        {renderThumb(imgUri, (u) => setPreviewImage(u))}
                      </View>
                    </View>
                  </View>
                );
              }}
            />
          )}
          </Card>
        </View>
        <Modal visible={!!previewImage} transparent animationType="fade" onRequestClose={() => setPreviewImage(null)}>
          <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' }}>
            <View style={{ width: '88%', maxWidth: 500, backgroundColor: colors.cardBg, borderRadius: 8, padding: spacing.md }}>
              <Text style={{ color: colors.textDark, fontWeight: '600', textAlign: 'center', marginBottom: spacing.sm }}>Imagen</Text>
              {previewImage ? (
                <Image source={{ uri: String(previewImage) }} style={{ width: '100%', height: 280, borderRadius: 6 }} resizeMode="cover" />
              ) : null}
              <Pressable onPress={() => setPreviewImage(null)} style={{ marginTop: spacing.md, alignItems: 'center', backgroundColor: colors.neutral, padding: spacing.sm, borderRadius: 6 }}>
                <Text style={{ color: colors.text, fontWeight: '600' }}>Cerrar</Text>
              </Pressable>
            </View>
          </View>
        </Modal>
      </View>
    </SafeAreaView>
  );
}
const renderThumb = (uri, onPress) => {
  if (uri) {
    return (
      <Pressable onPress={() => onPress(uri)} accessibilityLabel="Abrir imagen de liberación">
        <Image source={{ uri: String(uri) }} style={{ width: 120, height: 90, borderRadius: 6, borderWidth: 1, borderColor: colors.border }} />
      </Pressable>
    );
  }
  return (
    <View style={{ width: 120, height: 90, borderRadius: 6, borderWidth: 1, borderColor: colors.border, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.cardFooterBg }}>
      <MaterialIcons name="image" size={22} color={colors.icon} />
      <Text style={{ color: colors.textLight, marginTop: 4 }}>Sin imagen</Text>
    </View>
  );
};
const formatDate = (s) => {
  if (!s) return 'N/D';
  const d = new Date(s);
  if (isNaN(d.getTime())) return String(s);
  const dd = String(d.getDate()).padStart(2, '0');
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const yy = d.getFullYear();
  return `${dd}/${mm}/${yy}`;
};
