import { useEffect, useState } from 'react';
import { View, Text, ActivityIndicator, FlatList, Image, Modal, Pressable, ScrollView, useWindowDimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import Card from '../components/Card';
import { colors } from '../theme/colors';
import { spacing, typography } from '../theme/layout';
import { listAnimalHistories, getLatestAnimalHistories } from '../api/animalHistories';
import { listAnimalFiles, getAnimalFile } from '../api/animalFiles';
import CustomDropdown from '../components/CustomDropdown';
import { MaterialIcons } from '@expo/vector-icons';
import { resolveImageUrl } from '../api/reports';
import useIsMounted from '../hooks/useIsMounted';

export default function HistoryScreen({ route }) {
  const navigation = useNavigation();
  const paramAnimalFileId = route?.params?.animalFileId;
  const [selectedAnimalFileId, setSelectedAnimalFileId] = useState(null);
  const animalFileId = paramAnimalFileId ?? selectedAnimalFileId;
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [previewImage, setPreviewImage] = useState(null);
  const [pickerLoading, setPickerLoading] = useState(false);
  const [pickerItems, setPickerItems] = useState([]);
  const isMounted = useIsMounted();
  const { width } = useWindowDimensions();
  const isWide = width > 600;
  const isTablet = width > 900;
  const containerStyle = isWide ? { maxWidth: isTablet ? 900 : 600, alignSelf: 'center', width: '100%' } : {};

  const getEventColor = (title) => {
    const t = String(title || '').toLowerCase();
    if (t.includes('hallazgo')) return colors.blue;
    if (t.includes('traslado')) return colors.warning;
    if (t.includes('evalu')) return colors.success;
    if (t.includes('liber')) return colors.blueDark;
    return colors.neutral;
  };

  const getEventIcon = (title) => {
    const t = String(title || '').toLowerCase();
    if (t.includes('hallazgo')) return 'place';
    if (t.includes('traslado')) return 'local-shipping';
    if (t.includes('evalu')) return 'medical-services';
    if (t.includes('liber')) return 'flight-takeoff';
    return 'info';
  };

  useEffect(() => {
    (async () => {
      if (!animalFileId) {
        if (isMounted.current) {
          setItems([]);
          setLoading(false);
        }
        return;
      }
      try {
        const data = await listAnimalHistories(animalFileId);
        const arr = Array.isArray(data) ? data : [];
        if (isMounted.current) setItems(arr);
      } finally {
        if (isMounted.current) setLoading(false);
      }
    })();
  }, [animalFileId]);

  useEffect(() => {
    (async () => {
      if (animalFileId) return;
      if (isMounted.current) setPickerLoading(true);
      try {
        const data = await listAnimalFiles({});
        const arr = Array.isArray(data) ? data : [];
        if (arr.length > 0) {
          if (isMounted.current) setPickerItems(arr);
        } else {
          const latest = await getLatestAnimalHistories({ order: 'desc', page: 1 }).catch(() => ({ data: [] }));
          const fromLatest = Array.isArray(latest?.data) ? latest.data : [];
          const ids = [];
          const seen = new Set();
          for (const it of fromLatest) {
            const id = it?.animal_file_id ?? it?.animalFileId ?? it?.id;
            if (!id) continue;
            const key = String(id);
            if (seen.has(key)) continue;
            seen.add(key);
            ids.push(Number(id));
          }
          if (ids.length === 0) {
            if (isMounted.current) setPickerItems([]);
          } else {
            const files = await Promise.all(ids.map((id) => getAnimalFile(id).catch(() => ({ id }))));
            const items = files.map((f) => ({
              id: f.id ?? f?.animal_file_id ?? f?.animalFileId,
              animal_nombre: f?.animal?.nombre || f?.animal_nombre || `Ficha ${f.id ?? ''}`,
              animal: f?.animal || undefined,
            })).filter((x) => x.id != null);
            if (isMounted.current) setPickerItems(items);
          }
        }
      } finally {
        if (isMounted.current) setPickerLoading(false);
      }
    })();
  }, [animalFileId]);

  if (loading) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator />
      </SafeAreaView>
    );
  }

  if (!animalFileId) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
        <View style={{ padding: spacing.md }}>
          <View style={containerStyle}>
            <Card>
              <Text style={{ textAlign: 'center', color: colors.textDark, marginBottom: spacing.sm, fontWeight: '600', fontSize: typography.lg }}>
                Selecciona ficha
              </Text>
            {pickerLoading ? (
              <View style={{ alignItems: 'center', paddingVertical: spacing.sm }}>
                <ActivityIndicator />
              </View>
            ) : (
              <View>
                <CustomDropdown
                  label="Ficha"
                  placeholder="Seleccione"
                  value={selectedAnimalFileId != null ? String(selectedAnimalFileId) : ''}
                  onValueChange={(val) => setSelectedAnimalFileId(val ? Number(val) : null)}
                  options={pickerItems.map(item => ({
                    label: String(item?.animal?.nombre || item?.animal_nombre || `Ficha ${item.id}`),
                    value: String(item.id)
                  }))}
                />
              </View>
            )}
            </Card>
          </View>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.md + 20 }} keyboardShouldPersistTaps="handled">
        <View style={containerStyle}>
          <Card>
            <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: spacing.sm }}>
              <Text style={{ flex: 1, color: colors.textDark, fontWeight: '600', fontSize: typography.lg }}>Historial</Text>
            </View>
          {items.length === 0 ? (
            <Text style={{ color: colors.text }}>Sin historial</Text>
          ) : (
            <View>
              {items.map((item, idx) => {
                const title = item.title || item.titulo || 'Evento';
                const when = item.changed_at_label || item.changed_at || '';
                const color = getEventColor(title);
                const iconName = getEventIcon(title);
                const hasDetails = Array.isArray(item.details) && item.details.length > 0;
                const raw = item.image_url || item.image || null;
                const imgUri = raw ? resolveImageUrl(raw) : null;
                return (
                  <View key={String(item.id || idx)} style={{ flexDirection: 'row', paddingVertical: spacing.sm }}>
                    <View style={{ width: 28, alignItems: 'center' }}>
                      <MaterialIcons name={iconName} size={24} color={color} />
                    </View>
                    <View style={{ flex: 1, paddingLeft: spacing.sm }}>
                      <Text style={{ color, fontWeight: '600', fontSize: typography.md }}>{title}</Text>
                      {!!when && (
                        <Text style={{ color: colors.text, marginTop: 2, fontSize: typography.sm }}>{when}</Text>
                      )}
                      {hasDetails &&
                        item.details.map((d, i) => (
                          <Text key={`d-${i}`} style={{ color: colors.textDark, marginTop: 2, fontSize: typography.sm }}>
                            {String(d.label || '')}: {String(d.value || '')}
                          </Text>
                        ))}
                    </View>
                    {imgUri && (
                      <Pressable onPress={() => setPreviewImage(imgUri)} style={{ marginLeft: spacing.sm }}>
                        <Image
                          source={{ uri: imgUri }}
                          style={{ width: 64, height: 64, borderRadius: 6, backgroundColor: colors.card }}
                          resizeMode="cover"
                        />
                      </Pressable>
                    )}
                  </View>
                );
              })}
            </View>
          )}
          </Card>
        </View>
      </ScrollView>

      <Modal visible={!!previewImage} transparent animationType="fade" onRequestClose={() => setPreviewImage(null)}>
        <Pressable style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', alignItems: 'center' }} onPress={() => setPreviewImage(null)}>
          {!!previewImage && (
            <Image source={{ uri: previewImage }} style={{ width: '88%', height: '70%', borderRadius: 10 }} resizeMode="contain" />
          )}
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}
