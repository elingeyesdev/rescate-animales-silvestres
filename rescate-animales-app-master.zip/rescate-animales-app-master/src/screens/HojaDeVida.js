import React, { useEffect, useState } from 'react';
import { View, Text, ActivityIndicator, Image, Modal, Pressable, ScrollView, useWindowDimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Card from '../components/Card';
import { colors } from '../theme/colors';
import { spacing, typography } from '../theme/layout';
import { getAnimalFile } from '../api/animalFiles';
import { listAnimalFiles } from '../api/animalFiles';
import { listMedicalEvaluations } from '../api/medicalEvaluations';
import { listAnimalCares } from '../api/animalCares';
import { listTransfers } from '../api/transfers';
import { listAnimalHistories } from '../api/animalHistories';
import { listReleases } from '../api/releases';
import { PrimaryButton, SecondaryButton } from '../components/Buttons';
import { resolveImageUrl } from '../api/reports';
import CustomDropdown from '../components/CustomDropdown';
import { MaterialIcons } from '@expo/vector-icons';
import apiClient from '../api/client';
import useIsMounted from '../hooks/useIsMounted';

export default function HojaDeVida({ route, navigation }) {
  const paramAnimalFileId = route?.params?.animalFileId;
  const [selectedAnimalFileId, setSelectedAnimalFileId] = useState(null);
  const animalFileId = paramAnimalFileId ?? selectedAnimalFileId;
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [evaluations, setEvaluations] = useState([]);
  const [cares, setCares] = useState([]);
  const [transfers, setTransfers] = useState([]);
  const [history, setHistory] = useState([]);
  const [releases, setReleases] = useState([]);
  const [previewImage, setPreviewImage] = useState(null);
  const [pickerLoading, setPickerLoading] = useState(false);
  const [pickerItems, setPickerItems] = useState([]);
  const [showEvaluations, setShowEvaluations] = useState(false);
  const [showCares, setShowCares] = useState(false);
  const [showTransfers, setShowTransfers] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [showReleases, setShowReleases] = useState(false);
  const [currentStatusName, setCurrentStatusName] = useState(null);
  const isMounted = useIsMounted();
  const { width } = useWindowDimensions();
  const isWide = width > 600;
  const isTablet = width > 900;
  const containerStyle = isWide ? { maxWidth: isTablet ? 900 : 600, alignSelf: 'center', width: '100%' } : {};

  const statusBadge = (name) => (
    <View style={{ paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6, backgroundColor: colors.cardFooterBg, borderWidth: 1, borderColor: colors.border }}>
      <Text style={{ color: colors.text }}>{name || '—'}</Text>
    </View>
  );

  const careIconAndColor = (tipoNombre) => {
    const t = String(tipoNombre || '').toLowerCase();
    if (t.includes('alimen')) return { icon: 'restaurant', color: colors.blue };
    if (t.includes('higien')) return { icon: 'local-laundry-service', color: colors.warning };
    if (t.includes('vacun') || t.includes('medic')) return { icon: 'medical-services', color: colors.success };
    return { icon: 'info', color: colors.neutral };
  };

  const eventColor = (title) => {
    const t = String(title || '').toLowerCase();
    if (t.includes('hallazgo')) return colors.blue;
    if (t.includes('traslado')) return colors.warning;
    if (t.includes('evalu')) return colors.success;
    if (t.includes('liber')) return (colors.blueDark || colors.blue);
    return colors.neutral;
  };

  const eventIcon = (title) => {
    const t = String(title || '').toLowerCase();
    if (t.includes('hallazgo')) return 'place';
    if (t.includes('traslado')) return 'local-shipping';
    if (t.includes('evalu')) return 'medical-services';
    if (t.includes('liber')) return 'flight-takeoff';
    return 'info';
  };

  const validIcons = new Set([
    'restaurant',
    'local-laundry-service',
    'medical-services',
    'place',
    'local-shipping',
    'flight-takeoff',
    'pets',
    'person',
    'event',
    'access-time',
    'history',
    'image',
    'assignment',
    'health-and-safety',
    'flag',
    'info',
  ]);
  const IconSafe = ({ name, size, color, style }) => {
    const n = typeof name === 'string' && validIcons.has(name) ? name : 'info';
    return <MaterialIcons name={n} size={size} color={color} style={style} />;
  };

  const formatDate = (s) => {
    if (!s) return 'N/D';
    const d = new Date(s);
    if (isNaN(d.getTime())) return String(s);
    const dd = String(d.getDate()).padStart(2, '0');
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const yy = d.getFullYear();
    return `${dd}/${mm}/${yy}`;
  };

  const isValidHttp = (u) => typeof u === 'string' && (u.startsWith('http://') || u.startsWith('https://'));
  const renderThumb = (uri, onPress) => {
    if (uri && isValidHttp(uri)) {
      return (
        <Pressable onPress={() => onPress(uri)}>
          <Image source={{ uri: String(uri) }} style={{ width: 120, height: 90, borderRadius: 6, borderWidth: 1, borderColor: colors.border }} />
        </Pressable>
      );
    }
    return (
      <View style={{ width: 120, height: 90, borderRadius: 6, borderWidth: 1, borderColor: colors.border, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.cardFooterBg }}>
        <IconSafe name="image" size={22} color={colors.icon} />
        <Text style={{ color: colors.textLight, marginTop: 4 }}>Sin imagen</Text>
      </View>
    );
  };

  useEffect(() => {
    (async () => {
      const fid = animalFileId != null && animalFileId !== '' ? Number(animalFileId) : null;
      if (!fid) {
        if (isMounted.current) {
          setFile(null);
          setEvaluations([]);
          setCares([]);
          setTransfers([]);
          setHistory([]);
          setReleases([]);
          setCurrentStatusName(null);
          setLoading(false);
        }
        return;
      }
      try {
        const data = await getAnimalFile(fid);
        if (isMounted.current) setFile(data);
        const aid = data?.animal?.id || data?.animal_id;
        const estadoId = data?.estado?.id || data?.estado_id;

        // Load status name from API
        let statusName = null;
        if (estadoId) {
          try {
            const statusRes = await apiClient.get('/animal-statuses').catch(() => ({ data: [] }));
            const statuses = Array.isArray(statusRes?.data?.data)
              ? statusRes.data.data
              : (Array.isArray(statusRes?.data) ? statusRes.data : []);
            const status = statuses.find((s) => String(s.id) === String(estadoId));
            statusName = status?.nombre || status?.name || null;
          } catch (e) {
            console.log('Error loading status from API', e);
          }
        }
        if (isMounted.current) setCurrentStatusName(statusName);

        const [ev, cr, tr, hi, rl] = await Promise.all([
          listMedicalEvaluations(fid).catch(() => []),
          listAnimalCares(fid).catch(() => []),
          listTransfers(aid).catch(() => []),
          listAnimalHistories(fid).catch(() => []),
          listReleases(fid).catch(() => []),
        ]);
        if (isMounted.current) {
          setEvaluations(ev);
          setCares(cr);
          setTransfers(tr);
          setHistory(hi);
          setReleases(rl);
        }
      } catch (e) {
        if (isMounted.current) {
          setFile(null);
          setEvaluations([]);
          setCares([]);
          setTransfers([]);
          setHistory([]);
          setReleases([]);
          setCurrentStatusName(null);
        }
      } finally {
        if (isMounted.current) setLoading(false);
      }
    })();
  }, [animalFileId]);

  useEffect(() => {
    (async () => {
      if (animalFileId) return;
      if (isMounted.current) setPickerLoading(true);
      try {
        const data = await listAnimalFiles({});
        if (isMounted.current) setPickerItems(Array.isArray(data) ? data : []);
      } finally {
        if (isMounted.current) setPickerLoading(false);
      }
    })();
  }, [animalFileId]);

  if (loading) return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg, justifyContent: 'center', alignItems: 'center' }}>
      <ActivityIndicator />
    </SafeAreaView>
  );

  if (!file) return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <View style={{ padding: spacing.md }}>
        <View style={containerStyle}>
          <Card>
            <Text style={{ textAlign: 'center', color: colors.textDark, marginBottom: spacing.sm, fontWeight: '600', fontSize: typography.lg }}>Selecciona ficha</Text>
          {pickerLoading ? (
            <View style={{ alignItems: 'center', paddingVertical: spacing.sm }}>
              <ActivityIndicator />
            </View>
          ) : (
            <View>
              <CustomDropdown
                label="Ficha"
                placeholder="Seleccione"
                value={selectedAnimalFileId != null ? String(selectedAnimalFileId) : ''}
                onValueChange={(val) => setSelectedAnimalFileId(val ? Number(val) : null)}
                options={(Array.isArray(pickerItems) ? pickerItems : []).map((item) => ({
                  label: String(item?.animal?.nombre || item?.animal_nombre || `Ficha ${item.id}`),
                  value: String(item.id)
                }))}
              />
            </View>
          )}
          <View style={{ marginTop: spacing.sm }}>
            <PrimaryButton title="Agregar Hoja de Vida" onPress={() => navigation.navigate('AnimalFileCreate')} />
          </View>
          </Card>
        </View>
      </View>
    </SafeAreaView>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.md + 20 }} keyboardShouldPersistTaps="handled">
        <View style={containerStyle}>
          <Card>
            <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: spacing.sm }}>
              <View style={{ flex: 1 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap' }}>
                <Text style={{ color: colors.textDark, fontWeight: '700', fontSize: typography.lg }}>{file?.animal?.nombre || 'Hoja de vida'}</Text>
                {releases.length > 0 && (
                  <Text style={{ color: colors.success, fontWeight: '600', fontSize: typography.md, marginLeft: spacing.xs }}>• Liberado</Text>
                )}
              </View>
              <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: spacing.xs }}>
                <MaterialIcons name="person" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                <Text style={{ color: colors.textLight, marginRight: 10 }}>{file?.animal?.sexo || '—'}</Text>
                {statusBadge(currentStatusName || file?.estado?.nombre || file?.estado_nombre)}
              </View>
            </View>

          </View>
          <View style={{ flexDirection: 'row', alignItems: 'flex-start' }}>
            <View style={{ flex: 1 }}>
              {/*<View style={{ flexDirection: 'row', alignItems: 'center', marginTop: spacing.xs }}>
                <MaterialIcons name="pets" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                <Text style={{ color: colors.text }}>{file?.especie?.nombre || file?.especie_nombre || 'Especie'}</Text>
                <Text style={{ color: colors.textLight, marginLeft: 8 }}>•</Text>
              </View>*/}
              <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: spacing.xs }}>
                <MaterialIcons name="event" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                <Text style={{ color: colors.textLight }}>Ingreso: {formatDate(file?.created_at)}</Text>
              </View>
            </View>
            <View style={{ marginLeft: spacing.sm }}>
              {renderThumb(resolveImageUrl(file?.imagen_url || file?.image_url || file?.imagen || file?.image), (u) => setPreviewImage(u))}
            </View>
          </View>

          <View style={{ marginTop: spacing.md }}>
            <Text style={{ color: colors.textDark, fontWeight: '600', marginBottom: spacing.xs }}>Resumen</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', marginRight: spacing.md, marginBottom: spacing.xs }}>
                <IconSafe name="medical-services" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                <Text style={{ color: colors.text }}>Evaluaciones: {evaluations.length}</Text>
              </View>
              <View style={{ flexDirection: 'row', alignItems: 'center', marginRight: spacing.md, marginBottom: spacing.xs }}>
                <IconSafe name="health-and-safety" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                <Text style={{ color: colors.text }}>Cuidados: {cares.length}</Text>
              </View>
              <View style={{ flexDirection: 'row', alignItems: 'center', marginRight: spacing.md, marginBottom: spacing.xs }}>
                <MaterialIcons name="history" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                <Text style={{ color: colors.text }}>Historial: {history.length}</Text>
              </View>
              <View style={{ flexDirection: 'row', alignItems: 'center', marginRight: spacing.md, marginBottom: spacing.xs }}>
                <MaterialIcons name="flight-takeoff" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                <Text style={{ color: colors.text }}>Liberaciones: {releases.length}</Text>
              </View>
            </View>
          </View>
          <View style={{ marginTop: spacing.md }}>
            <SecondaryButton title="Ver evaluaciones" onPress={() => navigation.navigate('Evaluations', { animalFileId })} style={{ marginBottom: spacing.xs }} />
            <SecondaryButton title="Ver cuidados" onPress={() => navigation.navigate('Cares', { animalFileId })} style={{ marginBottom: spacing.xs }} />
            <SecondaryButton title="Ver historial" onPress={() => navigation.navigate('History', { animalFileId })} style={{ marginBottom: spacing.xs }} />
            <SecondaryButton title="Ver liberaciones" onPress={() => navigation.navigate('Releases', { animalFileId })} style={{ marginBottom: spacing.xs }} />
            {/* Deshabilitado para aplicación móvil
            {file?.animal?.id && releases.length === 0 ? (
              <SecondaryButton title="Traslado entre centros" onPress={() => navigation.navigate('Transfers', { animalId: file.animal.id })} />
            ) : null}
            */}
          </View>
          <View style={{ marginTop: spacing.md }}>
            <Pressable onPress={() => setShowEvaluations((v) => !v)} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: spacing.sm }}>
              <IconSafe name="medical-services" size={18} color={colors.icon} style={{ marginRight: 8 }} />
              <Text style={{ color: colors.textDark, fontWeight: '600', fontSize: typography.md }}>Evaluaciones médicas</Text>
              <Text style={{ color: colors.textLight, marginLeft: 8 }}>({evaluations.length})</Text>
            </Pressable>
            {showEvaluations ? (
              evaluations.length === 0 ? (
                <Text style={{ color: colors.text }}>Sin evaluaciones</Text>
              ) : (
                <View>
                  {(Array.isArray(evaluations) ? evaluations : []).map((item, idx) => {
                    const title = item.descripcion || 'Evaluación médica';
                    const date = formatDate(item.fecha || item.created_at);
                    const time = item.hora || item.time || null;
                    const colorDot = colors.success;
                    const imgUriRaw = item.image_url || item.image || null;
                    const imgUri = imgUriRaw ? resolveImageUrl(imgUriRaw) : null;
                    return (
                      <View key={String(item.id || idx)} style={{ flexDirection: 'row', paddingVertical: spacing.sm }}>
                        <View style={{ width: 28, alignItems: 'center' }}>
                          <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: colorDot, marginTop: spacing.xs }} />
                        </View>
                        <View style={{ flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: 8, padding: spacing.sm, backgroundColor: colors.cardBg }}>
                          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: spacing.xs }}>
                            <IconSafe name="medical-services" size={18} color={colorDot} style={{ marginRight: 8 }} />
                            <Text style={{ color: colors.textDark, fontWeight: '600', fontSize: typography.md }}>{title}</Text>
                          </View>
                          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: spacing.xs }}>
                            <MaterialIcons name="access-time" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                            <Text style={{ color: colors.textLight, marginRight: 12 }}>{time || '—'}</Text>
                            <MaterialIcons name="event" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                            <Text style={{ color: colors.textLight }}>{date}</Text>
                          </View>
                          <View style={{ marginTop: spacing.sm, alignItems: 'flex-end' }}>
                            {renderThumb(imgUri, (u) => setPreviewImage(u))}
                          </View>
                        </View>
                      </View>
                    );
                  })}
                </View>
              )
            ) : null}

            <Pressable onPress={() => setShowCares((v) => !v)} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: spacing.sm }}>
              <IconSafe name="health-and-safety" size={18} color={colors.icon} style={{ marginRight: 8 }} />
              <Text style={{ color: colors.textDark, fontWeight: '600', fontSize: typography.md }}>Cuidados</Text>
              <Text style={{ color: colors.textLight, marginLeft: 8 }}>({cares.length})</Text>
            </Pressable>
            {showCares ? (
              cares.length === 0 ? (
                <Text style={{ color: colors.text }}>Sin cuidados registrados</Text>
              ) : (
                <View>
                  {(Array.isArray(cares) ? cares : []).map((item, idx) => {
                    const tipo = item?.tipo?.nombre || item?.tipo_nombre || 'Cuidado';
                    const date = formatDate(item.fecha || item.created_at);
                    const time = item.hora || item.time || null;
                    const { icon, color } = careIconAndColor(tipo);
                    return (
                      <View key={String(item.id || idx)} style={{ flexDirection: 'row', paddingVertical: spacing.sm }}>
                        <View style={{ width: 28, alignItems: 'center' }}>
                          <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: color, marginTop: spacing.xs }} />
                        </View>
                        <View style={{ flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: 8, padding: spacing.sm, backgroundColor: colors.cardBg }}>
                          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: spacing.xs }}>
                            <IconSafe name={icon} size={18} color={color} style={{ marginRight: 8 }} />
                            <Text style={{ color: colors.textDark, fontWeight: '600', fontSize: typography.md }}>{tipo}</Text>
                          </View>
                          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <MaterialIcons name="access-time" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                            <Text style={{ color: colors.textLight, marginRight: 12 }}>{time || '—'}</Text>
                            <MaterialIcons name="event" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                            <Text style={{ color: colors.textLight }}>{date}</Text>
                          </View>
                        </View>
                      </View>
                    );
                  })}
                </View>
              )
            ) : null}


            <Pressable onPress={() => setShowHistory((v) => !v)} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: spacing.sm }}>
              <MaterialIcons name="history" size={18} color={colors.icon} style={{ marginRight: 8 }} />
              <Text style={{ color: colors.textDark, fontWeight: '600', fontSize: typography.md }}>Historial</Text>
              <Text style={{ color: colors.textLight, marginLeft: 8 }}>({history.length})</Text>
            </Pressable>
            {showHistory ? (
              history.length === 0 ? (
                <Text style={{ color: colors.text }}>Sin historial</Text>
              ) : (
                <View>
                  {(Array.isArray(history) ? history : []).map((item, idx) => {
                    const title = item.titulo || item.title || 'Evento';
                    const date = item.fecha || item.created_at || 'N/D';
                    const time = item.hora || item.time || null;
                    const color = eventColor(title);
                    const iconName = eventIcon(title);
                    const imgUriRaw = item.image_url || item.image || null;
                    const imgUri = imgUriRaw ? resolveImageUrl(imgUriRaw) : null;
                    return (
                      <View key={String(item.id || idx)} style={{ flexDirection: 'row', paddingVertical: spacing.sm }}>
                        <View style={{ width: 28, alignItems: 'center' }}>
                          <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: color, marginTop: spacing.xs }} />
                        </View>
                        <View style={{ flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: 8, padding: spacing.sm, backgroundColor: colors.cardBg }}>
                          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: spacing.xs }}>
                            <IconSafe name={iconName} size={18} color={color} style={{ marginRight: 8 }} />
                            <Text style={{ color: colors.textDark, fontWeight: '600', fontSize: typography.md }}>{title}</Text>
                          </View>
                          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: spacing.xs }}>
                            <MaterialIcons name="access-time" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                            <Text style={{ color: colors.textLight, marginRight: 12 }}>{time || '—'}</Text>
                            <MaterialIcons name="event" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                            <Text style={{ color: colors.textLight }}>{date}</Text>
                          </View>
                          <View style={{ marginTop: spacing.sm, alignItems: 'flex-end' }}>
                            {renderThumb(imgUri, (u) => setPreviewImage(u))}
                          </View>
                        </View>
                      </View>
                    );
                  })}
                </View>
              )
            ) : null}

            <Pressable onPress={() => setShowReleases((v) => !v)} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: spacing.sm }}>
              <MaterialIcons name="flight-takeoff" size={18} color={colors.icon} style={{ marginRight: 8 }} />
              <Text style={{ color: colors.textDark, fontWeight: '600', fontSize: typography.md }}>Liberaciones</Text>
              <Text style={{ color: colors.textLight, marginLeft: 8 }}>({releases.length})</Text>
            </Pressable>
            {showReleases ? (
              releases.length === 0 ? (
                <Text style={{ color: colors.text }}>Sin liberaciones</Text>
              ) : (
                <View>
                  {(Array.isArray(releases) ? releases : []).map((item, idx) => {
                    const title = item.titulo || item.title || 'Liberación';
                    const date = item.fecha || item.created_at || 'N/D';
                    const time = item.hora || item.time || null;
                    const color = String(title || '').toLowerCase().includes('reub') ? colors.success : (String(title || '').toLowerCase().includes('liber') ? colors.blueDark : colors.neutral);
                    const iconName = String(title || '').toLowerCase().includes('reub') ? 'place' : (String(title || '').toLowerCase().includes('liber') ? 'flight-takeoff' : 'flag');
                    const imgUriRaw = item.image_url || item.image || null;
                    const imgUri = imgUriRaw ? resolveImageUrl(imgUriRaw) : null;
                    return (
                      <View key={String(item.id || idx)} style={{ flexDirection: 'row', paddingVertical: spacing.sm }}>
                        <View style={{ width: 28, alignItems: 'center' }}>
                          <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: color, marginTop: spacing.xs }} />
                        </View>
                        <View style={{ flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: 8, padding: spacing.sm, backgroundColor: colors.cardBg }}>
                          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: spacing.xs }}>
                            <IconSafe name={iconName} size={18} color={color} style={{ marginRight: 8 }} />
                            <Text style={{ color: colors.textDark, fontWeight: '600', fontSize: typography.md }}>{title}</Text>
                          </View>
                          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: spacing.xs }}>
                            <MaterialIcons name="access-time" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                            <Text style={{ color: colors.textLight, marginRight: 12 }}>{time || '—'}</Text>
                            <MaterialIcons name="event" size={16} color={colors.icon} style={{ marginRight: 6 }} />
                            <Text style={{ color: colors.textLight }}>{date}</Text>
                          </View>
                          <View style={{ marginTop: spacing.sm, alignItems: 'flex-end' }}>
                            {renderThumb(imgUri, (u) => setPreviewImage(u))}
                          </View>
                        </View>
                      </View>
                    );
                  })}
                </View>
              )
            ) : null}
          </View>
          <Modal visible={!!previewImage} transparent animationType="fade" onRequestClose={() => setPreviewImage(null)}>
            <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' }}>
              <View style={{ width: '88%', maxWidth: 500, backgroundColor: colors.cardBg, borderRadius: 8, padding: spacing.md }}>
                <Text style={{ color: colors.textDark, fontWeight: '600', textAlign: 'center', marginBottom: spacing.sm }}>Imagen</Text>
                {previewImage ? (
                  <Image source={{ uri: String(previewImage) }} style={{ width: '100%', height: 280, borderRadius: 6 }} resizeMode="cover" />
                ) : null}
                <Pressable onPress={() => setPreviewImage(null)} style={{ marginTop: spacing.md, alignItems: 'center', backgroundColor: colors.neutral, padding: spacing.sm, borderRadius: 6 }}>
                  <Text style={{ color: colors.text, fontWeight: '600' }}>Cerrar</Text>
                </Pressable>
              </View>
            </View>
          </Modal>
          </Card>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
