import { useState, useRef } from 'react';
import { View, Text, Image, Pressable, Alert, Switch, Modal, useWindowDimensions } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import NetInfo from '@react-native-community/netinfo';
import Card from '../components/Card';

import InputWithIcon from '../components/InputWithIcon';
import { colors } from '../theme/colors';
import { createReport, buildReportForm, resolveImageUrl } from '../api/reports';
import apiClient from '../api/client';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { PrimaryButton, SecondaryButton, DangerButton } from '../components/Buttons';
import MapPreview from '../components/MapPreview';
import CentersMap from '../components/CentersMap';
import { savePendingReport, getPendingReportsCount, computeReportFingerprint, cacheFormData, getCachedFormData } from '../utils/offlineStorage';
import { saveReportToHistory } from '../utils/reportHistory';
import SyncService from '../services/SyncService';
import { useAuth } from '../context/AuthContext';
import useIsMounted from '../hooks/useIsMounted';

import { listCenters } from '../api/centers';
import { useEffect } from 'react';
import Checkbox from 'expo-checkbox';
import LeafletPicker from '../components/LeafletPicker';
import CustomDropdown from '../components/CustomDropdown';


export default function ReportCreateScreen() {
  const isMounted = useIsMounted();
  const { width } = useWindowDimensions();
  const isWide = width > 600;
  const isTablet = width > 900;
  // Center content on wide screens
  const containerStyle = isWide 
    ? { padding: 16, maxWidth: isTablet ? 960 : 640, alignSelf: 'center', width: '100%' }
    : { padding: 16 };

  const navigation = useNavigation();
  const { user, offlineMode } = useAuth();
  const [img, setImg] = useState(null);
  const [lat, setLat] = useState(null);
  const [lng, setLng] = useState(null);
  const [tamano, setTamano] = useState('mediano');
  const [puedeMoverse, setPuedeMoverse] = useState(false);
  const [condicionId, setCondicionId] = useState('');
  const [incidenteId, setIncidenteId] = useState('');
  const [observaciones, setObservaciones] = useState('');
  const [direccion, setDireccion] = useState('');
  const [trasladoInmediato, setTrasladoInmediato] = useState(false);
  const [loading, setLoading] = useState(false);
  const [centers, setCenters] = useState([]);
  const [selectedCenterId, setSelectedCenterId] = useState(null);
  const [conditions, setConditions] = useState([]);
  const [incidents, setIncidents] = useState([]);
  const [mapPickerOpen, setMapPickerOpen] = useState(false);
  const [clearConfirmOpen, setClearConfirmOpen] = useState(false);
  const [isOnline, setIsOnline] = useState(true);
  const [pendingCount, setPendingCount] = useState(0);
  const lastFpRef = useRef(null);

  useEffect(() => {
    // Monitor network state
    const unsubscribe = NetInfo.addEventListener(state => {
      if (isMounted.current) setIsOnline(state.isConnected ?? true);
    });

    // Start sync service
    SyncService.start();
    const syncUnsubscribe = SyncService.addListener((event, data) => {
      if (event === 'sync_complete') {
        loadPendingCount();
      }
      if (event === 'report_uploaded') {
        const fp = lastFpRef.current;
        if (fp && data?.fingerprint === fp && data?.traslado_inmediato && data?.centro_id && data?.reportId) {
          try { navigation.getParent()?.navigate('Transfers', { reportId: data.reportId, reporte_id: data.reportId, primer_traslado: true }); } catch {}
        }
      }
    });

    // Load initial pending count
    loadPendingCount();

    return () => {
      unsubscribe();
      syncUnsubscribe();
    };
  }, []);

  const loadPendingCount = async () => {
    try {
      const count = await getPendingReportsCount();
      if (isMounted.current) setPendingCount(count);
    } catch (e) {
      console.log('Error loading pending count', e);
    }
  };

  // Automatic Reverse Geocoding
  useEffect(() => {
    const fetchAddress = async () => {
      if (lat && lng) {
        try {
          const reverseGeocode = await Location.reverseGeocodeAsync({
            latitude: lat,
            longitude: lng
          });
          
          if (reverseGeocode && reverseGeocode.length > 0) {
            const address = reverseGeocode[0];
            // Construct a readable address
            const parts = [];
            if (address.street) {
               parts.push(address.street + (address.streetNumber ? ` ${address.streetNumber}` : ''));
            } else if (address.name && address.name !== address.city && address.name !== address.region) {
               parts.push(address.name);
            }
            
            if (address.district && address.district !== address.city) parts.push(address.district);
            if (address.city) parts.push(address.city);
            if (address.region && address.region !== address.city) parts.push(address.region);
            
            const formattedAddress = parts.join(', ');
            
            if (formattedAddress && isMounted.current) {
              console.log('[ReportCreate] Auto-filling address:', formattedAddress);
              setDireccion(formattedAddress);
            }
          }
        } catch (error) {
          console.log('Error reverse geocoding:', error);
        }
      }
    };
    
    fetchAddress();
  }, [lat, lng]);

  useEffect(() => {
    const loadSelects = async () => {
      try {
        if (offlineMode || !isOnline) {
          console.log('[ReportCreate] Loading form data from cache (offline mode)...');
          const [cachedConds, cachedIncs] = await Promise.all([
            getCachedFormData('conditions'),
            getCachedFormData('incidents')
          ]);
          
          if (isMounted.current) {
            setConditions(Array.isArray(cachedConds) ? cachedConds : []);
            setIncidents(Array.isArray(cachedIncs) ? cachedIncs : []);
          }
          return;
        }

        const [condRes, incRes] = await Promise.all([
          apiClient.get('/animal-conditions').catch(() => ({ data: [] })),
          apiClient.get('/incident-types').catch(() => ({ data: [] })),
        ]);
        // Verificar si la respuesta viene en data.data o solo data (como en otras pantallas)
        const condsRaw = Array.isArray(condRes?.data?.data)
          ? condRes.data.data
          : (Array.isArray(condRes?.data) ? condRes.data : []);
        const incsRaw = Array.isArray(incRes?.data?.data)
          ? incRes.data.data
          : (Array.isArray(incRes?.data) ? incRes.data : []);

        // Guardar en caché para uso offline
        if (Array.isArray(condsRaw) && condsRaw.length > 0) {
            await cacheFormData('conditions', condsRaw);
        }
        if (Array.isArray(incsRaw) && incsRaw.length > 0) {
            await cacheFormData('incidents', incsRaw);
        }

        // Usar solo los datos de la API, sin fallbacks hardcodeados
        if (isMounted.current) {
          setConditions(Array.isArray(condsRaw) ? condsRaw : []);
          setIncidents(Array.isArray(incsRaw) ? incsRaw : []);
        }
      } catch (e) {
        console.log('Error cargando condiciones e incidentes desde API', e?.response || e);
        
        // Intentar cargar de caché si falla la API
        try {
            const [cachedConds, cachedIncs] = await Promise.all([
                getCachedFormData('conditions'),
                getCachedFormData('incidents')
            ]);
            if (isMounted.current) {
                if (Array.isArray(cachedConds)) setConditions(cachedConds);
                if (Array.isArray(cachedIncs)) setIncidents(cachedIncs);
            }
        } catch (cacheErr) {
             console.log('Error loading cache fallback:', cacheErr);
             if (isMounted.current) {
                setConditions([]);
                setIncidents([]);
             }
        }
      }
    };
    loadSelects();
  }, [offlineMode, isOnline]);

  useEffect(() => {
    const loadCenters = async () => {
      try {
        // Allow loading even if offline (listCenters handles caching)
        const data = await listCenters();
        if (isMounted.current) {
          setCenters(Array.isArray(data) ? data : []);
          // Show message if offline and using cached data
          if ((!isOnline || offlineMode) && data.length > 0) {
            console.log('Using cached centers in offline mode');
          }
        }
      } catch (e) {
        console.log('No se pudieron cargar centros', e?.response || e);
        if (isMounted.current) setCenters([]);
      }
    };
    if (trasladoInmediato) {
      loadCenters();
    }
  }, [trasladoInmediato, isOnline, offlineMode]);

  const pickImage = async () => {
    try {
      console.log('[ReportCreate] pickImage called');
      const perm = await ImagePicker.requestCameraPermissionsAsync();
      console.log('[ReportCreate] Camera permission:', perm.granted);
      if (!perm.granted) {
        console.log('[ReportCreate] Camera permission denied');
        Alert.alert('Permiso denegado', 'Se requiere permiso de cámara para tomar fotos.');
        return;
      }

      // Request location permission
      console.log('[ReportCreate] Requesting location permission...');
      const locPerm = await Location.requestForegroundPermissionsAsync();
      console.log('[ReportCreate] Location permission:', locPerm.status);
      if (locPerm.status !== 'granted') {
        Alert.alert('Permiso de ubicación', 'Se recomienda permitir el acceso a la ubicación para registrar dónde se tomó la foto');
      }

      console.log('[ReportCreate] Launching camera...');
      const res = await ImagePicker.launchCameraAsync({
        quality: 0.8,
        exif: true,
        allowsEditing: false
      });
      console.log('[ReportCreate] Camera result:', { canceled: res.canceled, hasAssets: !!res.assets });

      if (!res.canceled && res.assets?.[0]) {
        const asset = res.assets[0];
        const mime = asset.mimeType || asset.type || '';
        const name = asset.fileName || asset.uri || '';
        const hasValidMime = String(mime).toLowerCase().startsWith('image/');
        const hasValidExt = /\.(jpe?g|png|gif)$/i.test(String(name));
        console.log('[ReportCreate] pickImage asset', { name, mime, uri: asset.uri, hasValidMime, hasValidExt, width: asset.width, height: asset.height });
        if (!hasValidMime && !hasValidExt) {
          console.log('[ReportCreate] Invalid image format');
          Alert.alert('Formato de imagen inválido', 'Formatos permitidos: JPG, PNG');
          return;
        }
        console.log('[ReportCreate] Setting image asset');
        if (isMounted.current) setImg(asset);

        // Try to get location from EXIF data first
        console.log('[ReportCreate] Checking EXIF data for location...');
        let locationCaptured = false;
        if (asset.exif) {
          console.log('[ReportCreate] EXIF data available:', Object.keys(asset.exif));
          const exifLat = asset.exif.GPSLatitude;
          const exifLng = asset.exif.GPSLongitude;
          const exifLatRef = asset.exif.GPSLatitudeRef;
          const exifLngRef = asset.exif.GPSLongitudeRef;
          console.log('[ReportCreate] GPS EXIF data:', { exifLat, exifLng, exifLatRef, exifLngRef });

          if (exifLat && exifLng) {
            // Convert EXIF GPS to decimal degrees
            const lat = (exifLatRef === 'S' ? -1 : 1) * exifLat;
            const lng = (exifLngRef === 'W' ? -1 : 1) * exifLng;
            console.log('[ReportCreate] Converted GPS coordinates:', { lat, lng });
            if (isFinite(lat) && isFinite(lng)) {
              if (isMounted.current) {
                setLat(Number(lat.toFixed(7)));
                setLng(Number(lng.toFixed(7)));
              }
              locationCaptured = true;
              console.log('[ReportCreate] Location captured from EXIF:', { lat, lng });
            }
          }
        } else {
          console.log('[ReportCreate] No EXIF data available');
        }

        // If EXIF location not available, get current location
        if (!locationCaptured && locPerm.status === 'granted') {
          console.log('[ReportCreate] Getting current location from GPS...');
          try {
            const pos = await Location.getCurrentPositionAsync({
              accuracy: Location.Accuracy.High
            });
            console.log('[ReportCreate] GPS position obtained:', pos.coords);
            if (isMounted.current) {
              setLat(Number(pos.coords.latitude.toFixed(7)));
              setLng(Number(pos.coords.longitude.toFixed(7)));
              console.log('[ReportCreate] Location captured from GPS:', {
                lat: pos.coords.latitude,
                lng: pos.coords.longitude
              });
              Alert.alert('Ubicación capturada', 'Se ha registrado la ubicación donde se tomó la foto');
            }
          } catch (e) {
            console.log('[ReportCreate] Error getting location:', e);
            Alert.alert('Ubicación', 'No se pudo obtener la ubicación automáticamente. Por favor, selecciónala manualmente.');
          }
        } else {
          console.log('[ReportCreate] Skipping GPS location:', { locationCaptured, locPermStatus: locPerm.status });
        }
      } else {
        console.log('[ReportCreate] Camera canceled or no assets');
      }
    } catch (e) {
      console.log('[ReportCreate] Error picking image:', e);
      Alert.alert('Error', 'No se pudo abrir la cámara.');
    }
  };

  const pickImageFromGallery = async () => {
    try {
      console.log('[ReportCreate] pickImageFromGallery called');
      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      console.log('[ReportCreate] Gallery permission:', perm.granted);
      if (!perm.granted) {
        console.log('[ReportCreate] Gallery permission denied');
        Alert.alert('Permiso denegado', 'Se requiere permiso de galería para adjuntar imágenes.');
        return;
      }
      console.log('[ReportCreate] Launching gallery...');
      const res = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        quality: 0.8,
      });
      console.log('[ReportCreate] Gallery result:', { canceled: res.canceled, hasAssets: !!res.assets });
      if (!res.canceled && res.assets?.[0]) {
        const asset = res.assets[0];
        const mime = asset.mimeType || asset.type || '';
        const name = asset.fileName || asset.uri || '';
        const hasValidMime = String(mime).toLowerCase().startsWith('image/');
        const hasValidExt = /\.(jpe?g|png|gif)$/i.test(String(name));
        console.log('[ReportCreate] gallery asset', { name, mime, uri: asset.uri, hasValidMime, hasValidExt, width: asset.width, height: asset.height });
        if (!hasValidMime && !hasValidExt) {
          console.log('[ReportCreate] Invalid gallery image format');
          Alert.alert('Formato de imagen inválido', 'Formatos permitidos: JPG, PNG');
          return;
        }
        console.log('[ReportCreate] Setting gallery image');
        if (isMounted.current) setImg(asset);
      } else {
        console.log('[ReportCreate] Gallery canceled or no assets');
      }
    } catch (e) {
      console.log('[ReportCreate] Error picking image from gallery:', e);
      Alert.alert('Error', 'No se pudo abrir la galería.');
    }
  };

  const getLocation = async () => {
    try {
      console.log('[ReportCreate] getLocation called');
      const { status } = await Location.requestForegroundPermissionsAsync();
      console.log('[ReportCreate] Location permission status:', status);
      if (status !== 'granted') {
        console.log('[ReportCreate] Location permission not granted');
        Alert.alert('Permiso', 'Se requiere permiso de ubicación');
        return;
      }
      console.log('[ReportCreate] Getting current position...');
      const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      console.log('[ReportCreate] Position obtained:', pos.coords);
      if (isMounted.current) {
        setLat(Number(pos.coords.latitude.toFixed(7)));
        setLng(Number(pos.coords.longitude.toFixed(7)));
        console.log('[ReportCreate] Opening map picker');
        setMapPickerOpen(true);
      }
    } catch (e) {
      console.log('[ReportCreate] Error getting location manually:', e);
      Alert.alert('Error', 'No se pudo obtener la ubicación.');
    }
  };

  const submit = async () => {
    console.log('[ReportCreate] ========== SUBMIT STARTED ==========');
    console.log('[ReportCreate] Form state:', {
      hasImg: !!img?.uri,
      lat,
      lng,
      tamano,
      puedeMoverse,
      condicionId,
      incidenteId,
      observaciones,
      trasladoInmediato,
      selectedCenterId,
      isOnline
    });
    try {
      if (isMounted.current) setLoading(true);
      if (!img?.uri) {
        console.log('[ReportCreate] No image selected');
        Alert.alert('Falta imagen', 'Toma una foto para registrar el hallazgo. Formatos permitidos: JPG, PNG');
        if (isMounted.current) setLoading(false);
        return;
      }
      const mime = img.mimeType || img.type || '';
      console.log('[ReportCreate] Image mime type:', mime);
      const name = img.fileName || img.uri || '';
      const hasValidMime = String(mime).toLowerCase().startsWith('image');
      const hasValidExt = /\.(jpe?g|png|gif)$/i.test(String(name));
      console.log('[ReportCreate] Image validation:', { hasValidMime, hasValidExt, name });
      if (!hasValidMime && !hasValidExt) {
        console.log('[ReportCreate] Invalid image format detected');
        Alert.alert('Formato de imagen inválido', 'Formatos permitidos: JPG, PNG o GIF');
        if (isMounted.current) setLoading(false);
        return;
      }
      if (lat == null || lng == null) {
        console.log('[ReportCreate] Missing location');
        Alert.alert('Falta ubicación', 'Obtén la ubicación actual antes de enviar');
        if (isMounted.current) setLoading(false);
        return;
      }
      console.log('[ReportCreate] Validating size...');
      const allowedSizes = ['pequeno', 'mediano', 'grande'];
      if (!allowedSizes.includes(tamano)) {
        console.log('[ReportCreate] Invalid size:', tamano);
        Alert.alert('Tamaño inválido', 'El tamaño debe ser pequeño, mediano o grande');
        if (isMounted.current) setLoading(false);
        return;
      }
      console.log('[ReportCreate] Validating condition and incident...');
      if (!condicionId) {
        console.log('[ReportCreate] Missing condition');
        Alert.alert('Condición requerida', 'Selecciona la condición inicial');
        if (isMounted.current) setLoading(false);
        return;
      }
      if (!incidenteId) {
        console.log('[ReportCreate] Missing incident');
        Alert.alert('Incidente requerido', 'Selecciona el tipo de incidente');
        if (isMounted.current) setLoading(false);
        return;
      }
      const condSel = conditions.find((c) => String(c.id) === String(condicionId));
      const incSel = incidents.find((i) => String(i.id) === String(incidenteId));
      console.log('[ReportCreate] Selected condition and incident:', { condSel, incSel });
      const condSlug = condSel?.slug || String(condSel?.nombre || '').toLowerCase();
      const incSlug = incSel?.slug || String(incSel?.nombre || '').toLowerCase();
      if ((condSlug === 'desconocido' || incSlug === 'otro') && !observaciones) {
        console.log('[ReportCreate] Observations required for unknown/other');
        Alert.alert('Observaciones requeridas', 'Agrega observaciones para esta condición/incidente');
        if (isMounted.current) setLoading(false);
        return;
      }
      console.log('[ReportCreate] Resolving image type...');
      const ext = String(name).toLowerCase().match(/\.(jpe?g|png|gif)$/)?.[1] || '';
      const typeResolved = String(mime).toLowerCase().startsWith('image/')
        ? mime
        : (ext === 'png' ? 'image/png' : ext === 'gif' ? 'image/gif' : 'image/jpeg');
      console.log('[ReportCreate] Resolved image type:', typeResolved);

      // Get persona_id from user
      const personaId = user?.persona?.id || user?.person?.id || user?.id || null;
      console.log('[ReportCreate] User persona_id:', personaId);

      const payloadPreview = {
        imagen: img ? { uri: img.uri, name: img.fileName || 'foto.jpg', type: typeResolved } : null,
        latitud: lat,
        longitud: lng,
        condicion_inicial_id: condicionId,
        tipo_incidente_id: incidenteId,
        tamano,
        puede_moverse: !!puedeMoverse,
        direccion,
        observaciones,
        traslado_inmediato: !!trasladoInmediato,
        centro_id: selectedCenterId,
        persona_id: personaId, // Add persona_id for transfers
      };
      try { lastFpRef.current = computeReportFingerprint(payloadPreview); } catch {}
      console.log('[ReportCreate] Payload preview created:', { ...payloadPreview, imagen: payloadPreview.imagen ? { ...payloadPreview.imagen, uri: 'REDACTED' } : null });

      // Check if online
      console.log('[ReportCreate] Checking online status:', isOnline);
      if (!isOnline) {
        // Save offline
        console.log('[ReportCreate] Offline mode: saving report locally');
        await savePendingReport(payloadPreview);
        try {
          const fp = computeReportFingerprint(payloadPreview);
          await saveReportToHistory({ ...payloadPreview, uploadedSuccessfully: false, fingerprint: fp });
        } catch {}
        console.log('[ReportCreate] Report saved offline, loading pending count');
        await loadPendingCount();
        console.log('[ReportCreate] Showing offline save alert');
        Alert.alert(
          'Guardado offline',
          'No hay conexión a internet. El hallazgo se guardó localmente y se enviará automáticamente cuando haya conexión.',
          [{ text: 'OK', onPress: () => { resetForm(); navigation.replace('MyReports'); } }]
        );
        return;
      }

      console.log('[ReportCreate] Online mode: building form and sending to API');
      console.log('[ReportCreate] submit payloadPreview', { ...payloadPreview, imagen: { ...(payloadPreview.imagen || {}), mimeOriginal: mime, ext } });
      const form = buildReportForm(payloadPreview);
      console.log('[ReportCreate] Form built, sending to API...');
      const r = await createReport(form);
      console.log('[ReportCreate] Reporte enviado OK', r);
      try {
        const rawUrl = r?.imagen_url || r?.image_url || r?.imagen || r?.image || null;
        const url = rawUrl ? resolveImageUrl(rawUrl) : null;
        console.log('[ReportCreate] Verifying uploaded image:', url);
        if (url) {
          const head = await fetch(url, { method: 'HEAD' }).catch((e) => ({ error: e?.message }));
          console.log('[ReportCreate] stored image HEAD', head?.status, head?.headers && head.headers.get && head.headers.get('content-type'));
        }
      } catch (e) {
        console.log('[ReportCreate] Error verifying image:', e);
      }
      try {
        const reportId = r?.id || r?.report_id || r?.reporte_id || r?.data?.id || null;
        const fp = computeReportFingerprint(payloadPreview);
        await saveReportToHistory({ uploadedSuccessfully: true, report_id: reportId, persona_id: personaId, centro_id: selectedCenterId, traslado_inmediato: trasladoInmediato ? 1 : 0, fingerprint: fp });
        if (trasladoInmediato && reportId && selectedCenterId) {
          navigation.getParent()?.navigate('Transfers', { reportId, reporte_id: reportId, primer_traslado: true });
        }
      } catch {}
      const msg = r?.message || 'Hallazgo registrado';
      console.log('[ReportCreate] Showing success alert');
      Alert.alert('OK', msg, [
        { text: 'Ir al inicio', onPress: () => navigation.replace('MyReports') }
      ]);

    } catch (e) {
      console.log('[ReportCreate] ========== ERROR IN SUBMIT ==========');
      console.log('[ReportCreate] Error details:', { status: e?.response?.status, data: e?.response?.data, message: e?.message, code: e?.code });

      // If error is network-related, save offline
      if (!isOnline || e?.message?.includes('Network') || e?.code === 'ERR_NETWORK') {
        console.log('[ReportCreate] Network error detected, saving offline');
        try {
          await savePendingReport(payloadPreview);
          await loadPendingCount();
          console.log('[ReportCreate] Report saved offline after error');
          Alert.alert(
            'Guardado offline',
            'Hubo un problema de conexión. El hallazgo se guardó localmente y se enviará cuando haya conexión.',
            [{ text: 'OK', onPress: () => { resetForm(); navigation.replace('MyReports'); } }]
          );
          return;
        } catch (offlineError) {
          console.error('[ReportCreate] Error saving offline:', offlineError);
        }
      }

      const msg = e?.response?.data?.message || e?.message || 'No se pudo registrar';
      const errorsObj = e?.response?.data?.errors || {};
      const errors = Array.isArray(errorsObj)
        ? errorsObj
        : Object.values(errorsObj).flat().filter(Boolean);
      const first = errors && errors.length > 0 ? `\n${errors[0]}` : '';
      console.log('[ReportCreate] Showing error alert:', msg + first);
      Alert.alert('Error', `${msg}${first}`);
    } finally {
      if (isMounted.current) setLoading(false);
      console.log('[ReportCreate] ========== SUBMIT FINISHED ==========');
    }
  };

  const resetForm = () => {
    setImg(null);
    setLat(null);
    setLng(null);
    setTamano('mediano');
    setPuedeMoverse(false);
    setCondicionId('');
    setIncidenteId('');
    setObservaciones('');
    setTrasladoInmediato(false);
    setSelectedCenterId(null);
    setMapPickerOpen(false);
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardShouldPersistTaps="handled">
          <View style={containerStyle}>
            <Card>
              <Text style={{ textAlign: 'center', color: colors.textDark, marginBottom: 12, fontSize: 18, fontWeight: '600' }}>Registrar hallazgo</Text>
            {!isOnline && (
              <View style={{ backgroundColor: colors.warning + '22', borderLeftWidth: 4, borderLeftColor: colors.warning, padding: 12, borderRadius: 6, marginBottom: 12 }}>
                <Text style={{ color: colors.warning, fontWeight: '600' }}>⚠️ Modo offline</Text>
                <Text style={{ color: colors.textDark, marginTop: 4 }}>Los reportes se guardarán localmente y se sincronizarán automáticamente cuando haya conexión</Text>
                <Pressable
                  onPress={async () => {
                    const state = await NetInfo.fetch();
                    setIsOnline(state.isConnected ?? false);
                    if (state.isConnected) {
                      Alert.alert('Conexión restaurada', 'Ya tienes conexión a internet');
                    } else {
                      Alert.alert('Sin conexión', 'Aún no hay conexión a internet');
                    }
                  }}
                  style={{ marginTop: 8, backgroundColor: colors.warning, paddingVertical: 8, paddingHorizontal: 12, borderRadius: 6, alignItems: 'center' }}
                >
                  <Text style={{ color: '#fff', fontWeight: '600' }}>Reintentar conexión</Text>
                </Pressable>
              </View>
            )}
            {pendingCount > 0 && (
              <View style={{ backgroundColor: colors.blue + '22', borderLeftWidth: 4, borderLeftColor: colors.blue, padding: 12, borderRadius: 6, marginBottom: 12 }}>
                <Text style={{ color: colors.blue, fontWeight: '600' }}>📤 {pendingCount} reporte{pendingCount > 1 ? 's' : ''} pendiente{pendingCount > 1 ? 's' : ''}</Text>
                <Text style={{ color: colors.textDark, marginTop: 4 }}>Se sincronizará{pendingCount > 1 ? 'n' : ''} cuando haya conexión a internet</Text>
              </View>
            )}

            <View style={{ flexDirection: isWide ? 'row' : 'column', gap: isTablet ? 32 : 24 }}>
              {/* Left Column (or Top) */}
              <View style={{ flex: 1 }}>
                <View style={{ marginBottom: 8, flexDirection: 'row', justifyContent: 'space-between' }}>
                  <PrimaryButton title="Tomar foto" onPress={pickImage} accessibilityLabel="Tomar foto del hallazgo" style={{ flex: 1, marginRight: 8 }} />
                  <SecondaryButton title="Subir foto" onPress={pickImageFromGallery} accessibilityLabel="Subir foto desde galería" style={{ flex: 1 }} />
                </View>
                <View style={{ marginBottom: 12 }}>
                  <DangerButton title="Limpiar" onPress={() => setClearConfirmOpen(true)} accessibilityLabel="Limpiar formulario" />
                </View>
                <Text style={{ color: colors.textLight, textAlign: 'center' }}>Formatos permitidos: JPG, PNG</Text>
                {img?.uri ? (
                  <Image source={{ uri: img.uri }} style={{ width: '100%', height: 240, marginTop: 12, borderRadius: 6 }} />
                ) : null}

                <View style={{ marginTop: 12 }}>
                  <Text style={{ color: colors.textDark, marginBottom: 6, fontWeight: '600' }}>Ubicación</Text>
                  <SecondaryButton title="Ubicación actual" onPress={getLocation} accessibilityLabel="Obtener ubicación actual" />
                  <SecondaryButton title="Marcar en mapa" onPress={() => setMapPickerOpen(true)} accessibilityLabel="Marcar ubicación en mapa" style={{ marginTop: 8 }} />
                  <SecondaryButton title="Limpiar ubicación" onPress={() => { setLat(null); setLng(null); }} accessibilityLabel="Limpiar ubicación seleccionada" style={{ marginTop: 8 }} />
                </View>
                {(lat != null && lng != null) ? (
                  <View style={{ marginTop: 8 }}>
                    <MapPreview lat={lat} lng={lng} height={180} title="Ubicación seleccionada" />
                  </View>
                ) : null}
              </View>

              {/* Right Column (or Bottom) */}
              <View style={{ flex: 1 }}>
                <View style={{ marginTop: isWide ? 0 : 16 }}>
                  <CustomDropdown
                    label="Condición inicial"
                    placeholder="Elegir condición"
                    value={condicionId}
                    onValueChange={setCondicionId}
                    options={conditions.map(c => ({
                      label: String(c.nombre || `Condición ${c.id}`),
                      value: c.id
                    }))}
                  />
                </View>

                <View style={{ marginTop: 12 }}>
                  <CustomDropdown
                    label="Tipo de incidente"
                    placeholder="Elegir incidente"
                    value={incidenteId}
                    onValueChange={setIncidenteId}
                    options={incidents.map(i => ({
                      label: String(i.nombre || `Incidente ${i.id}`),
                      value: i.id
                    }))}
                  />
                </View>

                <InputWithIcon icon="place" value={direccion} onChangeText={setDireccion} placeholder="Dirección (ubicación escrita)" accessibilityLabel="Dirección del hallazgo" multiline returnKeyType="done" style={{ marginTop: 12 }} />

                <View style={{ marginTop: 12 }}>
                  <CustomDropdown
                    label="Tamaño del animal"
                    value={tamano}
                    onValueChange={setTamano}
                    options={[
                      { label: "Pequeño", value: "pequeno" },
                      { label: "Mediano", value: "mediano" },
                      { label: "Grande", value: "grande" }
                    ]}
                  />
                </View>

                <View style={{ marginTop: 12, marginBottom: 4 }}>
                  <Text style={{ color: colors.textDark, marginBottom: 6 }}>¿Puede moverse?</Text>
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Switch
                      value={puedeMoverse}
                      onValueChange={setPuedeMoverse}
                      trackColor={{ false: '#ccc', true: colors.blue }}
                      thumbColor={puedeMoverse ? colors.blue : '#f4f3f4'}
                    />
                    <Text style={{ marginLeft: 8, color: colors.text }}>{puedeMoverse ? 'Sí' : 'No'}</Text>
                  </View>
                </View>

                <InputWithIcon icon="assignment" value={observaciones} onChangeText={setObservaciones} placeholder="Observaciones" accessibilityLabel="Observaciones del hallazgo" multiline returnKeyType="done" />

                <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 16, marginBottom: 8 }}>
                  <Checkbox value={trasladoInmediato} onValueChange={(v) => setTrasladoInmediato(v)} color={trasladoInmediato ? colors.blue : undefined} />
                  <Text style={{ marginLeft: 8, color: colors.text }}>Trasladaré al refugio ahora (opcional)</Text>
                </View>

                {trasladoInmediato ? (
                  <>
                    <Text style={{ color: colors.textDark, marginBottom: 8 }}>Selecciona un centro</Text>
                    {!isOnline && centers.length > 0 && (
                      <View style={{ backgroundColor: colors.blue + '22', borderLeftWidth: 4, borderLeftColor: colors.blue, padding: 12, borderRadius: 6, marginBottom: 12 }}>
                        <Text style={{ color: colors.blue, fontWeight: '600' }}>ℹ️ Modo offline</Text>
                        <Text style={{ color: colors.textDark, marginTop: 4 }}>Mostrando centros guardados en caché. Se actualizarán cuando haya conexión.</Text>
                      </View>
                    )}
                    <View style={{ marginBottom: 12 }}>
                      <CustomDropdown
                        label="Centro"
                        placeholder="Elegir centro"
                        value={selectedCenterId ?? ''}
                        onValueChange={(val) => setSelectedCenterId(val ? Number(val) : null)}
                        options={centers.map(c => ({
                          label: String(c.nombre || `Centro ${c.id}`),
                          value: Number(c.id)
                        }))}
                      />
                    </View>
                    <Text style={{ color: colors.textDark, marginBottom: 8 }}>Centros disponibles</Text>
                    <CentersMap
                      centers={centers}
                      selectedId={selectedCenterId}
                      userLat={lat}
                      userLng={lng}
                      onSelect={(c) => { setSelectedCenterId(c.id); }}
                      height={280}
                    />
                  </>
                ) : null}

                <PrimaryButton title={loading ? 'Enviando...' : 'Registrar hallazgo'} icon="add-circle" onPress={submit} disabled={loading} style={{ marginTop: 12 }} accessibilityLabel="Enviar hallazgo" />
              </View>
            </View>
          </Card>
          </View>
          <Modal visible={mapPickerOpen} animationType="slide" transparent={false} onRequestClose={() => setMapPickerOpen(false)}>
            <View style={{ flex: 1, backgroundColor: colors.bg }}>
              <View style={{ padding: 12 }}>
                <Text style={{ color: colors.textDark, textAlign: 'center' }}>Ajusta manualmente la ubicación en el mapa</Text>
              </View>
              <View style={{ flex: 1 }}>
                <LeafletPicker
                  lat={lat}
                  lng={lng}
                  onChange={(la, ln) => { setLat(Number(la)); setLng(Number(ln)); }}
                />
              </View>
              <View style={{ padding: 12 }}>
                <PrimaryButton title="Guardar ubicación" onPress={() => setMapPickerOpen(false)} accessibilityLabel="Guardar ubicación seleccionada" />
                <SecondaryButton title="Cancelar" onPress={() => setMapPickerOpen(false)} style={{ marginTop: 8 }} accessibilityLabel="Cancelar selección de ubicación" />
              </View>
            </View>
          </Modal>
          <Modal visible={clearConfirmOpen} animationType="fade" transparent onRequestClose={() => setClearConfirmOpen(false)}>
            <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center' }}>
              <View style={{ width: '86%', maxWidth: 420, backgroundColor: colors.cardBg, borderRadius: 8, padding: 16 }}>
                <Text style={{ color: colors.textDark, fontWeight: '600', marginBottom: 8, textAlign: 'center' }}>Limpiar formulario</Text>
                <Text style={{ color: colors.text, textAlign: 'center' }}>¿Seguro que deseas limpiar todos los campos?</Text>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 16 }}>
                  <SecondaryButton title="Cancelar" onPress={() => setClearConfirmOpen(false)} style={{ flex: 1, marginRight: 8 }} />
                  <DangerButton title="Sí, limpiar" onPress={() => { setClearConfirmOpen(false); resetForm(); Alert.alert('Formulario limpiado'); }} style={{ flex: 1, marginLeft: 8 }} />
                </View>
              </View>
            </View>
          </Modal>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
