import AsyncStorage from '@react-native-async-storage/async-storage';

const TOKEN_KEY = '@auth_token';
const REMEMBERED_EMAIL_KEY = '@remembered_email';
const REMEMBERED_PASSWORD_KEY = '@remembered_password';
const REMEMBER_ME_KEY = '@remember_me';
const CACHED_USER_KEY = '@cached_user';

export const storeToken = async (token) => {
  try {
    console.log('[tokenStore] storeToken called:', token ? 'token present' : 'no token');
    if (token) {
      await AsyncStorage.setItem(TOKEN_KEY, token);
      console.log('[tokenStore] Token stored successfully');
    } else {
      await AsyncStorage.removeItem(TOKEN_KEY);
      console.log('[tokenStore] Token removed');
    }
  } catch (error) {
    console.error('[tokenStore] Error guardando token', error);
  }
};

export const getToken = async () => {
  try {
    const token = await AsyncStorage.getItem(TOKEN_KEY);
    console.log('[tokenStore] getToken:', token ? 'token found' : 'no token');
    return token;
  } catch (error) {
    console.error('[tokenStore] Error leyendo token', error);
    return null;
  }
};

export const clearToken = async () => {
  try {
    console.log('[tokenStore] clearToken called');
    await AsyncStorage.removeItem(TOKEN_KEY);
    console.log('[tokenStore] Token cleared');
  } catch (error) {
    console.error('[tokenStore] Error eliminando token', error);
  }
};

// Funciones para "Recordarme"
export const storeRememberedCredentials = async (email, password, remember) => {
  try {
    console.log('[tokenStore] storeRememberedCredentials called:', { email, remember, hasPassword: !!password });
    if (remember && email) {
      await AsyncStorage.setItem(REMEMBERED_EMAIL_KEY, email);
      // Encode password in base64 for basic obfuscation
      if (password) {
        const encodedPassword = btoa(password);
        await AsyncStorage.setItem(REMEMBERED_PASSWORD_KEY, encodedPassword);
        console.log('[tokenStore] Email and password stored');
      }
      await AsyncStorage.setItem(REMEMBER_ME_KEY, 'true');
    } else {
      await AsyncStorage.removeItem(REMEMBERED_EMAIL_KEY);
      await AsyncStorage.removeItem(REMEMBERED_PASSWORD_KEY);
      await AsyncStorage.removeItem(REMEMBER_ME_KEY);
      console.log('[tokenStore] Remembered credentials cleared');
    }
  } catch (error) {
    console.error('[tokenStore] Error guardando credenciales recordadas', error);
  }
};

// Backward compatibility
export const storeRememberedEmail = storeRememberedCredentials;

export const getRememberedCredentials = async () => {
  try {
    const email = await AsyncStorage.getItem(REMEMBERED_EMAIL_KEY);
    const encodedPassword = await AsyncStorage.getItem(REMEMBERED_PASSWORD_KEY);
    const rememberMe = await AsyncStorage.getItem(REMEMBER_ME_KEY);

    // Decode password from base64
    let password = null;
    if (encodedPassword) {
      try {
        password = atob(encodedPassword);
      } catch (e) {
        console.error('[tokenStore] Error decoding password', e);
      }
    }

    console.log('[tokenStore] getRememberedCredentials:', {
      hasEmail: !!email,
      hasPassword: !!password,
      rememberMe: rememberMe === 'true'
    });

    return {
      email: email || null,
      password: password || null,
      rememberMe: rememberMe === 'true',
    };
  } catch (error) {
    console.error('[tokenStore] Error leyendo credenciales recordadas', error);
    return { email: null, password: null, rememberMe: false };
  }
};

// Backward compatibility
export const getRememberedEmail = getRememberedCredentials;

export const clearRememberedCredentials = async () => {
  try {
    console.log('[tokenStore] clearRememberedCredentials called');
    await AsyncStorage.removeItem(REMEMBERED_EMAIL_KEY);
    await AsyncStorage.removeItem(REMEMBERED_PASSWORD_KEY);
    await AsyncStorage.removeItem(REMEMBER_ME_KEY);
    console.log('[tokenStore] Remembered credentials cleared');
  } catch (error) {
    console.error('[tokenStore] Error eliminando credenciales recordadas', error);
  }
};

// Backward compatibility
export const clearRememberedEmail = clearRememberedCredentials;

export const storeCachedUser = async (user) => {
  try {
    const json = JSON.stringify(user || {});
    await AsyncStorage.setItem(CACHED_USER_KEY, json);
  } catch (error) {
    console.error('[tokenStore] Error guardando usuario cacheado', error);
  }
};

export const getCachedUser = async () => {
  try {
    const json = await AsyncStorage.getItem(CACHED_USER_KEY);
    return json ? JSON.parse(json) : null;
  } catch (error) {
    console.error('[tokenStore] Error leyendo usuario cacheado', error);
    return null;
  }
};

export const clearCachedUser = async () => {
  try {
    await AsyncStorage.removeItem(CACHED_USER_KEY);
  } catch (error) {
    console.error('[tokenStore] Error eliminando usuario cacheado', error);
  }
};


