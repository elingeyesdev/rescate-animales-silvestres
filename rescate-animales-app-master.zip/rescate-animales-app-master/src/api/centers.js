import apiClient from './client';
import { cacheCenters, getCachedCenters } from '../utils/offlineStorage';

export const listCenters = async (params = {}) => {
  const perPage = params.perPage ?? 20;
  const page = params.page ?? 1;

  try {
    const { data } = await apiClient.get('/centers', { params: { per_page: perPage, page } });
    const centers = Array.isArray(data) ? data : (data?.data ?? []);

    // Cache centers for offline use
    if (centers.length > 0) {
      await cacheCenters(centers);
    }

    return centers;
  } catch (e1) {
    try {
      const { data } = await apiClient.get('/centros', { params: { per_page: perPage, page } });
      const centers = Array.isArray(data) ? data : (data?.data ?? []);

      // Cache centers for offline use
      if (centers.length > 0) {
        await cacheCenters(centers);
      }

      return centers;
    } catch (e2) {
      // If both API calls fail, try to return cached centers
      console.log('API calls failed, attempting to use cached centers');
      const cached = await getCachedCenters();
      if (cached && cached.length > 0) {
        console.log('Using cached centers:', cached.length);
        return cached;
      }
      return [];
    }
  }
};

export const getCenter = async (id) => {
  if (!id) throw new Error('id requerido');
  try {
    const { data } = await apiClient.get(`/centers/${id}`);
    return data;
  } catch (e1) {
    try {
      const { data } = await apiClient.get(`/centros/${id}`);
      return data;
    } catch {
      throw e1;
    }
  }
};