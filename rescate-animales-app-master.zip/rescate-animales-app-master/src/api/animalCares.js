import apiClient from './client';

export const listAnimalCares = async (animalFileId, page = 1) => {
  if (!animalFileId) return [];
  const { data } = await apiClient.get('/animal-cares', { params: { animal_file_id: animalFileId, page } });
  const arr = Array.isArray(data?.data) ? data.data : (Array.isArray(data) ? data : []);
  return arr;
};

export const getAnimalCare = async (id) => {
  const { data } = await apiClient.get(`/animal-cares/${id}`);
  return data;
};

export const createAnimalCare = async (payload) => {
  const hasImage = !!payload?.imagen;
  if (hasImage) {
    const fd = new FormData();
    Object.entries(payload).forEach(([k, v]) => {
      if (v !== undefined && v !== null) fd.append(k, v);
    });
    const { data } = await apiClient.post('/animal-cares', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
    return data;
  }
  const { data } = await apiClient.post('/animal-cares', payload);
  return data;
};
