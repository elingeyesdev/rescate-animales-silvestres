import apiClient from './client';

export const listReleases = async (animalFileId) => {
  if (!animalFileId) return [];
  const { data } = await apiClient.get('/releases', { params: { animal_file_id: animalFileId } });
  const arr = Array.isArray(data?.data) ? data.data : (Array.isArray(data) ? data : []);
  return arr;
};

export const getRelease = async (id) => {
  const { data } = await apiClient.get(`/releases/${id}`);
  return data;
};

export const createRelease = async (payload) => {
  const { data } = await apiClient.post('/releases', payload);
  return data;
};

