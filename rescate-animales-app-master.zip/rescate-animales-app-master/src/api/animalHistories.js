import apiClient from './client';

export const listAnimalHistories = async (animalFileId) => {
  if (!animalFileId) return [];
  const { data } = await apiClient.get(`/animal-histories/${animalFileId}`);
  return Array.isArray(data?.timeline) ? data.timeline : [];
};

export const getAnimalHistory = async (animalFileId) => {
  const { data } = await apiClient.get(`/animal-histories/${animalFileId}`);
  return Array.isArray(data?.timeline) ? data.timeline : [];
};

export const getLatestAnimalHistories = async ({ order = 'desc', page = 1 } = {}) => {
  const { data } = await apiClient.get(`/animal-histories`, { params: { order, page } });
  return data;
};

// Eventos que generan historial

export const createMedicalEvaluation = async (payload) => {
  // Campos clave: animal_file_id, veterinario_id, apto_traslado ('si'|'no'|'con_restricciones')
  // Opcionales: tratamiento_id, tratamiento_texto, estado_id, descripcion, diagnostico, peso, temperatura, recomendacion
  const { data } = await apiClient.post('/animal-medical-evaluations', payload);
  return data;
};

export const createAnimalCare = async (payload) => {
  // Campos: animal_file_id, tipo_cuidado_id; opcional: descripcion
  const { data } = await apiClient.post('/animal-cares', payload);
  return data;
};

export const createAnimalFeeding = async (payload) => {
  // Campos: animal_file_id, feeding_type_id, feeding_frequency_id; opcional: feeding_portion_id
  const { data } = await apiClient.post('/animal-feedings', payload);
  return data;
};

export const createTransfer = async (payload) => {
  // Primer traslado: { report_id, centro_id, observaciones? }
  // Interno: { animal_id | animal_file_id, centro_id, persona_id?, observaciones? }
  const { data } = await apiClient.post('/transfers', payload);
  return data;
};

export const createRelease = async (payload) => {
  // Campos: animal_file_id, aprobada, direccion; opcional: latitud, longitud
  const { data } = await apiClient.post('/releases', payload);
  return data;
};

// El backend no permite crear historial manualmente
export const createAnimalHistory = async () => {
  throw new Error('El historial se genera automáticamente via evaluaciones/cuidados/traslados/liberaciones');
};
