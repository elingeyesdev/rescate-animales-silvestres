import apiClient from './client';

const SEXOS = ['Hembra', 'Macho', 'Desconocido'];

export const getAnimalFile = async (id) => {
  if (!id) throw new Error('Falta animalFileId');
  const { data } = await apiClient.get(`/animal-files/${id}`);
  return data;
};

export const listAnimalFiles = async (params = {}) => {
  const perPage = params.perPage ?? 20;
  const page = params.page ?? 1;
  const { data } = await apiClient.get('/animal-files', {
    params: { per_page: perPage, page, ...params },
  });
  return Array.isArray(data?.data) ? data.data : (Array.isArray(data) ? data : []);
};

export const createFirstTransfer = async ({ report_id, centro_id, observaciones }) => {
  const payload = { report_id, centro_id, observaciones };
  const { data } = await apiClient.post('/transfers', payload);
  return data;
};

export const createAnimalFile = async (payload, options = {}) => {
  const ensureTransfer = options.ensureTransfer ?? true;
  const centroId = options.centro_id;

  if (payload.sexo && !SEXOS.includes(payload.sexo)) {
    throw new Error('Sexo inválido');
  }

  const postMultipart = async () => {
    const fd = new FormData();
    const keys = [];
    Object.entries(payload).forEach(([k, v]) => {
      if (v !== undefined && v !== null) { fd.append(k, v); keys.push(k); }
    });
    console.log('POST /animal-files FormData keys', keys);
    const { data } = await apiClient.post('/animal-files', fd, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    console.log('POST /animal-files OK', data?.status || '', data);
    return data;
  };
  const doCreate = async () => postMultipart();

  try {
    return await doCreate();
  } catch (e) {
    const msg = e?.response?.data?.error || e?.response?.data?.message || '';
    const needsTransfer = typeof msg === 'string' && msg.toLowerCase().includes('primer traslado');
    console.log('POST /animal-files error', { msg, needsTransfer, ensureTransfer, reporte_id: payload.reporte_id, centroId, status: e?.response?.status, data: e?.response?.data });
    if (ensureTransfer && needsTransfer && payload.reporte_id && centroId) {
      await createFirstTransfer({
        report_id: payload.reporte_id,
        centro_id: centroId,
        observaciones: payload.descripcion,
      });
      return await doCreate();
    }
    throw e;
  }
};
