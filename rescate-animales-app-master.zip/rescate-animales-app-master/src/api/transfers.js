import apiClient from './client';

export const listTransfers = async (options) => {
  const base =
    typeof options === 'object' && options !== null
      ? options
      : options
        ? { animal_id: options }
        : null;
  if (!base) return [];

  const params = {};
  if (base.report_id) params.report_id = base.report_id;
  else if (base.reporte_id) params.report_id = base.reporte_id;
  else if (base.reportId) params.report_id = base.reportId;
  if (base.animal_id) params.animal_id = base.animal_id;
  else if (base.animalId) params.animal_id = base.animalId;
  if (base.page) params.page = base.page;
  if (base.perPage) params.per_page = base.perPage;

  const { data } = await apiClient.get('/transfers', { params });
  return Array.isArray(data?.data) ? data.data : (Array.isArray(data) ? data : []);
};

export const getTransfer = async (id) => {
  const { data } = await apiClient.get(`/transfers/${id}`);
  return data;
};

export const createTransfer = async ({ reporte_id, report_id, reportId, centro_id, centroId, observaciones, persona_id, personaId }) => {
  const rid = report_id ?? reporte_id ?? reportId;
  const cid = centro_id ?? centroId;
  const payload = { report_id: String(rid), centro_id: String(cid) };
  if (observaciones) payload.observaciones = observaciones;
  const pid = persona_id ?? personaId;
  if (pid != null) payload.persona_id = String(pid);
  const { data } = await apiClient.post('/transfers', payload);
  return data;
};

export const createInternalTransfer = async ({ animal_id, animalId, animal_file_id, animalFileId, centro_id, centroId, observaciones, persona_id, personaId }) => {
  const aid = animal_id ?? animalId;
  const afid = animal_file_id ?? animalFileId;
  const cid = centro_id ?? centroId;
  const payload = { centro_id: String(cid) };
  if (aid != null) payload.animal_id = String(aid);
  if (afid != null) payload.animal_file_id = String(afid);
  if (observaciones) payload.observaciones = observaciones;
  const pid = persona_id ?? personaId;
  if (pid != null) payload.persona_id = String(pid);
  const { data } = await apiClient.post('/transfers', payload);
  return data;
};

export const getCurrentCenterDestinations = async ({ animal_id, animalId }) => {
  const aid = animal_id ?? animalId;
  const { data } = await apiClient.get('/transfers', { params: { current_center: 1, animal_id: aid } });
  return data;
};
