import apiClient, { API_BASE_URL } from './client';

export const buildReportForm = ({ imagen, latitud, longitud, condicion_inicial_id, tipo_incidente_id, tamano, puede_moverse, direccion, observaciones, traslado_inmediato, centro_id, persona_id }) => {
  const fd = new FormData();
  console.log('[buildReportForm] Building form with params:', {
    hasImagen: !!imagen?.uri,
    latitud,
    longitud,
    condicion_inicial_id,
    tipo_incidente_id,
    tamano,
    puede_moverse,
    traslado_inmediato,
    centro_id,
    persona_id
  });

  if (imagen?.uri) {
    const name = imagen.name || imagen.fileName || 'foto.jpg';
    const ext = String(name).toLowerCase().match(/\.(jpe?g|png|gif)$/)?.[1] || '';
    const typeRaw = imagen.type || imagen.mimeType || '';
    const type = typeRaw === 'image'
      ? (ext === 'png' ? 'image/png' : ext === 'gif' ? 'image/gif' : 'image/jpeg')
      : (typeRaw || (ext === 'png' ? 'image/png' : ext === 'gif' ? 'image/gif' : 'image/jpeg'));
    console.log('[buildReportForm] imagen', { name, type });
    fd.append('imagen', { uri: imagen.uri, name, type });
  }
  if (latitud != null) fd.append('latitud', typeof latitud === 'number' ? String(Number(latitud).toFixed(7)) : String(latitud));
  if (longitud != null) fd.append('longitud', typeof longitud === 'number' ? String(Number(longitud).toFixed(7)) : String(longitud));
  if (condicion_inicial_id) fd.append('condicion_inicial_id', String(condicion_inicial_id));
  if (tipo_incidente_id) fd.append('tipo_incidente_id', String(tipo_incidente_id));
  if (tamano) fd.append('tamano', tamano);
  if (typeof puede_moverse !== 'undefined') fd.append('puede_moverse', puede_moverse ? '1' : '0');
  if (direccion) fd.append('direccion', direccion);
  if (observaciones) fd.append('observaciones', observaciones);

  // DISABLED: traslado_inmediato causes persona_id null violation errors
  // The backend doesn't receive persona_id correctly from FormData
  // Solution: Don't send traslado_inmediato - transfers must be created separately
  console.log('[buildReportForm] traslado_inmediato DISABLED - transfers must be created separately');

  // Auto-approve reports
  fd.append('aprobado', '1');
  console.log('[buildReportForm] Report will be auto-approved');

  return fd;
};

export const createReport = async (data) => {
  const payload = data && typeof data.append === 'function' ? data : buildReportForm(data || {});
  try {
    console.log('POST /reports iniciar');
    const response = await apiClient.post('/reports', payload, { headers: { 'Content-Type': 'multipart/form-data' } });
    console.log('POST /reports OK', response?.status, response?.data);
    return response.data;
  } catch (err) {
    console.log('POST /reports error', err?.response?.status, err?.response?.data);
    throw err;
  }
};

export const listReports = async (params = {}) => {
  const { data } = await apiClient.get('/reports', { params });
  const arr = Array.isArray(data?.data) ? data.data : (Array.isArray(data) ? data : []);
  return arr;
};

const base = (API_BASE_URL || apiClient?.defaults?.baseURL || '')
  .toString();
export const storageBaseUrl = base.endsWith('/api')
  ? base.replace(/\/api$/, '/storage')
  : base.replace('/api', '/storage');

export const resolveImageUrl = (u) => {
  if (!u) return null;
  if (typeof u !== 'string') return null;
  const raw = String(u).trim();
  if (raw.startsWith('http://') || raw.startsWith('https://')) return raw;
  const appBase = base.endsWith('/api') ? base.slice(0, -4) : base;
  let path = raw;
  if (path.startsWith('/storage')) {
    return encodeURI(`${appBase}${path}`);
  }
  if (path.startsWith('storage')) {
    return encodeURI(`${appBase}/${path}`);
  }
  if (path.startsWith('/reports') || path.startsWith('reports')) {
    path = path.replace(/^\/+/, '');
    return encodeURI(`${appBase}/storage/${path}`);
  }
  path = path.replace(/^\/+/, '');
  return encodeURI(`${appBase}/storage/${path}`);
};
