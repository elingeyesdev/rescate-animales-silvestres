import axios from 'axios';
import { getToken } from './tokenStore';

// Ajusta esta URL si tu backend no corre en este host/puerto
export const API_BASE_URL = 'http://192.168.0.26:8000/api';

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 20000,
  headers: {
    Accept: 'application/json',
  },
});

//agrega el token si existe
apiClient.interceptors.request.use(
  async (config) => {
    const token = await getToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    try {
      console.log('API request', config.method, config.baseURL, config.url);
    } catch { }
    return config;
  },
  (error) => Promise.reject(error)
);

// Interceptor de respuesta: detecta expiración o errores de auth
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    const hasResponse = !!error.response;
    if (hasResponse) {
      const { status } = error.response;
      if (status === 404) {
        return Promise.reject({ status: 404, message: 'No hay datos', raw: error });
      }
      if (status === 401 || status === 419) {
        console.warn('Sesión expirada o no autorizada');
      }
      try {
        console.log('API error', status, error?.config?.method, error?.config?.baseURL, error?.config?.url);
      } catch { }
      return Promise.reject(error);
    }
    const isTimeout = error.code === 'ECONNABORTED' || String(error.message || '').toLowerCase().includes('timeout');
    const networkErr = new Error(isTimeout ? 'Tiempo de espera agotado. Verifica tu conexión y el servidor.' : 'No se pudo conectar con el servidor. Verifica tu red y la URL.');
    networkErr.original = error;
    return Promise.reject(networkErr);
  }
);

export default apiClient;

export const pingServer = async () => {
  try {
    const base = API_BASE_URL;
    const appBase = base.endsWith('/api') ? base.slice(0, -4) : base;
    const r1 = await axios.get(appBase, { timeout: 5000 });
    return !!r1;
  } catch (e1) {
    if (e1?.response) return true;
    try {
      const base = API_BASE_URL;
      const appBase = base.endsWith('/api') ? base.slice(0, -4) : base;
      const r2 = await axios.get(`${appBase}/health`, { timeout: 5000 });
      return !!r2;
    } catch (e2) {
      return false;
    }
  }
};

export const getCurrentUser = async () => {
  const r = await apiClient.get('/user');
  return r.data;
};

