import apiClient from './client';

export const listMedicalEvaluations = async (animalFileId, page = 1) => {
  if (!animalFileId) return [];
  const { data } = await apiClient.get('/animal-medical-evaluations', { params: { animal_file_id: animalFileId, page } });
  const arr = Array.isArray(data?.data) ? data.data : (Array.isArray(data) ? data : []);
  return arr;
};

export const getMedicalEvaluation = async (id) => {
  const { data } = await apiClient.get(`/animal-medical-evaluations/${id}`);
  return data;
};

export const createMedicalEvaluation = async (payload) => {
  const fd = new FormData();
  Object.entries(payload || {}).forEach(([k, v]) => {
    if (v === undefined || v === null) return;
    if (k === 'imagen' && v?.uri) {
      const name = v.name || 'evaluacion.jpg';
      const type = v.type || 'image/jpeg';
      fd.append('imagen', { uri: v.uri, name, type });
    } else {
      fd.append(k, v);
    }
  });
  const { data } = await apiClient.post('/animal-medical-evaluations', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
  return data;
};
