import apiClient from './client';

export const listAnimalFeedings = async (animalFileId) => {
  const { data } = await apiClient.get('/animal-feedings', { params: { animal_file_id: animalFileId } });
  const arr = Array.isArray(data?.data) ? data.data : (Array.isArray(data) ? data : []);
  return arr;
};

export const getAnimalFeeding = async (id) => {
  const { data } = await apiClient.get(`/animal-feedings/${id}`);
  return data;
};

export const createAnimalFeeding = async (payload) => {
  const { data } = await apiClient.post('/animal-feedings', payload);
  return data;
};

