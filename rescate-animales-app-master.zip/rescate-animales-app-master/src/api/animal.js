import apiClient from './client';

export const getAnimalFile = async (id) => {
  if (!id) throw new Error('Falta animalFileId');
  const { data } = await apiClient.get(`/animal-files/${id}`);
  return data;
};

export const listAnimalFiles = async (filters = {}) => {
  const { data } = await apiClient.get('/animal-files', { params: filters });
  const arr = Array.isArray(data?.data) ? data.data : (Array.isArray(data) ? data : []);
  return arr;
};

export const listMedicalEvaluations = async (animalFileId) => {
  if (!animalFileId) return [];
  const { data } = await apiClient.get('/animal-medical-evaluations', { params: { animal_file_id: animalFileId } });
  const arr = Array.isArray(data?.data) ? data.data : (Array.isArray(data) ? data : []);
  return arr;
};

export const getMedicalEvaluation = async (id) => {
  const { data } = await apiClient.get(`/animal-medical-evaluations/${id}`);
  return data;
};

export const createMedicalEvaluation = async (payload) => {
  const { data } = await apiClient.post('/animal-medical-evaluations', payload);
  return data;
};

export const listAnimalCares = async (animalFileId) => {
  if (!animalFileId) return [];
  const { data } = await apiClient.get('/animal-cares', { params: { animal_file_id: animalFileId } });
  const arr = Array.isArray(data?.data) ? data.data : (Array.isArray(data) ? data : []);
  return arr;
};

export const getAnimalCare = async (id) => {
  const { data } = await apiClient.get(`/animal-cares/${id}`);
  return data;
};

export const createAnimalCare = async (payload) => {
  const { data } = await apiClient.post('/animal-cares', payload);
  return data;
};

export const listTransfers = async (animalIdOrOptions) => {
  const params = (typeof animalIdOrOptions === 'object' && animalIdOrOptions !== null)
    ? (animalIdOrOptions.reporte_id
        ? { reporte_id: animalIdOrOptions.reporte_id }
        : animalIdOrOptions.reportId
          ? { reporte_id: animalIdOrOptions.reportId }
          : (animalIdOrOptions.animalId ? { animal_id: animalIdOrOptions.animalId } : null))
    : (animalIdOrOptions ? { animal_id: animalIdOrOptions } : null);
  if (!params) return [];
  const { data } = await apiClient.get('/transfers', { params });
  const arr = Array.isArray(data?.data) ? data.data : (Array.isArray(data) ? data : []);
  return arr;
};

export const getTransfer = async (id) => {
  const { data } = await apiClient.get(`/transfers/${id}`);
  return data;
};

export const listAnimalHistories = async (animalFileId) => {
  if (!animalFileId) return [];
  const { data } = await apiClient.get(`/animal-histories/${animalFileId}`);
  const arr = Array.isArray(data?.data) ? data.data : (Array.isArray(data) ? data : []);
  return arr;
};

export const getAnimalHistory = async (id) => {
  const { data } = await apiClient.get(`/animal-histories/${id}`);
  return data;
};

export const createAnimalHistory = async (payload) => {
  const { data } = await apiClient.post('/animal-histories', payload);
  return data;
};

export const listReleases = async (animalFileId) => {
  if (!animalFileId) return [];
  const { data } = await apiClient.get('/releases', { params: { animal_file_id: animalFileId } });
  const arr = Array.isArray(data?.data) ? data.data : (Array.isArray(data) ? data : []);
  return arr;
};

export const getRelease = async (id) => {
  const { data } = await apiClient.get(`/releases/${id}`);
  return data;
};

export const createRelease = async (payload) => {
  const { data } = await apiClient.post('/releases', payload);
  return data;
};

export const listAnimalFeedings = async (animalFileId) => {
  const { data } = await apiClient.get('/animal-feedings', { params: { animal_file_id: animalFileId } });
  const arr = Array.isArray(data?.data) ? data.data : (Array.isArray(data) ? data : []);
  return arr;
};

export const getAnimalFeeding = async (id) => {
  const { data } = await apiClient.get(`/animal-feedings/${id}`);
  return data;
};

export const createAnimalFeeding = async (payload) => {
  const { data } = await apiClient.post('/animal-feedings', payload);
  return data;
};

export const createAnimalFile = async (payload) => {
  const { data } = await apiClient.post('/animal-files', payload);
  return data;
};

export const createTransfer = async ({ report_id, centro_id, observaciones, latitud, longitud }) => {
  const payload = {
    report_id: String(report_id),
    centro_id: String(centro_id),
  };
  if (observaciones) payload.observaciones = observaciones;
  if (latitud != null) payload.latitud = typeof latitud === 'number' ? String(Number(latitud).toFixed(7)) : String(latitud);
  if (longitud != null) payload.longitud = typeof longitud === 'number' ? String(Number(longitud).toFixed(7)) : String(longitud);
  const { data } = await apiClient.post('/transfers', payload);
  return data;
};
