import '@testing-library/jest-native/extend-expect';
jest.mock('react-native-safe-area-context', () => {
  const React = require('react');
  const SafeAreaViewMock = ({ children, style }) => React.createElement('View', { style }, children);
  return { SafeAreaView: SafeAreaViewMock };
});
jest.mock('@expo/vector-icons', () => ({ MaterialIcons: () => null }));
jest.mock('@react-native-async-storage/async-storage', () => ({
  setItem: jest.fn(async () => {}),
  getItem: jest.fn(async () => null),
  removeItem: jest.fn(async () => {}),
}));
