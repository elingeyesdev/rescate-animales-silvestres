# Rescate Animales App

## Descripción General

**Rescate Animales App** es una aplicación móvil desarrollada en React Native para la gestión integral de rescates de fauna silvestre. La aplicación permite a los usuarios registrar hallazgos de animales, coordinar traslados, y gestionar fichas clínicas y liberaciones. Está diseñada para funcionar en entornos con conectividad limitada, ofreciendo capacidades robustas de modo offline y sincronización automática.

## Características Principales

*   **Registro de Hallazgos:** Reporte de animales heridos o en peligro con geolocalización, fotos y detalles del estado.
*   **Gestión de Centros:** Visualización de centros de rescate cercanos en mapa.
*   **Modo Offline:** Funcionalidad completa sin conexión a internet. Los datos se almacenan localmente y se sincronizan cuando se restablece la conexión.
    *   Carga de formularios (especies, condiciones, incidentes) desde caché.
    *   Visualización de centros guardados previamente.
    *   Almacenamiento de reportes pendientes de envío.
*   **Gestión de Roles:** Acceso diferenciado para usuarios, veterinarios y administradores.
*   **Seguimiento:** Trazabilidad completa desde el hallazgo hasta la liberación o deceso.

## Requisitos Previos

*   Node.js (v18 o superior)
*   npm o yarn
*   Expo CLI
*   Dispositivo móvil (Android/iOS) o emulador para pruebas.

## Instalación y Configuración

1.  **Clonar el repositorio:**
    ```bash
    git clone https://github.com/usuario/rescate-animales-app.git
    cd rescate-animales-app
    ```

2.  **Instalar dependencias:**
    ```bash
    npm install
    ```

3.  **Configuración de entorno:**
    *   Asegúrese de que la URL de la API esté configurada correctamente en `src/api/client.js`.

4.  **Ejecutar la aplicación:**
    ```bash
    npx expo start
    ```

## Estructura del Proyecto

*   `src/api/`: Clientes HTTP y lógica de conexión con el backend.
*   `src/components/`: Componentes de UI reutilizables (Botones, Inputs, Mapas).
*   `src/context/`: Gestión de estado global (Autenticación).
*   `src/navigation/`: Configuración de rutas y navegación.
*   `src/screens/`: Pantallas principales de la aplicación.
*   `src/services/`: Servicios en segundo plano (Sincronización).
*   `src/utils/`: Utilidades para almacenamiento offline, manejo de errores y formateo.

## Arquitectura y Tecnologías

*   **Frontend:** React Native con Expo.
*   **Navegación:** React Navigation (Stack y Bottom Tabs).
*   **Estado:** Context API + Hooks.
*   **Mapas:** Leaflet (vía WebView) y Expo Location.
*   **Almacenamiento Local:** AsyncStorage y Expo FileSystem.
*   **HTTP:** Axios con interceptores para manejo de tokens y errores.

## Modo Offline y Sincronización

La aplicación implementa una estrategia de "Offline First" para funciones críticas:

1.  **Caché de Datos Estáticos:** Al iniciar con conexión, la app descarga y guarda localmente listas de selección (condiciones, tipos de incidentes) y ubicaciones de centros.
2.  **Cola de Sincronización:** Las acciones realizadas sin internet (crear reportes) se guardan en una cola persistente (`@pending_reports`).
3.  **SyncService:** Un servicio monitorea la conexión y reintenta enviar los datos pendientes automáticamente cuando se detecta internet.
4.  **Fallback:** Si la API falla, la app recurre automáticamente a los datos en caché para permitir la continuidad operativa.

## Despliegue

Para generar los binarios de producción:

```bash
eas build --profile production --platform android
# o
eas build --profile production --platform ios
```

## Licencia

Este proyecto es propiedad privada y su uso está restringido a personal autorizado.
