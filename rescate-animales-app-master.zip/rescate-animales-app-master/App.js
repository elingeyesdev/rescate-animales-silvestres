import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Alert, Platform } from 'react-native';
import { useEffect } from 'react';
import LoginScreen from './src/screens/LoginScreen';
import RegisterScreen from './src/screens/RegisterScreen';
import MainTabs from './src/navigation/MainTabs';
import HojaDeVida from './src/screens/HojaDeVida';
import EvaluationsScreen from './src/screens/EvaluationsScreen';
import CaresScreen from './src/screens/CaresScreen';
import TransfersScreen from './src/screens/TransfersScreen';
import HistoryScreen from './src/screens/HistoryScreen';
import ReleasesScreen from './src/screens/ReleasesScreen';
import AnimalFileCreateScreen from './src/screens/AnimalFileCreateScreen';
import PendingReportsScreen from './src/screens/PendingReportsScreen';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AuthProvider } from './src/context/AuthContext';
import { colors } from './src/theme/colors';
import { MaterialIcons } from '@expo/vector-icons';
import ErrorBoundary from './src/components/ErrorBoundary';
import { useNotifications, sendPushTokenToBackend } from './src/hooks/useNotifications';
import { useReportStatusPolling } from './src/hooks/useReportStatusPolling';
import { LogBox } from 'react-native';

// Ignorar advertencia específica de Expo Notifications en Expo Go
LogBox.ignoreLogs([
  'expo-notifications: Android Push notifications',
  'No se pudo enviar el token al servidor'
]);

const Stack = createNativeStackNavigator();

function AppNavigator() {
  // Activar polling de reportes
  useReportStatusPolling();
  // Configuración común del header
  // La barra de estado está oculta, así que no necesitamos padding extra
  const headerOptions = {
    headerStyle: {
      backgroundColor: colors.bg,
    },
    headerTitleStyle: {
      color: colors.textDark,
    },
    headerTintColor: colors.textDark,
    // Asegura que el contenido no se solape con el header
    contentStyle: {
      flex: 1,
    },
  };

  return (
    <NavigationContainer>
      <StatusBar hidden={true} />
      <Stack.Navigator
        screenOptions={headerOptions}
      >
        <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
        <Stack.Screen name="Register" component={RegisterScreen} options={{ headerShown: false }} />
        <Stack.Screen name="Main" component={MainTabs} options={{ headerShown: false }} />
        <Stack.Screen name="HojaDeVida" component={HojaDeVida} options={{ title: 'Hoja de vida' }} />
        <Stack.Screen name="Evaluations" component={EvaluationsScreen} options={{ title: 'Evaluaciones médicas' }} />
        <Stack.Screen name="Cares" component={CaresScreen} options={{ title: 'Cuidados' }} />
        <Stack.Screen name="Transfers" component={TransfersScreen} options={{ title: 'Traslados' }} />
        <Stack.Screen name="History" component={HistoryScreen} options={{ title: 'Historial' }} />
        <Stack.Screen name="Releases" component={ReleasesScreen} options={{ title: 'Liberaciones' }} />
        <Stack.Screen name="AnimalFileCreate" component={AnimalFileCreateScreen} options={{ title: 'Crear Hoja de Vida' }} />
        <Stack.Screen name="PendingReports" component={PendingReportsScreen} options={{ title: 'Reportes Pendientes', headerShown: false }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default function App() {
  const { expoPushToken } = useNotifications();

  useEffect(() => {
    if (expoPushToken) {
      sendPushTokenToBackend(expoPushToken);
    }
  }, [expoPushToken]);

  return (
    <ErrorBoundary>
      <SafeAreaProvider>
        <AuthProvider>
          <AppNavigator />
        </AuthProvider>
      </SafeAreaProvider>
    </ErrorBoundary>
  );
}
